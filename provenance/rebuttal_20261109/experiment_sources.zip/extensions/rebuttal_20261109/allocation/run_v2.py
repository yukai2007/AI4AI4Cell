"""Independent 360-fit allocation study; no historical fit-cache reuse."""
from __future__ import annotations
import argparse
from collections import Counter
import itertools
import os
from pathlib import Path
import platform
import statistics
import time
from allocation_shared import v1
import numpy as np
import torch

ROOT, HERE, OLD, BASE = v1.ROOT, v1.HERE, v1.OLD, v1.BASE
OUT = ROOT/'results/rebuttal_20261109/allocation/v2'
TASKS, SEEDS, SLATE = v1.TASKS, v1.SEEDS, v1.SLATE
read, sha, dump = v1.read, v1.sha, v1.dump
proposal, promote, selected, score_promotions = v1.proposal, v1.promote, v1.selected, v1.score_promotions
JOBS = tuple((task, seed) for task in TASKS for seed in SEEDS)

def fit_path(task, seed, identifier, rounds):
    return OUT/task/f'seed{seed}'/'fits'/f'r{rounds}'/identifier

def preparation():
    destination=OUT/'registration.json'
    if destination.exists():
        registration=read(destination)
        for p,s in registration['bindings'].items():
            if sha(p)!=s: raise ValueError('Frozen binding changed: '+p)
        return registration
    files=[HERE/'run_v2.py',HERE/'run.py',HERE/'allocation_shared.py',OLD/'core.py',OLD/'core_v3.py',
        OLD/'run_v6.py',OLD/'research_v6.py',OLD/'research_v4.py',OLD/'adapters.py',
        OLD/'native_run.py',OLD/'ptpc_neural_adapter.py',OLD/'heldout_v6.py',
        OLD/'heldout_ptpc_neural.py',OLD/'prepare_ptpc_neural.py',
        ROOT/'extensions/federated_bio_20260918/scdebart.py',
        ROOT/'extensions/federated_bio_20260918/engine.py',
        ROOT/'extensions/proteomics/scoring.py',ROOT/'extensions/proteomics/ptpc_model.py']
    bindings={str(p):sha(p) for p in files}
    for task,seed in JOBS:
        definition_path=v1.old_study(task,seed)/'definition.json'
        definition=read(definition_path)
        assert definition['slate']==list(SLATE) and definition['clients']==list(range(10))
        for name,expected in definition['source_sha256'].items():
            if sha(OLD/name)!=expected: raise ValueError('Original source changed: '+name)
        bindings[str(definition_path)]=sha(definition_path)
        data=BASE/task/'data'; manifest=data/'manifest.json'
        assert sha(manifest)==definition['data_manifest_sha256']
        bindings[str(manifest)]=sha(manifest)
        actual=data if task=='ptpc_neural' else Path(read(manifest)['data_root'])
        inputs=[actual/f'clients/{c}/{role}.npz' for c in range(10) for role in ('train','dev')]
        if task!='ptpc_neural': inputs += [actual/n for n in ('public_hidden.npy','initial_head.pt','scoring_mask.npy')]
        for p in inputs:
            if str(p) not in bindings: bindings[str(p)]=sha(p)
    registration=dict(schema='allocation-controls-20261109-v2',registered_unix=time.time(),
        tasks=TASKS,seeds=SEEDS,slate=SLATE,bindings=bindings,
        jobs={'0':[list(job) for job in JOBS]},
        predecessor='v1 stopped on bitwise canary mismatch; no old or v1 fit reused',
        protocol=dict(training_labs=list(range(10)),development_panels=list(range(10)),
            rounds_per_fit=[20,80,100],new_fit_count=360,screening_candidates=10,
            screening_rounds=20,validation_rounds=100,promoted_candidates=6,
            restart_from_initialization=True,aggregation_rounds_per_policy=800,
            aggregate_dev_evaluations_per_policy=160,all_random_subsets=210,
            uniform_policy='10 independent 80-round fits; development selects one',
            random_policy='Uniform six-subset of ten; validation order is original SLATE order',
            evidence_guided='Original research_v6.promote: best score plus best remaining trajectory in each LR group',
            global_score_only='Highest six screening best-primary then lowest loss; SLATE tie order',
            stratified_score_only='Two per learning-rate group by screening best-primary then loss; SLATE tie order',
            selection='Best full-training development primary then lower loss; retain earlier candidate on complete tie',
            screening_cost='All 10 x20 screening fits plus 6 x100 fresh fits charged to every promotion policy',
            inference='All selected unique r80/r100 models newly scored only after global seal',
            runtime='CUDA, physical GPU6, original core_v3.Federation, one task-seed at a time',
            no_trajectory_truncation=True,no_historical_fit_reuse=True,
            retrospective=True,no_new_llm_calls=True))
    dump(destination,registration)
    return registration

def train(shard):
    registration=preparation()
    if os.environ.get('CUDA_VISIBLE_DEVICES')!='6' or shard!=0:
        raise ValueError('Single-shard CUDA version requires physical GPU6')
    started=time.time(); counts=Counter(); elapsed=[]
    runtime=dict(python=platform.python_version(),torch=torch.__version__,cuda=torch.version.cuda,
        physical_gpu=6,device='cuda:0',gpu=torch.cuda.get_device_name(0),threads=torch.get_num_threads(),host=platform.node(),
        deterministic_algorithms=torch.are_deterministic_algorithms_enabled(),
        cudnn_deterministic=torch.backends.cudnn.deterministic,
        cuda_matmul_allow_tf32=torch.backends.cuda.matmul.allow_tf32,
        registered_sha256=sha(OUT/'registration.json'))
    dump(OUT/f'runtime_shard{shard}.json',runtime)
    jobs=registration['jobs'][str(shard)]
    for task in TASKS:
        taskjobs=[(t,s) for t,s in jobs if t==task]
        if not taskjobs: continue
        federation=v1.Federation(BASE/task/'data',(0,))
        try:
            for _,seed in taskjobs:
                for rounds in (20,80,100):
                    for identifier in SLATE:
                        path=fit_path(task,seed,identifier,rounds)
                        if not (path/'fit.json').exists():
                            if path.exists(): raise RuntimeError('Interrupted fit preserved: '+str(path))
                            federation.fit(proposal(identifier)['config'],list(range(10)),path,seed=seed,rounds=rounds)
                        record=read(path/'fit.json')
                        assert record['config']==proposal(identifier)['config'] and record['seed']==seed
                        assert record['clients']==list(range(10)) and len(record['history'])==rounds
                        counts[f'r{rounds}']+=1; elapsed.append(record['training_seconds'])
                        state=dict(status='RUNNING',shard=shard,task=task,seed=seed,rounds=rounds,
                            design=identifier,counts=dict(counts),training_seconds=sum(elapsed),updated_unix=time.time())
                        dump(OUT/f'status_shard{shard}.json',state)
                        print(__import__('json').dumps(state),flush=True)
        finally: federation.close()
    assert sum(counts.values())==360
    dump(OUT/f'training_complete_shard{shard}.json',dict(status='COMPLETE',shard=shard,
        counts=dict(counts),fit_training_seconds=sum(elapsed),wall_seconds=time.time()-started,
        started_unix=started,completed_unix=time.time(),runtime=runtime))
    dump(OUT/f'status_shard{shard}.json',dict(status='COMPLETE',counts=dict(counts),updated_unix=time.time()))

def make_selection():
    registration=preparation()
    completions=[read(OUT/'training_complete_shard0.json')]
    assert all(x['status']=='COMPLETE' and sum(x['counts'].values())==360 for x in completions)
    counts=Counter()
    for c in completions: counts.update(c['counts'])
    training=dict(status='COMPLETE',counts=dict(counts),
        fit_training_seconds=sum(c['fit_training_seconds'] for c in completions),
        wall_seconds=max(c['completed_unix'] for c in completions)-min(c['started_unix'] for c in completions),
        shard_wall_seconds=[c['wall_seconds'] for c in completions],completed_unix=time.time())
    dump(OUT/'training_complete.json',training)
    selections={}; bindings={str(OUT/'registration.json'):sha(OUT/'registration.json')}
    for task in TASKS:
        selections[task]={}
        for seed in SEEDS:
            screen={i:read(fit_path(task,seed,i,20)/'fit.json') for i in SLATE}
            validation={i:read(fit_path(task,seed,i,100)/'fit.json') for i in SLATE}
            uniform={i:read(fit_path(task,seed,i,80)/'fit.json') for i in SLATE}
            choices=score_promotions(screen); choices['evidence_guided']=promote(screen)
            chosen={name:selected(ids,validation) for name,ids in choices.items()}
            random_counts=Counter(selected(subset,validation) for subset in itertools.combinations(SLATE,6))
            assert sum(random_counts.values())==210
            for rounds in (20,80,100):
                for i in SLATE:
                    for name in ('fit.json','best.pt'):
                        p=fit_path(task,seed,i,rounds)/name; bindings[str(p)]=sha(p)
            selections[task][str(seed)]=dict(promoted=choices,selected=chosen,
                random_selected_counts=dict(random_counts),uniform_design=selected(SLATE,uniform))
    result=dict(schema='allocation-controls-selection-v2',selections=selections,bindings=bindings,
        sealed_unix=time.time(),test_read=False,retrospective=True,no_historical_fit_reuse=True)
    destination=OUT/'selection_seal.json'
    if destination.exists():
        old=read(destination)
        assert old['selections']==selections and old['bindings']==bindings
        return old
    dump(destination,result)
    return result

def evaluate():
    preparation()
    receipt=read(OUT/'selection_seal.json')
    for p,s in receipt['bindings'].items():
        if sha(p)!=s: raise ValueError('Sealed fit/source changed: '+p)
    import heldout_v6 as heldout
    decoded=time.time(); scored={}; heldout_bindings={}
    assert decoded>receipt['sealed_unix']
    device='cpu'; torch.set_num_threads(2)
    for task in TASKS:
        manifest=read(BASE/task/'data/manifest.json')
        if task=='ptpc_neural':
            source=ROOT/'data/proteomics/ptpc_release_20260911'; querypath=source/'final/final.npz'
        else: source=Path(manifest['data_root']); querypath=source/'test/query.npz'
        heldout_bindings[str(querypath)]=sha(querypath)
        query=heldout.archive(querypath)
        if task=='ptpc_neural': x=heldout.features(query)
        else:
            hidden=np.load(source/'public_hidden.npy',mmap_mode='r')
            initial=torch.load(source/'initial_head.pt',map_location='cpu',weights_only=True)
            mask=np.load(source/'scoring_mask.npy')
        scored[task]={}
        for seed in SEEDS:
            row=receipt['selections'][task][str(seed)]
            used={(100,i) for i in set(row['selected'].values())|set(row['random_selected_counts'])}
            used.add((80,row['uniform_design']))
            values={}; models={}
            for rounds,identifier in sorted(used):
                location=fit_path(task,seed,identifier,rounds); record=read(location/'fit.json')
                if task=='ptpc_neural':
                    model=heldout.Predictor(manifest['n_proteins'],manifest['n_drug_features'],record['config']['residual'])
                else: model=heldout.make_head(initial,record['config'])
                heldout.restore(model,torch.load(location/'best.pt',map_location='cpu',weights_only=False)); model.eval()
                predpath=OUT/task/f'seed{seed}'/'heldout'/f'r{rounds}_{identifier}.npz'
                predpath.parent.mkdir(parents=True,exist_ok=True)
                with torch.inference_mode():
                    if task=='ptpc_neural':
                        p=torch.cat([model(c).sigmoid().cpu() for c in torch.as_tensor(x,dtype=torch.float32).split(512)]).numpy()
                        from sklearn.metrics import average_precision_score
                        value=heldout.phenotype_scores(query['y'],p)['ap']
                        assert abs(value-float(average_precision_score(query['y'],p)))<1e-12
                        np.savez_compressed(predpath,probabilities=p,y=query['y'])
                    else:
                        e=heldout.cell_evaluate(model,hidden,query,mask,device,return_rows=True)
                        value=heldout.cell_summary([e])['macro_accuracy']
                        ranks=np.asarray([r['rank'] for r in e['rows']]); ids=np.asarray(query['ids'])
                        independent=float(np.mean([np.mean(ranks[ids==g]==1) for g in np.unique(ids)]))
                        assert abs(value-independent)<1e-12
                        np.savez_compressed(predpath,ranks=ranks,ids=ids)
                values[(rounds,identifier)]=value
                models[f'r{rounds}_{identifier}']=dict(primary=value,prediction_sha256=sha(predpath))
            results={name:values[(100,identifier)] for name,identifier in row['selected'].items()}
            results['uniform_80']=values[(80,row['uniform_design'])]
            weights=row['random_selected_counts']
            expectation=sum(values[(100,i)]*n/210 for i,n in weights.items())
            variance=sum((values[(100,i)]-expectation)**2*n/210 for i,n in weights.items())
            results['random_promotion_exact']=expectation
            scored[task][str(seed)]=dict(results=results,selected=row,scored_models=models,
                random_policy_sd=variance**.5,random_min=min(values[(100,i)] for i in weights),
                random_max=max(values[(100,i)] for i in weights))
            print(__import__('json').dumps(dict(phase='heldout',task=task,seed=seed,results=results)),flush=True)
    summary={}
    for task,rows in scored.items():
        summary[task]={}
        for method in next(iter(rows.values()))['results']:
            values=[r['results'][method] for r in rows.values()]
            summary[task][method]=dict(mean=statistics.mean(values),sample_sd=statistics.stdev(values),n=3)
    payload=dict(schema='allocation-controls-results-v2',status='COMPLETE',summary=summary,per_seed=scored,
        selection_seal_sha256=sha(OUT/'selection_seal.json'),heldout_bindings=heldout_bindings,
        heldout_decoded_unix=decoded,completed_unix=time.time(),independent_rescore='PASS',
        training=read(OUT/'training_complete.json'),protocol=read(OUT/'registration.json')['protocol'])
    dump(OUT/'results.json',payload); dump(OUT/'status.json',dict(status='COMPLETE',updated_unix=time.time()))
    print(__import__('json').dumps(summary,indent=2),flush=True)

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('action',choices=('prepare','train','seal','evaluate'))
    parser.add_argument('--shard',type=int,choices=(0,)); args=parser.parse_args(); torch.set_num_threads(2)
    if args.action=='prepare': preparation()
    elif args.action=='train':
        if args.shard is None: parser.error('train requires --shard')
        train(args.shard)
    elif args.action=='seal': make_selection()
    else: evaluate()

if __name__=='__main__': main()
