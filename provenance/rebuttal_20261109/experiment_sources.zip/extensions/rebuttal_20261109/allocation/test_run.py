import importlib.util
from pathlib import Path
import unittest

spec=importlib.util.spec_from_file_location('allocation_run',Path(__file__).with_name('run.py'))
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

class AllocationTests(unittest.TestCase):
    def records(self):
        return {i:{'best':{'development':{'primary':float(j),'loss':1.}}} for j,i in enumerate(m.SLATE)}
    def test_top_six(self):
        result=m.score_promotions(self.records())
        self.assertEqual(result['score_only_global'],list(reversed(m.SLATE))[:6])
    def test_stratified_two_each(self):
        result=m.score_promotions(self.records())['score_only_stratified']
        self.assertEqual(len(result),6)
        self.assertEqual([sum(i.startswith(f'L{g}') for i in result) for g in range(3)],[2,2,2])
    def test_complete_tie_keeps_slate_order(self):
        records={i:{'best':{'development':{'primary':1.,'loss':1.}}} for i in m.SLATE}
        self.assertEqual(m.selected(m.SLATE,records),m.SLATE[0])
    def test_random_exact_probabilities(self):
        records=self.records()
        counts=m.Counter(m.selected(ids,records) for ids in m.itertools.combinations(m.SLATE,6))
        self.assertEqual(sum(counts.values()),210)
        self.assertEqual(counts[m.SLATE[-1]],126)
    def test_budget(self):
        self.assertEqual(10*20+6*100,10*80)
        self.assertEqual(10*4+6*20,10*16)

if __name__=='__main__': unittest.main()
