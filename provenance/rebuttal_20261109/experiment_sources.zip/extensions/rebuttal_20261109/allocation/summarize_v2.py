"""Human-readable report of the independent fresh-runtime allocation rerun."""
import json
from pathlib import Path
import statistics

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'results/rebuttal_20261109/allocation/v2'
TASKS=('ptpc_neural','vcc_corrected','norman_double_corrected','tahoe_drug_corrected')
METHODS=(('uniform_80','Uniform (80 rounds)'),
    ('random_promotion_exact','Random promotion'),
    ('score_only_global','Score-only (global)'),
    ('score_only_stratified','Score-only (LR-stratified)'),
    ('evidence_guided','Score + trajectory'))

def main():
    data=json.loads((OUT/'results.json').read_text())
    assert data['status']=='COMPLETE' and data['independent_rescore']=='PASS'
    lines=['Fresh-runtime same-budget allocation controls (2026-11-09)',
        '', 'All scores x100. Mean +/- sample SD across seeds 53,54,55.',
        'Protein AP | VCC Top-1 | Norman Top-1 | Tahoe Top-1']
    tex=[r'\begin{tabular}{lrrrr}',r'\toprule',
        r'Allocation policy & Protein AP $\uparrow$ & VCC $\uparrow$ & Norman $\uparrow$ & Tahoe $\uparrow$ \\',r'\midrule']
    for method,label in METHODS:
        cells=[]
        for task in TASKS:
            row=data['summary'][task][method]
            cell=f'{100*row["mean"]:.2f} $\\pm$ {100*row["sample_sd"]:.2f}'
            best=max(r['mean'] for r in data['summary'][task].values())
            if abs(row['mean']-best)<1e-12: cell=r'\textbf{'+cell+'}'
            cells.append(cell)
        lines.append(label+' | '+' | '.join(c.replace('$\\pm$','+/-').replace(r'\textbf{','').rstrip('}') for c in cells))
        tex.append(label+' & '+' & '.join(cells)+r' \\')
    tex.extend([r'\bottomrule',r'\end{tabular}'])
    lines.extend(['','Experimental contract:',
        'Ten training labs, equal-lab development selection, the same prespecified ten-design slate.',
        'All 20/80/100-round fits were freshly trained with the same CUDA/software runtime on A100 GPUs 5/6/7.',
        'A resource-only amendment parallelized nine unstarted task-seeds; scientific source and original registration stayed frozen.',
        'Each duration restarted from initialization; no trajectory truncation or old cached fits.',
        'Uniform: 10 x80 rounds. Promotion: 10 x20 screening +6 x100 restarted validation.',
        'All five policies use 800 aggregation rounds and 160 aggregate development evaluations.',
        'The LaTeX table bolds the largest mean in each endpoint, including exact ties.',
        'Policies are replayed from the complete freshly trained slate; the 800-round figure is each policy budget,',
        'not the total cost of constructing the full comparison cache. Actual 360-fit cost is reported below.',
        'This is a retrospective allocation study, separate from the original paper Table2.',
        'It uses the original V6 task partitions, not the separate heterogeneous-source lab study.',
        'No new language-model proposals are generated; candidate designs and selection rules are fixed.',
        'Score-only global promotes highest six best-screen-primary/loss; LR-stratified promotes two per LR group.',
        'Score-plus-trajectory uses the unchanged original research_v6 promotion rule.',
        'Random promotion samples uniformly from C(10,6)=210 subsets, not two per LR group.',
        'All 210 subsets are enumerated exactly, using original slate validation order.',
        'The random row averages selected single-model scores, not an ensemble of predictions.',
        'Its displayed SD is across three seed-conditional expectations; per-seed random-policy SD is in results.json.',
        'All selected checkpoint choices were sealed before the new held-out reads.',
        'Test panels are previously exposed retrospective targets, not newly blinded external cohorts.',
        '', 'Paired score-plus-trajectory minus each control (percentage points):'])
    pooled={m:[] for m,_ in METHODS[:-1]}
    for task in TASKS:
        lines.append(task)
        for method,label in METHODS[:-1]:
            ds=[r['results']['evidence_guided']-r['results'][method] for r in data['per_seed'][task].values()]
            pooled[method].extend(ds)
            w=sum(d>1e-12 for d in ds);l=sum(d< -1e-12 for d in ds)
            lines.append(f'  vs {label}: {100*statistics.mean(ds):+.4f}; W/T/L={w}/{3-w-l}/{l}')
    lines.extend(['','Across all 12 task-seed comparisons (not a common-unit pooled effect):'])
    for method,label in METHODS[:-1]:
        ds=pooled[method];w=sum(d>1e-12 for d in ds);l=sum(d< -1e-12 for d in ds)
        lines.append(f'  vs {label}: W/T/L={w}/{12-w-l}/{l}')
    t=data['training']; accounting=json.loads((OUT/'cost_accounting.json').read_text())
    lines.extend(['',f'Fresh fit counts: {t["counts"]} (360 total).',
        f'Sum of measured fit training seconds: {t["fit_training_seconds"]:.3f}.',
        f'Training-stage wall seconds: {t["wall_seconds"]:.3f}.',
        f'Formal sum of fit elapsed seconds after administrative-pause exclusion (bounded): {accounting["formal_fit_elapsed_seconds_excluding_pause_bounds"]}.',
        f'Preliminary checks: 4 GPU canary fits {accounting["preliminary_gpu_canary_elapsed_seconds"]:.3f} s; 1 CPU benchmark {accounting["preliminary_cpu_benchmark_elapsed_seconds"]:.3f} s.',
        'Fit elapsed sums include host/transfer work and are not directly profiled GPU-kernel computation time.',
        'Independent held-out metric rescore: PASS.',
        'Version1 exact-canary interruption and CPU scheduling benchmark are retained separately and excluded.'])
    (OUT/'RESULTS.txt').write_text('\n'.join(lines)+'\n')
    (OUT/'table.tex').write_text('\n'.join(tex)+'\n')
    print('\n'.join(lines))

if __name__=='__main__': main()
