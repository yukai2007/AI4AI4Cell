"""Export anonymous aggregate-only evidence after sealed v2 validation."""
import json
from pathlib import Path
import shutil
import statistics
import run_v2 as run

METHODS=('uniform_80','random_promotion_exact','score_only_global','score_only_stratified','evidence_guided')

def main():
    data=run.read(run.OUT/'results.json')
    validation=run.read(run.OUT/'validation.json')
    registration=run.read(run.OUT/'registration.json')
    amendment=run.read(run.OUT/'resource_amendment.json')
    accounting=run.read(run.OUT/'cost_accounting.json')
    protocol=dict(data['protocol'])
    protocol['runtime']='Same original core_v3.Federation and CUDA/software runtime; A100 GPUs5/6/7, disjoint complete task-seeds by resource-only amendment'
    assert data['status']=='COMPLETE' and validation['status']=='PASS'
    paired={}; random={}; overall={m:[] for m in METHODS[:-1]}
    for task in run.TASKS:
        paired[task]={}; random[task]={}
        for seed in run.SEEDS:
            row=data['per_seed'][task][str(seed)]
            scores={m:row['results'][m] for m in METHODS}
            deltas={m:scores['evidence_guided']-scores[m] for m in METHODS[:-1]}
            paired[task][str(seed)]=dict(scores=scores,trajectory_minus_control=deltas)
            random[task][str(seed)]=dict(conditional_expectation=scores['random_promotion_exact'],
                within_seed_policy_sd=row['random_policy_sd'],minimum=row['random_min'],maximum=row['random_max'],subsets=210)
            for m,d in deltas.items(): overall[m].append(d)
    wtl={}
    for m,ds in overall.items():
        w=sum(d>1e-12 for d in ds);l=sum(d< -1e-12 for d in ds)
        wtl[m]=dict(wins=w,ties=12-w-l,losses=l)
    snapshot=dict(schema='biocoloop-allocation-public-v2',status='COMPLETE',metric_units='fraction [0,1]',
        tasks=dict(ptpc_neural='Proteomic average precision',vcc_corrected='VCC macro Top-1 accuracy',
            norman_double_corrected='Norman macro Top-1 accuracy',tahoe_drug_corrected='Tahoe macro Top-1 accuracy'),
        methods=METHODS,training_seeds=list(run.SEEDS),summary=data['summary'],paired=paired,
        twelve_pair_wtl=wtl,random_promotion_distribution=random,
        uncertainty=dict(summary_sd='Sample SD across the three training seeds; random row uses seed-conditional expectations',
            within_seed_policy_sd='SD across all 210 uniformly sampled six-subsets, conditional on the trained slate',
            note='Training-seed variability and random-policy variability are distinct and are not added together'),
        protocol=protocol,cost=dict(new_fits=data['training']['counts'],
            actual_fit_training_seconds=data['training']['fit_training_seconds'],
            actual_training_wall_seconds=data['training']['wall_seconds'],
            actual_total_aggregation_rounds=24000,
            per_policy_aggregation_rounds=800,per_policy_development_evaluations=160,
            explanation='The complete 360-fit slate supports retrospective policy replay; 800 rounds is each policy budget, not total study cost.'),
        cost_accounting=accounting,
        scope='Fresh-runtime rerun of the fixed-slate allocation study on original V6 task partitions; original Table2 remains unchanged. This is not the separate heterogeneous-source lab study.',
        no_historical_fit_reuse=True,no_cpu_benchmark_reuse=True)
    source_hashes={}
    for path,digest in registration['bindings'].items():
        p=Path(path)
        if p.suffix=='.py': source_hashes[str(p.relative_to(run.ROOT))]=digest
    source_hashes['extensions/rebuttal_20261109/allocation/resource_executor_v2.py']=amendment['wrapper_sha256']
    provenance=dict(schema='biocoloop-allocation-public-provenance-v2',source_sha256=source_hashes,
        artifact_sha256={name:run.sha(run.OUT/name) for name in
            ('registration.json','resource_amendment.json','resource_resume.json','selection_seal.json','results.json','validation.json','training_complete.json','cost_accounting.json','table.tex')},
        data_manifest_sha256={task:run.sha(run.BASE/task/'data/manifest.json') for task in run.TASKS},
        validation_status=validation['status'],validation_checks=validation['checks'],
        fit_counts=validation['counts'],scientific_runtime=dict(device='CUDA',gpu_model='NVIDIA A100-SXM4-80GB',
            torch=run.read(run.OUT/'runtime_shard0.json')['torch'],cuda=run.read(run.OUT/'runtime_shard0.json')['cuda']),
        sequence='Frozen protocol; complete fresh training; development selection seal; held-out scoring; independent validation; aggregate export.',
        notes=['v1 stopped at an exact-reproduction canary mismatch and contributes no fits to v2.',
            'A CPU benchmark was used for scheduling only and contributes no scientific result.',
            'A resource-only amendment schedules disjoint complete task-seeds on GPUs5/7 while the GPU6 coordinator pauses, then it checks the completed fits and seals selections. Original scientific registration and source are unchanged.',
            'No absolute paths or query-level outputs are included in this publication snapshot.'])
    out=run.OUT/'public';out.mkdir(exist_ok=True)
    for name,payload in (('allocation_public.json',snapshot),('provenance.json',provenance)):
        text=json.dumps(payload,ensure_ascii=False,indent=2)
        assert all(marker not in text for marker in ('/liziqing/','/home/','yukai','query.npz','prediction_sha256'))
        run.dump(out/name,payload)
    shutil.copyfile(run.OUT/'table.tex',out/'table.tex')
    print('Anonymous aggregate snapshot and provenance: PASS')

if __name__=='__main__': main()
