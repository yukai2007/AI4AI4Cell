"""Load frozen helpers without shadowing the original trainer's run module."""
import importlib.util
from pathlib import Path
import sys

spec=importlib.util.spec_from_file_location('allocation_v1',Path(__file__).with_name('run.py'))
v1=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=v1
spec.loader.exec_module(v1)
