"""Separate recorded elapsed time, scheduling pauses and preliminary checks."""
from pathlib import Path
import run_v2 as run

def main():
    fit_paths=list(run.OUT.glob('*/seed*/fits/r*/*/fit.json'))
    assert len(fit_paths)==360
    raw=sum(run.read(p)['training_seconds'] for p in fit_paths)
    official=run.read(run.OUT/'training_complete.json')
    assert abs(raw-official['fit_training_seconds'])<1e-6
    resume=run.read(run.OUT/'resource_resume.json')
    short_pause_fit=run.read(run.OUT/'ptpc_neural/seed53/fits/r20/L0W2M1R1/fit.json')
    pause_lower=resume['pause_seconds_lower_bound']
    pause_upper=resume['pause_seconds_upper_bound']+short_pause_fit['training_seconds']
    gpu_checks=list(run.OUT.parent.glob('*/seed*/canary/*/fit.json'))
    assert len(gpu_checks)==4
    preliminary_gpu=sum(run.read(p)['training_seconds'] for p in gpu_checks)
    cpu=run.read(run.OUT.parent/'cpu_benchmark/vcc_seed53_L0W1M0R0_r100/fit.json')['training_seconds']
    start=run.read(run.OUT/'training_complete_shard0.json')['started_unix']
    result=run.read(run.OUT/'results.json')
    payload=dict(schema='allocation-cost-accounting-v2',formal_fit_count=360,
        formal_total_aggregation_rounds=24000,formal_fit_elapsed_seconds_raw=raw,
        administrative_pause_seconds_bounds=[pause_lower,pause_upper],
        formal_fit_elapsed_seconds_excluding_pause_bounds=[raw-pause_upper,raw-pause_lower],
        formal_training_wall_seconds=official['wall_seconds'],
        training_through_scoring_wall_seconds=result['completed_unix']-start,
        preliminary_gpu_canary_fit_count=4,preliminary_gpu_canary_elapsed_seconds=preliminary_gpu,
        preliminary_cpu_benchmark_fit_count=1,preliminary_cpu_benchmark_elapsed_seconds=cpu,
        all_gpu_fit_elapsed_excluding_pause_bounds=[raw-pause_upper+preliminary_gpu,raw-pause_lower+preliminary_gpu],
        timing_interpretation='Fit elapsed wall times include initialization, data transfer and host work; these are not directly profiled GPU-kernel seconds. Parallel fit elapsed sums and total wall time are separate.',
        pause_accounting='Long pause bracketed by last progress write and amendment freeze, then timestamped resume. Early short pause is conservatively bounded by its entire 34.06-second affected fit; the resulting interval does not pretend to recover an unlogged exact pause timestamp.')
    run.dump(run.OUT/'cost_accounting.json',payload)
    print(payload)

if __name__=='__main__':main()
