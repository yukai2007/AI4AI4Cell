"""Read-only independent checks of fresh fits, sealed choices and metric outputs."""
import itertools
import math
from collections import Counter
import statistics
import numpy as np
from sklearn.metrics import average_precision_score
import run_v2 as run

def selection_key(record):
    d=record['best']['development']
    return d['primary'],-d['loss']

def main():
    registration=run.read(run.OUT/'registration.json')
    for path,digest in registration['bindings'].items(): assert run.sha(path)==digest,path
    amendment=run.read(run.OUT/'resource_amendment.json')
    assert run.sha(run.HERE/'resource_executor_v2.py')==amendment['wrapper_sha256']
    assert run.sha(run.OUT/'registration.json')==amendment['original_registration_sha256']
    jobs=[tuple(j) for group in amendment['jobs'].values() for j in group]
    assert len(jobs)==len(set(jobs))==9
    assert set(jobs)=={j for j in run.JOBS if j[0]!='ptpc_neural'}
    resume=run.read(run.OUT/'resource_resume.json')
    for shard in (0,1):
        completion=run.read(run.OUT/f'resource_complete{shard}.json')
        assert completion['status']=='COMPLETE'
        assert sum(completion['counts'].values())==30*len(amendment['jobs'][str(shard)])
        assert completion['completed_unix']<=resume['resume_command_before_unix']
        assert completion['runtime']['amendment_sha256']==run.sha(run.OUT/'resource_amendment.json')
    counts=Counter(); all_records={}
    for task in run.TASKS:
        for seed in run.SEEDS:
            for rounds in (20,80,100):
                for identifier in run.SLATE:
                    path=run.fit_path(task,seed,identifier,rounds)
                    assert path.is_relative_to(run.OUT)
                    record=run.read(path/'fit.json')
                    assert record['seed']==seed and record['rounds']==rounds
                    assert record['clients']==list(range(10)) and record['test_read'] is False
                    assert record['config']==run.proposal(identifier)['config']
                    assert [r['round'] for r in record['history']]==list(range(1,rounds+1))
                    curves=[r for r in record['history'] if 'development' in r]
                    assert len(curves)==rounds//5
                    assert record['best']==max(curves,key=lambda r:(r['development']['primary'],-r['development']['loss']))
                    assert all(math.isfinite(r['train_loss']) for r in record['history'])
                    assert all(math.isfinite(r['development'][name]) for r in curves for name in ('primary','loss','worst_client'))
                    assert record['core_sha256']==run.sha(run.OLD/'core_v3.py')
                    counts[f'r{rounds}']+=1; all_records[(task,seed,rounds,identifier)]=record
    assert dict(counts)=={'r20':120,'r80':120,'r100':120}
    seal=run.read(run.OUT/'selection_seal.json')
    for path,digest in seal['bindings'].items(): assert run.sha(path)==digest,path
    data=run.read(run.OUT/'results.json')
    assert data['selection_seal_sha256']==run.sha(run.OUT/'selection_seal.json')
    assert data['heldout_decoded_unix']>seal['sealed_unix']>registration['registered_unix']
    for path,digest in data['heldout_bindings'].items(): assert run.sha(path)==digest,path
    assert data['protocol']==registration['protocol']
    for task in run.TASKS:
        for seed in run.SEEDS:
            row=seal['selections'][task][str(seed)]
            screen={i:all_records[(task,seed,20,i)] for i in run.SLATE}
            full={i:all_records[(task,seed,100,i)] for i in run.SLATE}
            uniform={i:all_records[(task,seed,80,i)] for i in run.SLATE}
            assert row['promoted']['score_only_global']==sorted(run.SLATE,key=lambda i:selection_key(screen[i]),reverse=True)[:6]
            for group in range(3):
                ids=[i for i in run.SLATE if i.startswith(f'L{group}')]
                expected=sorted(ids,key=lambda i:selection_key(screen[i]),reverse=True)[:2]
                actual=[i for i in row['promoted']['score_only_stratified'] if i.startswith(f'L{group}')]
                assert actual==expected
            assert row['promoted']['evidence_guided']==run.promote(screen)
            for method,ids in row['promoted'].items():
                assert len(ids)==len(set(ids))==6
                assert row['selected'][method]==max(ids,key=lambda i:selection_key(full[i]))
            assert row['uniform_design']==max(run.SLATE,key=lambda i:selection_key(uniform[i]))
            random_counts=Counter(max(ids,key=lambda i:selection_key(full[i])) for ids in itertools.combinations(run.SLATE,6))
            assert dict(random_counts)==row['random_selected_counts'] and sum(random_counts.values())==210
            scored=data['per_seed'][task][str(seed)]
            assert scored['selected']==row
            independent_scores={}
            for model,entry in scored['scored_models'].items():
                pred=run.OUT/task/f'seed{seed}'/'heldout'/f'{model}.npz'
                assert run.sha(pred)==entry['prediction_sha256']
                with np.load(pred,allow_pickle=False) as archive:
                    if task=='ptpc_neural':
                        value=float(average_precision_score(archive['y'],archive['probabilities']))
                    else:
                        ranks,ids=archive['ranks'],archive['ids']
                        value=float(np.mean([np.mean(ranks[ids==g]==1) for g in np.unique(ids)]))
                assert abs(value-entry['primary'])<1e-12,(task,seed,model)
                independent_scores[model]=value
            assert set(scored['results'])=={'uniform_80','random_promotion_exact','score_only_global','score_only_stratified','evidence_guided'}
            for method,identifier in row['selected'].items():
                assert abs(scored['results'][method]-independent_scores[f'r100_{identifier}'])<1e-12
            assert abs(scored['results']['uniform_80']-independent_scores['r80_'+row['uniform_design']])<1e-12
            exact=sum(independent_scores[f'r100_{i}']*n/210 for i,n in random_counts.items())
            assert abs(exact-scored['results']['random_promotion_exact'])<1e-12
            variance=sum((independent_scores[f'r100_{i}']-exact)**2*n/210 for i,n in random_counts.items())
            assert abs(variance**.5-scored['random_policy_sd'])<1e-12
            assert abs(min(independent_scores[f'r100_{i}'] for i in random_counts)-scored['random_min'])<1e-12
            assert abs(max(independent_scores[f'r100_{i}'] for i in random_counts)-scored['random_max'])<1e-12
        for method,summary in data['summary'][task].items():
            values=[data['per_seed'][task][str(seed)]['results'][method] for seed in run.SEEDS]
            assert summary['n']==3
            assert abs(summary['mean']-statistics.mean(values))<1e-12
            assert abs(summary['sample_sd']-statistics.stdev(values))<1e-12
    result=dict(status='PASS',counts=dict(counts),checks=[
        'source/data bindings','disjoint resource-only schedule and completion before resume','fresh output paths','seed/config/clients/rounds',
        'round-by-round development and checkpoint selector','no fit test access',
        'global/stratified/evidence promotion','exact 210 random subsets',
        'seal precedes heldout decode','heldout input hashes','prediction hashes',
        'saved-NPZ independent sklearn AP or grouped macroTop1',
        'sealed policy-to-checkpoint scores including uniform r80',
        'independent random expectation/SD/range arithmetic','three-seed mean and sample SD'])
    run.dump(run.OUT/'validation.json',result)
    print(result)

if __name__=='__main__': main()
