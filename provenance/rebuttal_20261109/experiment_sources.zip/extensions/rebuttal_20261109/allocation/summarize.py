"""Readable tables from a completed, sealed allocation-controls result."""
from pathlib import Path
import json
import statistics

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'results/rebuttal_20261109/allocation'
TASKS=('ptpc_neural','vcc_corrected','norman_double_corrected','tahoe_drug_corrected')
METHODS=(('uniform_80','Uniform (80 rounds)'),
         ('random_promotion_exact','Random promotion (exact expectation)'),
         ('score_only_global','Score-only promotion'),
         ('score_only_stratified','Score-only promotion (LR-stratified)'),
         ('evidence_guided','Score + trajectory (original)'))

def main():
    result=json.loads((OUT/'results.json').read_text())
    assert result['status']=='COMPLETE' and result['independent_rescore']=='PASS'
    lines=['Same-budget allocation controls (retrospective, 2026-11-09)',
        '', 'All scores are metric x100; mean +/- sample SD across training seeds 53, 54, 55.',
        'Columns: Protein AP | VCC Top-1 | Norman Top-1 | Tahoe Top-1.']
    tex=[r'\begin{tabular}{lrrrr}',r'\toprule',
         r'Allocation policy & Protein AP $\uparrow$ & VCC $\uparrow$ & Norman $\uparrow$ & Tahoe $\uparrow$ \\',r'\midrule']
    for method,label in METHODS:
        cells=[]
        for task in TASKS:
            row=result['summary'][task][method]
            cells.append(f'{row["mean"]*100:.2f} $\\pm$ {row["sample_sd"]*100:.2f}')
        lines.append(label+' | '+' | '.join(c.replace('$\\pm$','+/-') for c in cells))
        tex.append(label.replace('+',r'$+$')+' & '+' & '.join(cells)+r' \\')
    tex.extend([r'\bottomrule',r'\end{tabular}'])
    lines.extend(['','All methods: ten training labs and target development panels; same fixed ten-design slate.',
        'Uniform: 10 x80. Promotion: 10 x20 screening +6 x100 restarted validation.',
        'Each policy costs 800 aggregation rounds /160 aggregate development evaluations.',
        'Random promotion is uniform over all C(10,6)=210 subsets, NOT a learning-rate-stratified random rule.',
        'Each subset is evaluated in original slate order. Exact expectation averages selected single-model scores, not predictions.',
        'The displayed random-row SD is across three conditional expectations (training seeds), not random-policy SD.',
        'Per-seed random-policy dispersion and ranges are separately recorded in results.json.',
        'Score-only uses best screening primary then loss; full validation uses the original development selector.',
        'All final choices were sealed before the new held-out reads. These are previously exposed retrospective targets.',
        'No candidate, threshold, split or metric was tuned using the new held-out results.',
        '', 'Paired original score+trajectory minus controls (percentage points):'])
    for task in TASKS:
        lines.append(task)
        for method,label in METHODS[:-1]:
            deltas=[v['results']['evidence_guided']-v['results'][method] for v in result['per_seed'][task].values()]
            w=sum(d>1e-12 for d in deltas);l=sum(d< -1e-12 for d in deltas)
            lines.append(f'  vs {label}: {statistics.mean(deltas)*100:+.4f}; W/T/L {w}/{3-w-l}/{l}')
    training=result['training']
    lines.extend(['',f'New fits: {training["counts"]}; 12 canaries must reproduce historical parameters and development exactly.',
        f'Sum of new fit training seconds: {training["fit_training_seconds"]:.3f}; training-stage wall seconds: {training["wall_seconds"]:.3f}.',
        'Frozen implementation, per-fit checkpoints, development records, selection seal and predictions are retained in this directory.'])
    (OUT/'RESULTS.txt').write_text('\n'.join(lines)+'\n')
    (OUT/'table.tex').write_text('\n'.join(tex)+'\n')
    print('\n'.join(lines))

if __name__=='__main__':main()
