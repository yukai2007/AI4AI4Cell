"""Retrospective same-budget allocation controls using frozen V6 training."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import itertools
import json
import os
from pathlib import Path
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OLD = ROOT / 'extensions/unified_bio_20260918'
BASE = ROOT / 'results/unified_bio_20260918'
OUT = ROOT / 'results/rebuttal_20261109/allocation'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(OLD))
# Identical registration imports execute in spawned workers as in run_v6.
import run_v6
from core_v3 import Federation, fingerprint
from research_v6 import SLATE, proposal, promote
import numpy as np
import torch

TASKS = ('ptpc_neural', 'vcc_corrected', 'norman_double_corrected', 'tahoe_drug_corrected')
SEEDS = (53, 54, 55)

def read(path):
    return json.loads(Path(path).read_text())

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''): h.update(chunk)
    return h.hexdigest()

def dump(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.tmp')
    temp.write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False)+'\n')
    temp.replace(path)

def old_study(task, seed):
    return BASE / task / f'study_v6_seed{seed}'

def old_fit(task, seed, identifier, phase):
    rounds = {'loop_screen':20, 'loop_validation':100, 'direct':80}[phase]
    return old_study(task, seed)/'fits'/f'{phase}_r{rounds}_{fingerprint(proposal(identifier)["config"])[:16]}'

def fit_path(task, seed, identifier):
    old = old_fit(task, seed, identifier, 'loop_validation')
    return old if (old/'fit.json').exists() else OUT/task/f'seed{seed}'/'fits'/identifier

def key(record):
    value = record['best']['development']
    return value['primary'], -value['loss']

def score_promotions(screen):
    global_score = sorted(SLATE, key=lambda i:key(screen[i]), reverse=True)[:6]
    stratified = []
    for group in range(3):
        branch = [i for i in SLATE if i.startswith(f'L{group}')]
        stratified.extend(sorted(branch, key=lambda i:key(screen[i]), reverse=True)[:2])
    return dict(score_only_global=global_score, score_only_stratified=stratified)

def selected(ids, records):
    return max(ids, key=lambda i:key(records[i]))

def preparation():
    if (OUT/'registration.json').exists():
        registration = read(OUT/'registration.json')
        for p,s in registration['bindings'].items():
            if sha(p) != s: raise ValueError('Frozen binding changed: '+p)
        return registration
    bindings = {str(p):sha(p) for p in (HERE/'run.py', OLD/'core.py', OLD/'core_v3.py',
        OLD/'run_v6.py', OLD/'research_v6.py', OLD/'research_v4.py', OLD/'adapters.py',
        OLD/'native_run.py', OLD/'ptpc_neural_adapter.py', OLD/'heldout_v6.py',
        OLD/'heldout_ptpc_neural.py', OLD/'prepare_ptpc_neural.py',
        ROOT/'extensions/federated_bio_20260918/scdebart.py',
        ROOT/'extensions/federated_bio_20260918/engine.py',
        ROOT/'extensions/proteomics/scoring.py',ROOT/'extensions/proteomics/ptpc_model.py')}
    missing = []; canaries = []
    for task in TASKS:
        for seed in SEEDS:
            study = old_study(task,seed); definition=read(study/'definition.json')
            assert definition['slate']==list(SLATE) and definition['clients']==list(range(10))
            assert read(study/'status.json')['status']=='DEVELOPMENT_COMPLETE'
            for name, expected in definition['source_sha256'].items():
                if sha(OLD/name)!=expected: raise ValueError('Original source changed: '+name)
            bindings[str(study/'definition.json')]=sha(study/'definition.json')
            manifest=BASE/task/'data/manifest.json'
            assert sha(manifest)==definition['data_manifest_sha256']
            bindings[str(manifest)]=sha(manifest)
            data=BASE/task/'data'; meta=read(manifest)
            actual=data if task=='ptpc_neural' else Path(meta['data_root'])
            inputs=[actual/f'clients/{c}/{role}.npz' for c in range(10) for role in ('train','dev')]
            if task!='ptpc_neural': inputs += [actual/n for n in ('public_hidden.npy','initial_head.pt','scoring_mask.npy')]
            for p in inputs:
                if str(p) not in bindings: bindings[str(p)]=sha(p)
            for identifier in SLATE:
                for phase in ('direct','loop_screen','loop_validation'):
                    location=old_fit(task,seed,identifier,phase)
                    if phase=='loop_validation' and not (location/'fit.json').exists():
                        missing.append([task,seed,identifier]); continue
                    record=read(location/'fit.json')
                    assert record['config']==proposal(identifier)['config']
                    assert record['seed']==seed and record['clients']==list(range(10))
                    for name in ('fit.json','best.pt'): bindings[str(location/name)]=sha(location/name)
            available=[i for i in SLATE if (old_fit(task,seed,i,'loop_validation')/'fit.json').exists()]
            assert len(available)==6
            canaries.append([task,seed,available[0]])
    assert len(missing)==48 and len(canaries)==12
    registration=dict(schema='allocation-controls-20261109-v1',registered_unix=time.time(),
        tasks=TASKS,seeds=SEEDS,slate=SLATE,bindings=bindings,missing_fits=missing,canaries=canaries,
        protocol=dict(training_labs=list(range(10)),development_panels=list(range(10)),
            screening_rounds=20,screening_candidates=10,validation_rounds=100,promoted_candidates=6,
            restart_from_initialization=True,aggregation_rounds_per_policy=800,
            aggregate_dev_evaluations_per_policy=160,all_random_subsets=210,
            random_policy='Uniform six-subset of ten; validation order is original SLATE order',
            global_score_only='Highest six screening best-primary then lowest loss; SLATE tie order',
            stratified_score_only='Two per learning-rate group by screening best-primary then loss; SLATE tie order',
            selection='Best full-training development primary then lower loss; retain earlier candidate on complete tie',
            canary='Exact historical best parameter arrays, best record and development history before any new candidates',
            inference='All selected unique models scored after global selection seal',
            retrospective=True,no_new_llm_calls=True,all_screening_cost_charged=True))
    dump(OUT/'registration.json',registration)
    return registration

def compare_canary(path,old):
    newrec,oldrec=read(path/'fit.json'),read(old/'fit.json')
    a=torch.load(path/'best.pt',map_location='cpu',weights_only=False)
    b=torch.load(old/'best.pt',map_location='cpu',weights_only=False)
    param_equal=set(a)==set(b) and all(np.array_equal(a[k],b[k]) for k in a)
    dev=lambda r:[x['development'] for x in r['history'] if 'development' in x]
    result=dict(exact_parameters=param_equal,exact_best=newrec['best']==oldrec['best'],
                exact_development=dev(newrec)==dev(oldrec),new_fit_seconds=newrec['training_seconds'],
                max_parameter_difference=max(float(np.max(np.abs(a[k]-b[k]))) for k in a))
    result['status']='PASS' if all(result[k] for k in ('exact_parameters','exact_best','exact_development')) else 'MISMATCH'
    return result

def train():
    registration=preparation()
    gpu=os.environ.get('CUDA_VISIBLE_DEVICES')
    if gpu!='5': raise ValueError('This run is allocated physical GPU 5 only')
    started=time.time(); counts=Counter(); elapsed=[]
    for phase in ('canaries','missing_fits'):
        for task in TASKS:
            jobs=[x for x in registration[phase] if x[0]==task]
            federation=Federation(BASE/task/'data',(0,))
            try:
                for _,seed,identifier in jobs:
                    path=OUT/task/f'seed{seed}'/('canary' if phase=='canaries' else 'fits')/identifier
                    if not (path/'fit.json').exists():
                        if path.exists(): raise RuntimeError('Interrupted fit preserved: '+str(path))
                        federation.fit(proposal(identifier)['config'],list(range(10)),path,seed=seed,rounds=100)
                    record=read(path/'fit.json'); counts[phase]+=1; elapsed.append(record['training_seconds'])
                    if phase=='canaries':
                        verdict=compare_canary(path,old_fit(task,seed,identifier,'loop_validation'))
                        dump(path/'comparison.json',verdict)
                        if verdict['status']!='PASS': raise ValueError('Canary mismatch: '+str(path))
                    dump(OUT/'status.json',dict(status='RUNNING',phase=phase,task=task,seed=seed,
                        design=identifier,counts=dict(counts),training_seconds=sum(elapsed),updated_unix=time.time()))
                    print(json.dumps(dict(phase=phase,task=task,seed=seed,design=identifier,seconds=record['training_seconds'])),flush=True)
            finally: federation.close()
        if phase=='canaries':
            dump(OUT/'canary_summary.json',dict(status='PASS',count=12,all_exact=True,completed_unix=time.time()))
    dump(OUT/'training_complete.json',dict(status='COMPLETE',counts=dict(counts),
        fit_training_seconds=sum(elapsed),wall_seconds=time.time()-started,completed_unix=time.time()))

def make_selection():
    registration=preparation()
    assert read(OUT/'canary_summary.json')['status']=='PASS'
    selections={}; bindings={str(OUT/'registration.json'):sha(OUT/'registration.json')}
    for task in TASKS:
        selections[task]={}
        for seed in SEEDS:
            screen={i:read(old_fit(task,seed,i,'loop_screen')/'fit.json') for i in SLATE}
            records={i:read(fit_path(task,seed,i)/'fit.json') for i in SLATE}
            choices=score_promotions(screen); evidence=read(old_study(task,seed)/'promotion.json')['promoted']
            assert evidence==promote(screen)
            choices['evidence_guided']=evidence
            chosen={name:selected(ids,records) for name,ids in choices.items()}
            random_counts=Counter(selected(subset,records) for subset in itertools.combinations(SLATE,6))
            assert sum(random_counts.values())==210
            oldselected=read(old_study(task,seed)/'selected_development.json')
            assert chosen['evidence_guided']==oldselected['loop_design_id']
            for i in SLATE:
                for name in ('fit.json','best.pt'):
                    p=fit_path(task,seed,i)/name; bindings[str(p)]=sha(p)
            selections[task][str(seed)]=dict(promoted=choices,selected=chosen,
                random_selected_counts=dict(random_counts),uniform_design=oldselected['direct_design_id'],
                uniform_checkpoint=oldselected['direct']['checkpoint'])
    result=dict(schema='allocation-controls-selection-v1',selections=selections,bindings=bindings,
                sealed_unix=time.time(),test_read=False,retrospective=True)
    destination=OUT/'selection_seal.json'
    if destination.exists():
        old=read(destination)
        assert old['selections']==selections and old['bindings']==bindings
        return old
    dump(destination,result)
    return result

def evaluate():
    receipt=read(OUT/'selection_seal.json')
    for p,s in receipt['bindings'].items():
        if sha(p)!=s: raise ValueError('Sealed fit/source changed: '+p)
    import heldout_v6 as heldout
    decoded=time.time(); scored={}; predictions={}; all_source_bindings={}
    device='cpu'
    torch.set_num_threads(2)
    for task in TASKS:
        data=BASE/task/'data'; manifest=read(data/'manifest.json')
        if task=='ptpc_neural':
            source=ROOT/'data/proteomics/ptpc_release_20260911'; querypath=source/'final/final.npz'
        else: source=Path(manifest['data_root']); querypath=source/'test/query.npz'
        all_source_bindings[str(querypath)]=sha(querypath)
        query=heldout.archive(querypath)
        if task=='ptpc_neural': x=heldout.features(query)
        else:
            hidden=np.load(source/'public_hidden.npy',mmap_mode='r')
            initial=torch.load(source/'initial_head.pt',map_location='cpu',weights_only=True)
            mask=np.load(source/'scoring_mask.npy')
        scored[task]={}
        for seed in SEEDS:
            selected_row=receipt['selections'][task][str(seed)]
            used=set(selected_row['selected'].values())|set(selected_row['random_selected_counts'])
            values={}; rows={}
            for identifier in sorted(used):
                location=fit_path(task,seed,identifier); record=read(location/'fit.json')
                if task=='ptpc_neural':
                    model=heldout.Predictor(manifest['n_proteins'],manifest['n_drug_features'],record['config']['residual'])
                else: model=heldout.make_head(initial,record['config'])
                heldout.restore(model,torch.load(location/'best.pt',map_location='cpu',weights_only=False)); model.eval()
                predpath=OUT/task/f'seed{seed}'/'heldout'/f'{identifier}.npz'
                predpath.parent.mkdir(parents=True,exist_ok=True)
                with torch.inference_mode():
                    if task=='ptpc_neural':
                        p=torch.cat([model(c).sigmoid().cpu() for c in torch.as_tensor(x,dtype=torch.float32).split(512)]).numpy()
                        from sklearn.metrics import average_precision_score
                        value=heldout.phenotype_scores(query['y'],p)['ap']
                        assert abs(value-float(average_precision_score(query['y'],p)))<1e-12
                        np.savez_compressed(predpath,probabilities=p,y=query['y'])
                    else:
                        e=heldout.cell_evaluate(model,hidden,query,mask,device,return_rows=True)
                        value=heldout.cell_summary([e])['macro_accuracy']
                        ranks=np.asarray([r['rank'] for r in e['rows']]); ids=np.asarray(query['ids'])
                        independent=float(np.mean([np.mean(ranks[ids==g]==1) for g in np.unique(ids)]))
                        assert abs(value-independent)<1e-12
                        np.savez_compressed(predpath,ranks=ranks,ids=ids)
                values[identifier]=value; rows[identifier]=dict(primary=value,prediction_sha256=sha(predpath))
            original=read(BASE/'heldout_v6'/task/f'seed{seed}'/'results.json')
            evidence=values[selected_row['selected']['evidence_guided']]
            if abs(evidence-original['results']['loop']['primary'])>1e-9:
                raise ValueError('Original evidence-guided heldout differs from independent rerun')
            results={name:values[identifier] for name,identifier in selected_row['selected'].items()}
            results['uniform_80']=original['results']['direct']['primary']
            weights=selected_row['random_selected_counts']
            expectation=sum(values[i]*n/210 for i,n in weights.items())
            variance=sum((values[i]-expectation)**2*n/210 for i,n in weights.items())
            results['random_promotion_exact']=expectation
            scored[task][str(seed)]=dict(results=results,selected=selected_row,scored_models=rows,
                random_policy_sd=variance**.5,random_min=min(values[i] for i in weights),
                random_max=max(values[i] for i in weights))
    summary={}
    for task, seedrows in scored.items():
        summary[task]={}
        for method in next(iter(seedrows.values()))['results']:
            values=[r['results'][method] for r in seedrows.values()]
            summary[task][method]=dict(mean=statistics.mean(values),sample_sd=statistics.stdev(values),n=3)
    payload=dict(schema='allocation-controls-results-v1',status='COMPLETE',summary=summary,
        per_seed=scored,selection_seal_sha256=sha(OUT/'selection_seal.json'),heldout_bindings=all_source_bindings,
        heldout_decoded_unix=decoded,completed_unix=time.time(),independent_rescore='PASS',
        training=read(OUT/'training_complete.json'),protocol=read(OUT/'registration.json')['protocol'])
    dump(OUT/'results.json',payload); dump(OUT/'status.json',dict(status='COMPLETE',updated_unix=time.time()))
    print(json.dumps(summary,indent=2),flush=True)

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('action',choices=('prepare','train','seal','evaluate','all'))
    args=parser.parse_args(); torch.set_num_threads(2)
    if args.action=='prepare': preparation()
    elif args.action=='train': train()
    elif args.action=='seal': make_selection()
    elif args.action=='evaluate': evaluate()
    else: preparation(); train(); make_selection(); evaluate()

if __name__=='__main__': main()
