"""Synchronous CPU transport for the unchanged core_v3 fitting coordinator.

Local update statements follow core_v3.local_worker exactly; device binding and
RPC execution are the only changes. Each task uses two CPU threads in total.
"""
from pathlib import Path
import numpy as np
import torch
from allocation_shared import v1
from core_v3 import state, restore, validate

class CPUFederation(v1.Federation):
    def __init__(self,path):
        from adapters import load_adapter
        torch.set_num_threads(2)
        self.path=Path(path)
        self.adapters={c:load_adapter(self.path,c,'cpu') for c in range(10)}
        self.models={}; self.configs={}

    def rpc(self,clients,requests):
        result=[]
        for client,request in zip(clients,requests):
            adapter=self.adapters[client]
            if request['op']=='init':
                config=validate(request['config']); self.configs[client]=config
                torch.manual_seed(request['seed'])
                model=adapter.model(config).to('cpu'); self.models[client]=model
                response=dict(n=adapter.n_train,initial=state(model),
                    parameter_keys=sorted(dict(model.named_parameters())))
            elif request['op']=='epoch':
                model=self.models[client]; config=self.configs[client]
                restore(model,request['state'])
                anchor={k:p.detach().clone() for k,p in model.named_parameters()}
                model.train()
                optimizer=torch.optim.AdamW(model.parameters(),lr=config['lr'],weight_decay=config['weight_decay'])
                torch.manual_seed(request['seed'])
                order=np.random.default_rng(request['seed']).permutation(adapter.n_train)
                total,examples=0.,0
                for offset in range(0,len(order),request['batch_size']):
                    ids=order[offset:offset+request['batch_size']]
                    loss=adapter.loss(model,ids)
                    if config['prox_mu']:
                        loss=loss+.5*config['prox_mu']*sum((p-anchor[k]).square().sum() for k,p in model.named_parameters())
                    if not torch.isfinite(loss): raise ValueError('Non-finite training objective')
                    optimizer.zero_grad(set_to_none=True); loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(),1.); optimizer.step()
                    total+=float(loss.detach())*len(ids); examples+=len(ids)
                response=dict(state=state(model),n=examples,loss=total/examples)
            elif request['op']=='dev':
                model=self.models[client]; restore(model,request['state']); model.eval()
                with torch.inference_mode(): response=adapter.evaluate(model)
            else: raise ValueError('Unsupported client RPC')
            result.append(response)
        return result

    def close(self):
        self.adapters.clear(); self.models.clear(); self.configs.clear()
