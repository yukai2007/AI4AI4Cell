"""Resource-only parallel executor for not-yet-started whole task-seeds.

The frozen v2 coordinator stays paused during execution and later checks all
fits, finishing its protein jobs and performing the original single seal.
"""
import argparse
from collections import Counter
import os
import time
import torch
import run_v2 as run

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--shard',type=int,choices=(0,1),required=True)
    args=parser.parse_args();torch.set_num_threads(2)
    amendment=run.read(run.OUT/'resource_amendment.json')
    assert run.sha(__file__)==amendment['wrapper_sha256']
    assert run.sha(run.OUT/'registration.json')==amendment['original_registration_sha256']
    run.preparation()
    shard=args.shard;gpu=amendment['gpus'][str(shard)]
    assert os.environ.get('CUDA_VISIBLE_DEVICES')==str(gpu)
    jobs=amendment['jobs'][str(shard)]
    started=time.time();counts=Counter();seconds=[]
    runtime=dict(physical_gpu=gpu,gpu=torch.cuda.get_device_name(0),torch=torch.__version__,
        cuda=torch.version.cuda,amendment_sha256=run.sha(run.OUT/'resource_amendment.json'))
    for task in run.TASKS:
        taskjobs=[(t,s) for t,s in jobs if t==task]
        if not taskjobs:continue
        federation=run.v1.Federation(run.BASE/task/'data',(0,))
        try:
            for _,seed in taskjobs:
                for rounds in (20,80,100):
                    for identifier in run.SLATE:
                        path=run.fit_path(task,seed,identifier,rounds)
                        if path.exists():raise RuntimeError('Resource jobs must be disjoint, not resumed: '+str(path))
                        record=federation.fit(run.proposal(identifier)['config'],list(range(10)),path,seed=seed,rounds=rounds)
                        assert record['rounds']==rounds and len(record['history'])==rounds
                        counts[f'r{rounds}']+=1;seconds.append(record['training_seconds'])
                        status=dict(status='RUNNING',shard=shard,task=task,seed=seed,rounds=rounds,
                            design=identifier,counts=dict(counts),training_seconds=sum(seconds),updated_unix=time.time())
                        run.dump(run.OUT/f'resource_status{shard}.json',status)
                        print(__import__('json').dumps(status),flush=True)
        finally:federation.close()
    assert sum(counts.values())==30*len(jobs)
    completion=dict(status='COMPLETE',runtime=runtime,counts=dict(counts),
        fit_training_seconds=sum(seconds),wall_seconds=time.time()-started,completed_unix=time.time())
    run.dump(run.OUT/f'resource_complete{shard}.json',completion)
    run.dump(run.OUT/f'resource_status{shard}.json',completion)

if __name__=='__main__':main()
