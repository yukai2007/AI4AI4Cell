"""Matched ten-laboratory search controls; freeze development choices before scoring.

Exact random-policy variation is not a training-seed confidence interval.
Existing candidates and agent traces are immutable retrospective measurements.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from datetime import datetime, timezone
from itertools import combinations
import json
import math
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))
from extensions.budget1day_20260923 import contract
from extensions.single_lab_search_20261014 import bayes_search

OUT = ROOT / "results/rebuttal_20261109/search_controls/v2"
TASK_SEEDS = dict(native_tapb=42, ptpc_neural=61, vcc_corrected=61,
                  norman_double_corrected=61, tahoe_drug_corrected=61)
MENU = contract.DESIGNS


def read(path):
    return json.loads(Path(path).read_text())


def freeze(path, value):
    path = Path(path)
    if path.exists():
        if read(path) != value:
            raise ValueError(f"Frozen result differs: {path}")
        return
    contract.dump(path, value)


def score_key(record):
    return record["best"]["development"]["primary"], -record["best"]["development"]["loss"]


def pick(records, ordered_ids):
    return max(ordered_ids, key=lambda k: score_key(records[k]))


def exact_weights(records, budget=6, first=None):
    """Integrate uniform subsets and uniform orders, including exact ties."""
    if first is not None and (first == "D00" or first not in records):
        raise ValueError("First proposal must be a non-baseline menu member")
    prefix = ["D00"] + ([] if first is None else [first])
    remaining = sorted(set(records) - set(prefix))
    draws = budget - int(first is not None)
    if draws < 0 or draws > len(remaining):
        raise ValueError("Invalid random budget")
    mass, subsets = defaultdict(float), 0
    for subset in combinations(remaining, draws):
        subsets += 1
        top = max(score_key(records[k]) for k in prefix + list(subset))
        prefix_winners = [k for k in prefix if score_key(records[k]) == top]
        if prefix_winners:
            mass[prefix_winners[0]] += 1
        else:
            tied = [k for k in subset if score_key(records[k]) == top]
            for key in tied:
                mass[key] += 1 / len(tied)
    return {k: v / subsets for k, v in sorted(mass.items())}, subsets


def binding_sources():
    paths = [HERE / "run.py", HERE / "test_run.py", Path(contract.__file__),
             Path(bayes_search.__file__), ROOT / "extensions/single_lab_search_20261014/protocol.py",
             ROOT / "extensions/core_ablation_20260922/common.py",
             ROOT / "extensions/federated_bio_20260918/engine.py",
             ROOT / "extensions/unified_bio_20260918/heldout_native_tapb.py",
             ROOT / "extensions/unified_bio_20260918/heldout_ptpc_neural.py"]
    return {str(p): contract.sha(p) for p in paths}


def validate_agents(task, seed, records):
    base = ROOT / "results/budget1day_20260923" / task / f"seed{seed}"
    rows, pins = {}, {}
    for backend in ("qwen", "luna"):
        path = base / backend
        for name in ("definition.json", "curves.json", "costs.json", "selected_development.json", "status.json"):
            pins[str(path / name)] = contract.sha(path / name)
        definition, selected = read(path / "definition.json"), read(path / "selected_development.json")
        if (definition["clients"] != list(range(10)) or definition["rounds"] != 100
                or definition["slots"] != 6 or definition["menu"] != MENU
                or read(path / "status.json")["status"] != "COMPLETE"):
            raise ValueError("Incomplete or unmatched agent experiment")
        for source, digest in definition["source_sha256"].items():
            if contract.sha(source) != digest:
                raise ValueError("Old agent source changed")
        curves = read(path / "curves.json")
        for mode in ("direct", "loop"):
            trace = [r for r in curves if r["mode"] == mode]
            if [r["slot"] for r in trace] != list(range(7)):
                raise ValueError("Incomplete agent slots")
            ids = ["D00"]
            for item in trace[1:]:
                if item.get("invalid"):
                    continue
                proposal = item["design"]
                key = proposal["design_id"]
                if key in ids or proposal["config"] != MENU[key]:
                    raise ValueError("Invalid or duplicate proposal")
                if item["candidate"] != records[key]["best"]["development"]:
                    raise ValueError("Agent candidate evidence differs from verified cache")
                ids.append(key)
            chosen = pick(records, ids)
            old = selected[f"{mode}_b6"]
            if old["config"] != MENU[chosen] or old["best"] != records[chosen]["best"]:
                raise ValueError("Agent final choice is not the development maximum")
            if contract.sha(old["checkpoint"]) != contract.sha(records[chosen]["checkpoint"]):
                raise ValueError("Agent checkpoint differs")
            rows[f"{backend}_{mode}"] = dict(design_id=chosen, candidate_ids=ids,
                first_proposal=(trace[1].get("design") or {}).get("design_id"),
                logical_rounds=100 * len(ids), proposal_slots=6,
                invalid_slots=sum(bool(r.get("invalid")) for r in trace[1:]),
                development_curve=[r["incumbent"]["primary"] for r in trace])
        if rows[f"{backend}_direct"]["first_proposal"] != rows[f"{backend}_loop"]["first_proposal"]:
            raise ValueError("Agent cold starts differ")
    return rows, pins


def prepare():
    manifest = dict(schema="biocoloop-ten-lab-search-controls-20261109-v1",
        task_training_seeds=TASK_SEEDS, clients=list(range(10)), menu=MENU,
        rounds_per_candidate=100, initialization="D00", proposal_budget=6,
        random="Uniform without-replacement permutations of D01..D11; exact subset integration including order-sensitive ties",
        random_variance="Exact search-policy SD conditional on one fixed training seed; not training-seed variance or confidence interval",
        first_proposal_sensitivity="Fix each backend's observed shared first proposal, then sample five from remaining ten (252 subsets); if shared first slot failed, retain that failed slot and sample five from all eleven (462 subsets)",
        valid_fit_sensitivity="For each observed agent arm also report random search with its realized valid candidate count, without attributing invalid-slot costs to training",
        bayes="Unchanged 20261014 GP-EI implementation: two Python-random warm starts with task training seed; fixed unit Matern nu2.5; alpha1e-6; normalize_y; EI xi=.01; lexical acquisition ties",
        selection="Maximize equal-client development primary; then minimize development loss; earlier exact ties",
        physical_new_training_fits=0, new_llm_calls=0,
        budget="All searches have D00 plus six 100-round candidates =700 rounds and140 aggregate dev evaluations; invalid agent proposals remain charged slots but may reduce actual fit count",
        role="Retrospective cached-training comparison on previously exposed benchmarks, not independent blind evaluation",
        source_sha256=binding_sources())
    freeze(OUT / "protocol.json", manifest)
    if not (OUT / "registration.json").exists():
        freeze(OUT / "registration.json", dict(protocol_sha256=contract.sha(OUT / "protocol.json"),
             frozen_utc=datetime.now(timezone.utc).isoformat(), heldout_read_by_this_study=False))
    selections, pins = {}, {}
    for task, seed in TASK_SEEDS.items():
        base = ROOT / "results/budget1day_20260923" / task / f"seed{seed}"
        records = {}
        for key, config in MENU.items():
            record, receipt = contract.verify_cache(base, task, seed, config)
            if receipt["status"] != "COMPLETE" or record.get("test_read") is not False:
                raise ValueError("Require complete development-only twelve-candidate grid")
            curve = [r for r in record["history"] if "development" in r]
            if len(record["history"]) != 100 or [r["round"] for r in curve] != list(range(5,101,5)):
                raise ValueError("Incomplete fitting/evaluation budget")
            if max(curve, key=lambda r: (r["development"]["primary"], -r["development"]["loss"])) != record["best"]:
                raise ValueError("Checkpoint was not development selected")
            record["design_id"] = key
            records[key] = record
            for p in (Path(record["cache_receipt"]), Path(record["checkpoint"]), Path(record["checkpoint"]).with_name("fit.json")):
                pins[str(p)] = contract.sha(p)
        agents, agent_pins = validate_agents(task, seed, records)
        pins.update(agent_pins)
        weights, count = exact_weights(records)
        distributions = dict(random_6=dict(weights=weights, subsets=count, first=None))
        for backend in ("qwen", "luna"):
            first = agents[f"{backend}_direct"]["first_proposal"]
            w, n = exact_weights(records, budget=5 if first is None else 6, first=first)
            distributions[f"random_shared_first_{backend}"] = dict(weights=w, subsets=n, first=first,
                shared_failed_first_slot=first is None, logical_rounds=600 if first is None else 700)
        for name, policy in agents.items():
            if policy["invalid_slots"]:
                w, n = exact_weights(records, budget=len(policy["candidate_ids"])-1)
                distributions[f"random_valid_fit_count_{name}"] = dict(weights=w, subsets=n, first=None,
                    logical_rounds=policy["logical_rounds"], matches_realized_valid_fits=name)
        bo_choice, bo_trace, bo_ids = bayes_search.select(MENU, lambda k: records[k], seed)
        agents["gp_ei_6"] = dict(design_id=bo_choice, candidate_ids=bo_ids,
                                 logical_rounds=700, trace=bo_trace, search_seed=seed)
        agents["fixed"] = dict(design_id="D00", candidate_ids=["D00"], logical_rounds=100)
        needed = set(r["design_id"] for r in agents.values())
        for distribution in distributions.values():
            needed.update(distribution["weights"])
        selections[task] = dict(seed=seed, policies=agents, random_distributions=distributions,
            development_grid={k: r["best"]["development"] for k,r in records.items()},
            selected_records={k: records[k] for k in sorted(needed)},
            full_grid_size=12, physical_new_fits=0)
    freeze(OUT / "selections.json", selections)
    freeze(OUT / "selection_seal.json", dict(protocol_sha256=contract.sha(OUT / "protocol.json"),
        selections_sha256=contract.sha(OUT / "selections.json"), input_sha256=pins,
        all_tasks_selected_before_test_read=True))
    return {task: list(v["selected_records"]) for task,v in selections.items()}


def validate_seal():
    seal, manifest = read(OUT / "selection_seal.json"), read(OUT / "protocol.json")
    if (seal["protocol_sha256"] != contract.sha(OUT / "protocol.json")
            or seal["selections_sha256"] != contract.sha(OUT / "selections.json")
            or manifest["source_sha256"] != binding_sources()):
        raise ValueError("Frozen selection or implementation changed")
    for path, digest in seal["input_sha256"].items():
        if contract.sha(path) != digest:
            raise ValueError(f"Bound input changed: {path}")
    return read(OUT / "selections.json")


def find_old_scores(task, selected):
    """Reuse only checkpoint-identical old predictions with valid original seal."""
    seed = TASK_SEEDS[task]
    found = {}
    for backend in ("qwen", "luna"):
        base = ROOT / "results/budget1day_20260923" / task / f"seed{seed}" / backend / "heldout"
        result, seal = read(base / "results.json"), read(base / "seal.json")
        if result["seal_sha256"] != contract.sha(base / "seal.json"):
            raise ValueError("Existing held-out seal changed")
        for key, record in selected.items():
            expected = dict(path=record["checkpoint"], sha256=contract.sha(record["checkpoint"]),
                            config=record["config"], seed=record["seed"])
            for name, bound in seal["checkpoints"].items():
                if bound != expected:
                    continue
                suffix = "npz" if task in ("native_tapb", "ptpc_neural") else "json"
                prediction = base / f"{name}_predictions.{suffix}"
                if prediction.exists():
                    found.setdefault(key, dict(result=result["results"][name], prediction=str(prediction),
                        result_file=str(base / "results.json"), result_sha256=contract.sha(base / "results.json"),
                        prediction_sha256=contract.sha(prediction), reused=True))
    return found


def independent_verify(task, entries):
    import numpy as np
    from sklearn.metrics import average_precision_score, roc_auc_score
    if task == "native_tapb":
        import pandas as pd
        from heldout_native_tapb import LEGACY, DATA_PATH
        target = LEGACY / "third_party/DrugEvolve" / DATA_PATH / "bindingdb/random/test.csv"
        labels = pd.read_csv(target).Y.to_numpy()
    elif task == "ptpc_neural":
        target = ROOT / "data/proteomics/ptpc_release_20260911/final/final.npz"
        with np.load(target) as f:
            labels = f["y"]
    else:
        manifest = read(ROOT / "results/unified_bio_20260918" / task / "data/manifest.json")
        target = Path(manifest["data_root"]) / "test/query.npz"
        with np.load(target, allow_pickle=False) as f:
            query = {k:f[k] for k in ("ids", "choices")}
    verified = {}
    for key, entry in entries.items():
        path = Path(entry["prediction"])
        if contract.sha(path) != entry["prediction_sha256"]:
            raise ValueError("Prediction changed")
        if task in ("native_tapb", "ptpc_neural"):
            with np.load(path, allow_pickle=False) as f:
                probability = f["probability"]
            if probability.shape != labels.shape or not np.isfinite(probability).all():
                raise ValueError("Probability shape/finiteness mismatch")
            primary = float((roc_auc_score if task == "native_tapb" else average_precision_score)(labels, probability))
        else:
            rows = read(path)
            ids = np.asarray([r["intervention"] for r in rows])
            choices = np.asarray([r["choices"] for r in rows])
            scores = np.asarray([r["scores"] for r in rows], dtype=np.float32)
            if not np.array_equal(ids, query["ids"]) or not np.array_equal(choices, query["choices"]):
                raise ValueError("Prediction query identities differ")
            if not np.isfinite(scores).all() or not np.all((choices == ids[:,None]).sum(1) == 1):
                raise ValueError("Invalid scores or true candidate")
            truth = np.argmax(choices == ids[:,None], axis=1)
            rank = np.argmax(np.argsort(-scores, axis=1, kind="stable") == truth[:,None], axis=1) + 1
            if not np.array_equal(rank, [r["rank"] for r in rows]):
                raise ValueError("Stored ranks disagree")
            primary = float(np.mean([np.mean(rank[ids==i] == 1) for i in np.unique(ids)]))
        if abs(primary - entry["result"]["primary"]) > 1e-12:
            raise ValueError(f"Independent primary disagrees: {task}/{key}")
        verified[key] = primary
    return dict(status="PASS", target=str(target), target_sha256=contract.sha(target),
                rescored_primary=verified, tolerance=1e-12)


def evaluate(task, device):
    selections = validate_seal()  # GLOBAL selection pass before any held-out read.
    selected = selections[task]["selected_records"]
    sys.path.insert(0, str(ROOT / "extensions/core_ablation_20260922"))
    import common
    common.torch.set_num_threads(2)
    entries = find_old_scores(task, selected)
    missing = {k:r for k,r in selected.items() if k not in entries}
    if missing:
        directory = OUT / task / "new_heldout"
        result = common.evaluate_selected(task, missing, directory, device)
        if result["seal_sha256"] != contract.sha(directory / "seal.json"):
            raise ValueError("New scorer seal mismatch")
        for key, value in result["results"].items():
            suffix = "npz" if task in ("native_tapb", "ptpc_neural") else "json"
            prediction = directory / f"{key}_predictions.{suffix}"
            entries[key] = dict(result=value, prediction=str(prediction),
                prediction_sha256=contract.sha(prediction), reused=False,
                result_file=str(directory / "results.json"), result_sha256=contract.sha(directory / "results.json"))
    verification = independent_verify(task, entries)
    freeze(OUT / task / "scores.json", dict(task=task, entries=entries,
        verification=verification, selection_seal_sha256=contract.sha(OUT / "selection_seal.json")))
    return dict(task=task, status="PASS", unique_checkpoints=len(entries), new_inferences=len(missing))


def moments(weights, scores):
    mean = sum(weights[k]*scores[k] for k in weights)
    return dict(mean=mean, search_sd=math.sqrt(sum(weights[k]*(scores[k]-mean)**2 for k in weights)))


def report():
    selections = validate_seal()
    result = dict(status="COMPLETE", protocol_sha256=contract.sha(OUT / "protocol.json"), tasks={},
                  uncertainty="Random rows show exact search-policy SD conditional on one training seed; other rows are one trajectory; no training-seed CI",
                  new_training_fits=0, new_llm_calls=0)
    lines = ["Matched ten-laboratory search controls", "", "All metrics ×100. Random ± denotes exact search-policy SD, NOT training-seed uncertainty.",
             "D00 plus six proposals,100 rounds each,10 identical labs/development panels,12-design library.", ""]
    for task, selection in selections.items():
        path = OUT / task / "scores.json"
        payload = read(path)
        if payload["selection_seal_sha256"] != contract.sha(OUT / "selection_seal.json"):
            raise ValueError("Score belongs to another selection")
        primary = payload["verification"]["rescored_primary"]
        row = dict(seed=selection["seed"], policies={}, scores_sha256=contract.sha(path))
        for name, policy in selection["policies"].items():
            row["policies"][name] = dict(primary=primary[policy["design_id"]], design=policy["design_id"],
                development=selection["development_grid"][policy["design_id"]], logical_rounds=policy["logical_rounds"])
        for name, distribution in selection["random_distributions"].items():
            row["policies"][name] = dict(**moments(distribution["weights"], primary),
                development=moments(distribution["weights"], {k:v["primary"] for k,v in selection["development_grid"].items()}),
                subsets=distribution["subsets"], first=distribution["first"], logical_rounds=distribution.get("logical_rounds",700))
        result["tasks"][task] = row
        lines.append(f"{task} (training seed {selection['seed']})")
        for name, p in row["policies"].items():
            score = f"{p['primary']*100:.4f} ({p['design']})" if "primary" in p else f"{p['mean']*100:.4f} ± {p['search_sd']*100:.4f}"
            lines.append(f"  {name}: {score}")
        lines.append("")
    freeze(OUT / "summary.json", result)
    (OUT / "REPORT.txt").write_text("\n".join(lines)+"\n")
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("action", choices=("prepare", "evaluate", "report"))
    p.add_argument("--task", choices=list(TASK_SEEDS))
    p.add_argument("--device", default="cpu")
    args = p.parse_args()
    if args.action == "prepare":
        result = prepare()
    elif args.action == "evaluate":
        if not args.task:
            p.error("--task required")
        result = evaluate(args.task, args.device)
    else:
        result = report()
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
