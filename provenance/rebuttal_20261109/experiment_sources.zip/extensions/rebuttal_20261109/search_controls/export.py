"""Render the sealed matched-access controls; no fitting or selection."""
import csv
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import run


def main():
    result = run.read(run.OUT / "summary.json")
    tasks = list(run.TASK_SEEDS)
    methods = ["fixed", "random_6", "gp_ei_6", "qwen_direct", "qwen_loop", "luna_direct", "luna_loop"]
    names = dict(fixed="Fixed model", random_6="Random search, no replacement", gp_ei_6="GP--EI Bayesian optimization",
        qwen_direct="Qwen: direct search", qwen_loop="Qwen: history-guided search",
        luna_direct="Luna: direct search", luna_loop="Luna: history-guided search")
    rows=[]
    maxima={t:max(p.get("primary",p.get("mean")) for k,p in result["tasks"][t]["policies"].items() if k in methods) for t in tasks}
    for method in methods:
        formatted=[]
        for task in tasks:
            record=result["tasks"][task]["policies"][method]
            number=record.get("primary",record.get("mean"))*100
            cell=f"{number:.2f}"
            if abs(number-maxima[task]*100)<.005:
                cell=r"\textbf{"+cell+"}"
            if "search_sd" in record:
                cell+=r"\,{\scriptsize$\pm$}"+f"{100*record['search_sd']:.2f}"
            formatted.append(cell)
        rows.append(names[method]+" & "+" & ".join(formatted)+r" \\")
    text=r"""\begin{table}[t]
\centering
\caption{\textbf{Matched-access configuration search.} All methods use the same ten laboratories, development panels and 12-design library. Searches receive six proposal slots after the common initialization, with up to 700 aggregation rounds. Scores are multiplied by 100. Random search reports its exact expectation and search-policy standard deviation, integrating all 462 six-element subsets; this is not variation across training seeds.}
\label{tab:rebuttal-matched-search}
\small
\setlength{\tabcolsep}{4pt}
\begin{tabular}{lrrrrr}
\toprule
Method & DTI & Proteomics & VCC & Norman & Tahoe \\
 & AUROC$\uparrow$ & AP$\uparrow$ & Top-1$\uparrow$ & Top-1$\uparrow$ & Top-1$\uparrow$ \\
\midrule
"""+"\n".join(rows)+r"""
\bottomrule
\end{tabular}
\vspace{2pt}
\begin{minipage}{\linewidth}\footnotesize
One frozen training seed per endpoint (42 for DTI; 61 otherwise); agent and GP--EI rows each represent one search trajectory. The fixed reference uses 100 rounds. Failed proposals retain their slots: Qwen history uses 600 fitted rounds on proteomics, and both Qwen arms use 500 on Tahoe; other searches use 700. Matched-realized-fit and shared-first-proposal sensitivities are reported separately. Selection uses development scores only; the comparison reuses checkpoint-identical, fully trained candidates and previously exposed held-out panels. Bold marks the largest displayed mean, not statistical significance.
\end{minipage}
\end{table}
"""
    (run.OUT/"matched_search_table.tex").write_text(text)
    with (run.OUT/"matched_search_table.csv").open("w",newline="") as stream:
        writer=csv.writer(stream)
        writer.writerow(["method","task","training_seed","score_times100","search_sd_times100","logical_fitted_rounds"])
        for task in tasks:
            for method,record in result["tasks"][task]["policies"].items():
                writer.writerow([method,task,run.TASK_SEEDS[task],100*record.get("primary",record.get("mean")),
                    100*record["search_sd"] if "search_sd" in record else "N/A",record["logical_rounds"]])
    selected=run.validate_seal()
    curves={}
    for task,values in selected.items():
        grid={k:dict(best=dict(development=v)) for k,v in values["development_grid"].items()}
        expected=[]
        for budget in range(7):
            weights,_=run.exact_weights(grid,budget=budget)
            expected.append(sum(weights[k]*values["development_grid"][k]["primary"] for k in weights))
        arms={k:dict(values=r["development_curve"],mean_incumbent_slots1to6=sum(r["development_curve"][1:])/6)
              for k,r in values["policies"].items() if "development_curve" in r}
        arms["random_exact"]=dict(values=expected,mean_incumbent_slots1to6=sum(expected[1:])/6)
        curves[task]=arms
    run.freeze(run.OUT/"development_prefix_analysis.json",dict(role="descriptive prefix analysis of unchanged sealed policies; no new selections or training",
        summary_sha256=run.contract.sha(run.OUT/"summary.json"),curves=curves))
    print(json.dumps(dict(status="EXPORTED",directory=str(run.OUT))))


if __name__=="__main__": main()
