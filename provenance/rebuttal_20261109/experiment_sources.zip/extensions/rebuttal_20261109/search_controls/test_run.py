import itertools
import unittest
from collections import Counter
from extensions.rebuttal_20261109.search_controls.run import exact_weights, pick, moments


def records(values):
    return {k:dict(best=dict(development=dict(primary=v[0], loss=v[1]))) for k,v in values.items()}


class ExactRandomTests(unittest.TestCase):
    def test_exact_matches_all_orders_with_ties(self):
        grid=records(dict(D00=(0,1), D01=(2,1), D02=(2,1), D03=(1,0), D04=(0,0)))
        w,n=exact_weights(grid,budget=2)
        counts=Counter(pick(grid,['D00',*order]) for order in itertools.permutations(list(grid)[1:],2))
        self.assertEqual(n,6)
        for k in counts: self.assertAlmostEqual(w[k],counts[k]/12)

    def test_first_retains_full_tie(self):
        grid=records(dict(D00=(0,1),D01=(2,1),D02=(2,1),D03=(1,1)))
        w,n=exact_weights(grid,budget=2,first='D01')
        self.assertEqual(w,dict(D01=1.))
        self.assertEqual(n,2)

    def test_baseline_retains_tie(self):
        grid=records(dict(D00=(2,1),D01=(2,1),D02=(1,0)))
        self.assertEqual(exact_weights(grid,budget=2)[0],dict(D00=1.))

    def test_conditional_matches_permutations(self):
        grid=records({f'D{i:02d}':(i//2,1) for i in range(7)})
        w,n=exact_weights(grid,budget=3,first='D01')
        counts=Counter(pick(grid,['D00','D01',*order]) for order in itertools.permutations(list(grid)[2:],2))
        self.assertEqual(n,10)
        for k in counts: self.assertAlmostEqual(w[k],counts[k]/20)

    def test_twelve_candidate_counts(self):
        grid=records({f'D{i:02d}':(i,1) for i in range(12)})
        self.assertEqual(exact_weights(grid)[1],462)
        self.assertEqual(exact_weights(grid,first='D06')[1],252)
        self.assertAlmostEqual(sum(exact_weights(grid)[0].values()),1.)

    def test_loss_is_only_tiebreak(self):
        grid=records(dict(D00=(2,1),D01=(2,0),D02=(1,-2)))
        self.assertEqual(pick(grid,['D00','D01','D02']),'D01')

    def test_invalid_budget(self):
        grid=records(dict(D00=(2,1),D01=(2,0)))
        with self.assertRaises(ValueError): exact_weights(grid,budget=6)
        with self.assertRaises(ValueError): exact_weights(grid,budget=1,first='D00')

    def test_population_variance_not_seed_sem(self):
        m=moments(dict(D00=.25,D01=.75),dict(D00=0,D01=1))
        self.assertEqual(m['mean'],.75)
        self.assertAlmostEqual(m['search_sd'],(3/16)**.5)


if __name__=='__main__': unittest.main()
