"""Post-hoc development/held-out diagnostics of the frozen 24-proposal study.

CPU inference on existing selected checkpoints only. No training, model selection,
new research calls, or changes to the original protocol are performed. Test scores
are recomputed from archived per-query ranks, not newly generated predictions.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "results/rebuttal_20261109/validation"
TASKS = ("vcc_corrected", "tahoe_drug_corrected")
BACKENDS = ("qwen", "luna")


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 << 20), b""):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


def group_accuracy(rows):
    groups = sorted({int(r["intervention"]) for r in rows})
    return {g: float(np.mean([r["rank"] == 1 for r in rows if int(r["intervention"]) == g])) for g in groups}


def row_metrics(rows):
    values = group_accuracy(rows)
    return dict(macro=float(np.mean(list(values.values()))),
                micro=float(np.mean([r["rank"] == 1 for r in rows])),
                groups=len(values), n=len(rows))


def paired_bootstrap(before, after, repeats=10000):
    a, b = group_accuracy(before), group_accuracy(after)
    if set(a) != set(b):
        raise ValueError("The paired contrast requires identical intervention IDs")
    groups = sorted(a)
    delta = np.array([b[g] - a[g] for g in groups])
    rng = np.random.default_rng(20261109)
    draw = delta[rng.integers(0, len(delta), (repeats, len(delta)))].mean(1)
    return dict(delta_pp=float(delta.mean() * 100),
                interval95_pp=(100 * np.quantile(draw, [.025, .975])).tolist(),
                units=len(groups), unit="intervention, all within-group queries retained",
                posthoc=True, adjusts_for_search=False)


def validate_panel_partition(panels):
    seen = set()
    for q in panels:
        ids = set(map(int, q["ids"]))
        if ids & seen:
            raise ValueError("Development interventions occur in more than one laboratory")
        seen |= ids
        if q["choices"].shape[1] != 5:
            raise ValueError("Expected the original five-option scorer")
        if not np.all((q["choices"] == q["ids"][:, None]).sum(1) == 1):
            raise ValueError("Every roster needs exactly one true intervention")
        if any(len(set(row)) != 5 for row in q["choices"]):
            raise ValueError("Repeated option in roster")
    if not all(set(map(int, q["choices"].ravel())) <= seen for q in panels):
        raise ValueError("Development distractor escaped the development partition")
    return seen


def main():
    if (OUT / "summary.json").exists():
        raise FileExistsError("Preserve the completed diagnostic; do not overwrite")
    OUT.mkdir(parents=True, exist_ok=True)
    sources = {}
    def bind(path, expected=None):
        path = Path(path)
        actual = sha(path)
        if expected is not None and actual != expected:
            raise ValueError(f"Frozen input changed: {path}")
        sources[str(path.relative_to(ROOT))] = actual
        return read(path) if path.suffix == ".json" else None
    save(OUT / "protocol.json", dict(schema="development-diagnostic-v1",
        source_sha256=sha(__file__), tasks=TASKS, seed=61, backends=BACKENDS,
        checkpoints="all original selected prefixes, deduplicated by checkpoint hash",
        training=False, research_calls=False, model_selection=False,
        inference="CPU development only; archived held-out ranks independently rescored",
        metrics=["equal-laboratory macro Top-1", "pooled intervention macro Top-1", "query micro Top-1"],
        intervals="descriptive paired intervention bootstrap; does not adjust for adaptive selection",
        date="2026-11-09"))
    sys.path.insert(0, str(ROOT / "extensions/federated_bio_20260918"))
    import torch
    from engine import evaluate, summarize
    from scdebart import make_head
    torch.set_num_threads(2)
    started = time.time()
    tasks = {}
    for task in TASKS:
        manifest = bind(ROOT / f"results/unified_bio_20260918/{task}/data/manifest.json")
        data = Path(manifest["data_root"])
        data_manifest = bind(data / "manifest.json")
        panels = []
        for client in range(10):
            path = data / f"clients/{client}/dev.npz"
            bind(path)
            with np.load(path) as f:
                panels.append(dict(f))
        dev_ids = validate_panel_partition(panels)
        train_ids = set(map(int, data_manifest["train"]))
        test_ids = set(map(int, data_manifest["test"]))
        if dev_ids != set(map(int, data_manifest["dev"])) or dev_ids & test_ids or dev_ids & train_ids or train_ids & test_ids:
            raise ValueError("The declared intervention roles are not disjoint")
        for name in ("public_hidden.npy", "initial_head.pt", "scoring_mask.npy"):
            bind(data / name)
        hidden = np.load(data / "public_hidden.npy", mmap_mode="r")
        initial = torch.load(data / "initial_head.pt", map_location="cpu", weights_only=True)
        mask = np.load(data / "scoring_mask.npy")
        root = ROOT / f"results/core_ablation_20260922/model_loop/{task}/seed61"
        definition = bind(root / "definition.json")
        cached, selections, test_rows = {}, {}, {}
        for backend in BACKENDS:
            folder = root / backend
            selected = bind(folder / "selected_development.json")
            seal = bind(folder / "heldout/seal.json")
            heldout = bind(folder / "heldout/results.json")
            if heldout["seal_sha256"] != sha(folder / "heldout/seal.json"):
                raise ValueError("Original held-out seal identity changed")
            selections[backend] = {}
            test_rows[backend] = {}
            for name, selection in selected.items():
                checkpoint = Path(selection["checkpoint"])
                record = seal["checkpoints"][name]
                if record["path"] != str(checkpoint) or record["config"] != selection["config"]:
                    raise ValueError("Selection differs from original sealed checkpoint")
                bind(checkpoint, record["sha256"])
                digest = record["sha256"]
                if digest not in cached:
                    model = make_head(initial, selection["config"]).eval()
                    state = torch.load(checkpoint, map_location="cpu", weights_only=False)
                    model.load_state_dict({k: torch.from_numpy(v.copy()) for k, v in state.items()}, strict=True)
                    evidence = [evaluate(model, hidden, q, mask, "cpu", return_rows=True) for q in panels]
                    panel_metrics = [summarize([e]) for e in evidence]
                    rows = [r for e in evidence for r in e["rows"]]
                    equal = float(np.mean([m["macro_accuracy"] for m in panel_metrics]))
                    loss = float(np.mean([m["cross_entropy"] for m in panel_metrics]))
                    reference = selection["best"]["development"]
                    if abs(equal-reference["primary"]) > 1e-10 or abs(loss-reference["loss"]) > 2e-6:
                        raise ValueError(f"CPU development reproduction mismatch {task} {name}: {equal},{loss} vs {reference}")
                    cached[digest] = dict(checkpoint=str(checkpoint), config=selection["config"],
                        round=selection["best"]["round"], train_loss=selection["best"]["train_loss"],
                        equal_lab_macro=equal, equal_lab_loss=loss, **row_metrics(rows),
                        panels=[dict(client=c, **metrics) for c, metrics in enumerate(panel_metrics)],
                        original_development=reference, rows=rows)
                    save(OUT / task / f"development_{digest}.json", cached[digest])
                    print(task, "reproduced", checkpoint.parent.name, equal, flush=True)
                predictions = bind(folder / f"heldout/{name}_predictions.json")
                metric = row_metrics(predictions)
                if abs(metric["macro"] - heldout["results"][name]["primary"]) > 1e-12:
                    raise ValueError("Archived held-out independent rescore disagrees")
                if set(group_accuracy(predictions)) != test_ids:
                    raise ValueError("Archived held-out response IDs disagree with split manifest")
                if not all(set(r["choices"]) <= test_ids and len(set(r["choices"])) == 5 for r in predictions):
                    raise ValueError("Held-out options do not match the disjoint five-option role")
                test_rows[backend][name] = predictions
                selections[backend][name] = dict(checkpoint_sha256=digest,
                    development_equal_lab=cached[digest]["equal_lab_macro"],
                    development_pooled_macro=cached[digest]["macro"],
                    development_micro=cached[digest]["micro"], heldout=metric,
                    config=selection["config"], best_round=selection["best"]["round"],
                    train_loss=selection["best"]["train_loss"])
        contrasts=[]
        for backend in BACKENDS:
            for mode in ("direct", "loop"):
                initial_record=selections[backend][f"{mode}_b0"]
                final_record=selections[backend][f"{mode}_b24"]
                initial_dev=cached[initial_record["checkpoint_sha256"]]["rows"]
                final_dev=cached[final_record["checkpoint_sha256"]]["rows"]
                contrasts.append(dict(backend=backend, mode=mode,
                    development=paired_bootstrap(initial_dev,final_dev),
                    heldout=paired_bootstrap(test_rows[backend][f"{mode}_b0"],test_rows[backend][f"{mode}_b24"])))
        tasks[task] = dict(seed=61, menu_size=len(definition["menu"]), slots=definition["slots"],
            unique_selected_checkpoints=len(cached), chance=0.2,
            train_groups=len(train_ids), dev_groups=len(dev_ids), test_groups=len(test_ids),
            dev_queries=sum(len(q["ids"]) for q in panels),
            panel_sizes=[dict(client=c,n_queries=len(q["ids"]), n_interventions=len(set(q["ids"]))) for c,q in enumerate(panels)],
            partition_rule="whole intervention groups; original disjoint train/dev/test roles; train/dev round-robin assignment to ten clients",
            roster_rule="five distinct role-local options; true intervention once, four distractors; frozen shuffled option order",
            selectors=selections, contrasts=contrasts,
            aggregation_diagnostic="The ten development panels have equal intervention counts (VCC: two; Tahoe: six): equal-client macro equals pooled intervention macro exactly; query micro is a different estimand.")
    summary=dict(status="COMPLETE", tasks=tasks, source_sha256=sources, new_training_fits=0,
                 new_llm_calls=0, development_checkpoint_evaluations=sum(t["unique_selected_checkpoints"] for t in tasks.values()),
                 new_heldout_inference=False, seconds=time.time()-started,
                 interpretation="Retrospective diagnosis, not a new validation split or causal attribution. Bootstrap intervals do not adjust for selection or model search.")
    save(OUT / "summary.json",summary)
    print(json.dumps({"status":"COMPLETE","seconds":summary["seconds"]},indent=2))


if __name__ == "__main__":
    main()
