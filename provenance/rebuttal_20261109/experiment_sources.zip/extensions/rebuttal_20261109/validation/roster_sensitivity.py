"""Development-only randomized-roster sensitivity of already fixed endpoints.

No model fitting or model selection. Twenty newly frozen roster RNG seeds are
paired across the initial model and all original 24-slot final models. These are
not independent training seeds, new interventions, or new biological splits.
"""
from pathlib import Path
import sys
import time
import numpy as np

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from diagnose import ROOT, read, save, sha, group_accuracy

SEEDS=tuple(range(2026110900,2026110920))
OUT=ROOT/"results/rebuttal_20261109/validation/roster_sensitivity"


def roster(ids, seed):
    ids=np.array(sorted(set(map(int,ids))),dtype=np.int64)
    rng=np.random.default_rng(seed)
    return {int(g):rng.permutation(np.r_[g,rng.choice(ids[ids!=g],4,replace=False)]).tolist() for g in ids}


def macro_accuracy(similarity, candidate_ids, query_ids, choices):
    lookup={int(g):i for i,g in enumerate(candidate_ids)}
    columns=np.array([[lookup[int(g)] for g in choice] for choice in choices])
    values=np.take_along_axis(similarity,columns,axis=1)
    chosen=np.argmax(values,axis=1)
    correct=np.array([int(choices[i][j])==int(query_ids[i]) for i,j in enumerate(chosen)])
    return float(np.mean([correct[query_ids==g].mean() for g in np.unique(query_ids)]))


def main():
    if OUT.exists():raise FileExistsError("Retain the completed/frozen roster study")
    OUT.mkdir(parents=True)
    save(OUT/"protocol.json",dict(schema="development-roster-sensitivity-v1",date="2026-11-09",
        seeds=SEEDS,source_sha256=sha(__file__), scope="fixed D00 and original final24 endpoints; VCC/Tahoe seed61",
        perturbation="resample four distinct wrong options from the same development role; retain truth once; shuffle five positions",
        pairing="one roster per true intervention shared across its queries and all models",
        no_new_training=True,no_model_selection=True,no_test_response_read=True,
        independent_units="roster draws, not independent models/interventions/splits",
        outputs="mean/sample SD of paired final-minus-initial development macro Top1 across 20 roster draws"))
    sys.path.insert(0,str(ROOT/"extensions/federated_bio_20260918"))
    import torch
    from scdebart import make_head
    torch.set_num_threads(2)
    sources={}
    def bind(path,expected=None):
        path=Path(path);value=sha(path)
        if expected and value!=expected:raise ValueError(f"Changed source: {path}")
        sources[str(path.relative_to(ROOT))]=value
        return read(path) if path.suffix==".json" else None
    tasks={};start=time.time()
    for task in ("vcc_corrected","tahoe_drug_corrected"):
        manifest=bind(ROOT/f"results/unified_bio_20260918/{task}/data/manifest.json")
        data=Path(manifest["data_root"])
        panels=[]
        for c in range(10):
            path=data/f"clients/{c}/dev.npz";bind(path)
            with np.load(path) as f:panels.append(dict(f))
        query_ids=np.concatenate([p["ids"] for p in panels])
        observed=np.concatenate([p["y"] for p in panels])
        original_choices=np.concatenate([p["choices"] for p in panels])
        candidate_ids=np.unique(query_ids)
        mask=np.load(data/"scoring_mask.npy")
        observed=observed[:,mask]
        observed=observed/np.maximum(np.linalg.norm(observed,axis=1,keepdims=True),1e-12)
        hidden=np.load(data/"public_hidden.npy",mmap_mode="r")
        initial=torch.load(data/"initial_head.pt",map_location="cpu",weights_only=True)
        for filename in ("scoring_mask.npy","public_hidden.npy","initial_head.pt"):bind(data/filename)
        generated={seed:roster(candidate_ids,seed) for seed in SEEDS}
        choices_by_seed={seed:np.array([generated[seed][int(g)] for g in query_ids]) for seed in SEEDS}
        save(OUT/f"{task}_rosters.json",generated)
        cache={};models={}
        for backend in ("qwen","luna"):
            folder=ROOT/f"results/core_ablation_20260922/model_loop/{task}/seed61/{backend}"
            selected=bind(folder/"selected_development.json")
            seal=bind(folder/"heldout/seal.json") # identities only; no outcomes or test responses
            for mode in ("direct","loop"):
                for prefix in (0,24):
                    name=f"{mode}_b{prefix}";item=selected[name];identity=seal["checkpoints"][name]
                    path=Path(item["checkpoint"]);digest=identity["sha256"];bind(path,digest)
                    if digest not in cache:
                        model=make_head(initial,item["config"]).eval()
                        state=torch.load(path,map_location="cpu",weights_only=False)
                        model.load_state_dict({k:torch.from_numpy(v.copy()) for k,v in state.items()},strict=True)
                        predictions=[]
                        with torch.inference_mode():
                            for g in candidate_ids:
                                value=model(torch.tensor(np.array(hidden[int(g)],dtype=np.float32))).numpy()[mask]
                                predictions.append(value/max(float(np.linalg.norm(value)),1e-12))
                        # Preserve original scorer's per-row dot product and float32 accumulation.
                        similarity=np.array([[obs @ pred for pred in predictions] for obs in observed])
                        original=macro_accuracy(similarity,candidate_ids,query_ids,original_choices)
                        if abs(original-item["best"]["development"]["primary"])>1e-10:
                            raise ValueError("Vectorized sensitivity scorer differs from original macro scorer")
                        cache[digest]=dict(original=original,scores={seed:macro_accuracy(similarity,candidate_ids,query_ids,ch)
                                                                   for seed,ch in choices_by_seed.items()})
                    models[f"{backend}_{name}"]=dict(checkpoint_sha256=digest,**cache[digest])
        contrasts=[]
        for backend in ("qwen","luna"):
            for mode in ("direct","loop"):
                a=models[f"{backend}_{mode}_b0"];b=models[f"{backend}_{mode}_b24"]
                delta=np.array([100*(b["scores"][s]-a["scores"][s]) for s in SEEDS])
                contrasts.append(dict(backend=backend,mode=mode,original_delta_pp=100*(b["original"]-a["original"]),
                    resampled_mean_delta_pp=float(delta.mean()),resampled_sample_sd_pp=float(delta.std(ddof=1)),
                    positive=int((delta>1e-10).sum()),tied=int((abs(delta)<=1e-10).sum()),negative=int((delta < -1e-10).sum()),
                    per_roster_delta_pp=delta.tolist(),initial_mean=float(np.mean(list(a["scores"].values()))),
                    final_mean=float(np.mean(list(b["scores"].values())))))
        tasks[task]=dict(models=models,contrasts=contrasts,development_groups=len(candidate_ids),
                         development_queries=len(query_ids),unique_checkpoints=len(cache))
        print(task,"COMPLETE",contrasts,flush=True)
    save(OUT/"summary.json",dict(status="COMPLETE",tasks=tasks,seeds=SEEDS,source_sha256=sources,
        seconds=time.time()-start,new_training_fits=0,new_test_inference=False,new_llm_calls=0,
        limitation="Post-hoc roster sensitivity of fixed models on the same development interventions; not a new split or causal attribution."))


if __name__=="__main__":main()
