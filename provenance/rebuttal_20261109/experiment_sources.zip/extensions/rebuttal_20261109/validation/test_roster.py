import sys
from pathlib import Path
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from roster_sensitivity import roster, macro_accuracy, SEEDS

class RosterTests(unittest.TestCase):
    def test_frozen_twenty_seeds(self):
        self.assertEqual(SEEDS,tuple(range(2026110900,2026110920)))
    def test_no_duplicate_truth_once(self):
        for g,options in roster(range(20),42).items():
            self.assertEqual(len(options),5);self.assertEqual(len(set(options)),5)
            self.assertEqual(options.count(g),1);self.assertTrue(set(options)<=set(range(20)))
    def test_reproducible(self):
        self.assertEqual(roster(range(20),12),roster(range(20),12))
        self.assertNotEqual(roster(range(20),12),roster(range(20),13))
    def test_macro_and_stable_ties(self):
        ids=np.arange(5);queries=np.array([0,1,1]);choices=np.tile(ids,(3,1))
        self.assertEqual(macro_accuracy(np.zeros((3,5)),ids,queries,choices),.5)
    def test_perfect(self):
        ids=np.arange(10);options=roster(ids,9);choices=np.array([options[g] for g in ids])
        self.assertEqual(macro_accuracy(np.eye(10),ids,ids,choices),1.)

if __name__=="__main__":unittest.main()
