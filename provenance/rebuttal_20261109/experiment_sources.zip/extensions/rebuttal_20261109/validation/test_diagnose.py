import unittest
import numpy as np
from extensions.rebuttal_20261109.validation.diagnose import group_accuracy, row_metrics, paired_bootstrap, validate_panel_partition


class ValidationTests(unittest.TestCase):
    def test_macro_not_micro(self):
        rows=[dict(intervention=1,rank=1)] + [dict(intervention=2,rank=2)]*3
        self.assertEqual(row_metrics(rows)["macro"],.5)
        self.assertEqual(row_metrics(rows)["micro"],.25)

    def test_equal_panel_macro_matches_pooled_when_group_counts_equal(self):
        a=[dict(intervention=i,rank=r) for i,r in [(1,1),(1,2),(2,2)]]
        b=[dict(intervention=i,rank=r) for i,r in [(3,1),(4,2),(4,2)]]
        self.assertEqual(np.mean([row_metrics(a)["macro"],row_metrics(b)["macro"]]),row_metrics(a+b)["macro"])

    def test_paired_identity(self):
        rows=[dict(intervention=i,rank=i%2+1) for i in range(20)]
        result=paired_bootstrap(rows,rows,100)
        self.assertEqual(result["interval95_pp"],[0.,0.])

    def test_paired_different_ids_rejected(self):
        with self.assertRaises(ValueError):
            paired_bootstrap([dict(intervention=1,rank=1)],[dict(intervention=2,rank=1)])

    def test_original_five_options(self):
        q=dict(ids=np.arange(5),choices=np.tile(np.arange(5),(5,1)))
        self.assertEqual(validate_panel_partition([q]),set(range(5)))
        with self.assertRaises(ValueError):
            validate_panel_partition([q,q])

    def test_duplicate_choices_rejected(self):
        q=dict(ids=np.array([0]),choices=np.array([[0,1,1,2,3]]))
        with self.assertRaises(ValueError):validate_panel_partition([q])


if __name__=="__main__":unittest.main()
