import sys
from pathlib import Path
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from prefix_audit import incumbent_weights, weighted, direction_event, validate_scored_primary


class PrefixTests(unittest.TestCase):
    def test_earliest_tie(self):
        grid = {k: {"development":{"primary": .3, "loss":1.}} for k in ("D00","D01")}
        self.assertEqual(incumbent_weights(grid, ["D00","D01"]), {"D00":1.})

    def test_loss_breaks_primary_tie(self):
        grid = {"D00":{"development":{"primary":.3,"loss":1.}},
                "D01":{"development":{"primary":.3,"loss":.8}}}
        self.assertEqual(incumbent_weights(grid, ["D00","D01"]), {"D01":1.})

    def test_test_metrics_not_used(self):
        grid = {"D00":{"development":{"primary":.3,"loss":1.},"heldout":.1},
                "D01":{"development":{"primary":.2,"loss":.8},"heldout":.9}}
        self.assertEqual(incumbent_weights(grid, ["D00","D01"]), {"D00":1.})

    def test_invalid_probability(self):
        with self.assertRaises(ValueError):
            weighted({"D00":.2}, {"D00":.3})

    def test_finite_policy_expectation(self):
        self.assertAlmostEqual(weighted({"A":.25,"B":.75}, {"A":.4,"B":.8}), .7)

    def test_local_direction(self):
        self.assertTrue(direction_event({"development":.2,"heldout":.4},
                                        {"development":.3,"heldout":.3})["development_up_test_down"])
        self.assertFalse(direction_event({"development":.2,"heldout":.4},
                                         {"development":.2,"heldout":.3})["development_up_test_down"])

    def test_equal_context_macro(self):
        score = {"primary":.5, "per_gene":[{"gene":"a","context":"x","top1":1.},
                 {"gene":"b","context":"y","top1":0.}, {"gene":"c","context":"y","top1":0.}]}
        validate_scored_primary(score)
        score["primary"] = 1/3
        with self.assertRaises(ValueError):
            validate_scored_primary(score)


if __name__ == "__main__":
    unittest.main()
