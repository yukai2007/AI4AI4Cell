"""Audit every frozen search prefix against already evaluated checkpoints.

This is a post-hoc diagnostic, not a selector or a new experiment. It never
reads expression arrays, trains a model, invokes a researcher, or chooses a
prefix with held-out evidence. All methods and seeds are retained.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from extensions.history_repair_20261109.controls import exact_random_weights, score_key

SEARCH = ROOT / "results/history_repair_20261109/search_genetic_v3"
TRAIN = ROOT / "results/history_repair_20261109/training_genetic_v1"
TEST = ROOT / "results/history_repair_20261109/training_heldout_genetic_v1"
OUT = ROOT / "results/fbhk_followup_20261109/validation"
FIG = ROOT / "paper/figures/fbhk_followup_20261109"
SEEDS = (61, 62, 63)
POLICIES = ("fixed", "direct", "raw", "structured", "random", "random_shared_first", "gp_ei")
LABELS = dict(fixed="Fixed design", direct="Direct", raw="Raw history", structured="Structured history",
              random="Random", random_shared_first="Random (shared first)", gp_ei="GP-EI")
EPS = 1e-12


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def mean_sd(values):
    return dict(mean=statistics.mean(values), sample_sd=statistics.stdev(values))


def weighted(weights, values):
    if abs(sum(weights.values())-1) > EPS or any(v < 0 for v in weights.values()):
        raise ValueError("Invalid policy distribution")
    return math.fsum(weights[k]*values[k] for k in weights)


def incumbent_weights(grid, ids):
    """Only development primary/loss select; earliest complete ties persist."""
    if not ids or ids[0] != "D00" or len(ids) != len(set(ids)):
        raise ValueError("Invalid tried candidate list")
    winner = max(ids, key=lambda k: score_key({"development": {m:grid[k]["development"][m] for m in ("primary","loss")}}))
    return {winner: 1.}


def direction_event(before, after):
    return dict(development_gain_pp=100*(after["development"]-before["development"]),
                heldout_gain_pp=100*(after["heldout"]-before["heldout"]),
                development_up_test_down=after["development"] > before["development"]+EPS
                and after["heldout"] < before["heldout"]-EPS)


def aggregate_rows(rows):
    result = []
    for policy in POLICIES:
        for slot in range(7):
            items = [r for r in rows if r["policy"] == policy and r["slot"] == slot]
            if sorted(r["seed"] for r in items) != list(SEEDS):
                raise ValueError("Missing or repeated seeds")
            result.append(dict(policy=policy, slot=slot,
                               **{m: mean_sd([r[m] for r in items]) for m in ("development", "heldout")}))
    return result


def validate_scored_primary(score):
    rows = score["per_gene"]
    contexts = sorted({r["context"] for r in rows})
    if len({(r["context"], r["gene"]) for r in rows}) != len(rows):
        raise ValueError("Duplicated gene-context observation")
    recomputed = statistics.mean(statistics.mean(r["top1"] for r in rows if r["context"] == context)
                                 for context in contexts)
    if abs(recomputed-score["primary"]) > EPS:
        raise ValueError("Scored equal-context primary cannot be reproduced")


def build():
    sources = {}
    def bind(path, expected=None):
        digest = sha(path)
        if expected is not None and expected != digest:
            raise ValueError(f"Source changed: {path}")
        sources[str(path.relative_to(ROOT))] = digest
        return read(path)

    protocol = bind(SEARCH / "protocol.json")
    report = bind(TEST / "policy_report.json")
    heldout_protocol = bind(TEST / "protocol.json", report["protocol_sha256"])
    verification = bind(TEST / "verification.json")
    if verification["status"] != "PASS":
        raise ValueError("Prior independent test verification did not pass")
    rows, context_rows, events, correlation = [], [], [], []
    for seed in SEEDS:
        base = SEARCH / f"seed{seed}"
        seal = bind(base / "selection_seal.json")
        if seal["heldout_evaluation_read"] is not False or seal["protocol_sha256"] != sha(SEARCH / "protocol.json"):
            raise ValueError("Invalid original selection seal")
        grid = bind(TRAIN / f"seed{seed}/development_grid.json", seal["grid_sha256"])
        selections = bind(base / "selections.json", seal["selections_sha256"])
        controls = bind(base / "controls.json", seal["controls_sha256"])
        scores = {}
        for design in sorted(grid):
            path = TEST / f"scores/seed{seed}/{design}.json"
            scored = bind(path, report["score_sha256"][str(path)])
            if scored["checkpoint_sha256"] != grid[design]["checkpoint_sha256"] or scored["selected_using"] != "development only; frozen before test expression access":
                raise ValueError("Scored checkpoint identity/selection differs")
            if scored["protocol_sha256"] != sha(TEST / "protocol.json"):
                raise ValueError("Score protocol differs")
            scores[design] = scored["heldout"]
            validate_scored_primary(scores[design])
        prefix = {policy: [] for policy in POLICIES}
        for policy in ("direct", "raw", "structured"):
            tried = ["D00"]
            prefix[policy].append(incumbent_weights(grid, tried))
            for slot in range(1, 7):
                path = base / policy / f"slot{slot}.json"
                record = bind(path, seal["transcript_sha256"][str(path.relative_to(ROOT))])
                request = record["request"]
                if request["valid"]:
                    tried.append(request["parsed"]["design_id"])
                distribution = incumbent_weights(grid, tried)
                selected = next(iter(distribution))
                reference = selections[policy]["prefix_development"][slot]
                if any(abs(grid[selected]["development"][m]-reference[m]) > EPS for m in ("primary", "loss")):
                    raise ValueError("Reconstructed prefix differs from sealed development prefix")
                prefix[policy].append(distribution)
            if tried != selections[policy]["candidate_ids"] or next(iter(prefix[policy][-1])) != selections[policy]["design_id"]:
                raise ValueError("Final selection mismatch")
        first = bind(base / "shared_first.json")["parsed"]["design_id"]
        selection_grid = {k: {"development": {m:v["development"][m] for m in ("primary","loss")}} for k,v in grid.items()}
        for slot in range(7):
            prefix["fixed"].append({"D00": 1.})
            prefix["gp_ei"].append(incumbent_weights(grid, controls["gp_ei"]["candidate_ids"][:slot+1]))
            prefix["random"].append(exact_random_weights(selection_grid, slot)[0])
            prefix["random_shared_first"].append(exact_random_weights(selection_grid, slot, first if slot else None)[0])
        for policy in POLICIES:
            for slot, distribution in enumerate(prefix[policy]):
                row = dict(seed=seed, policy=policy, slot=slot, selected_weights=distribution,
                    development=weighted(distribution, {k: v["development"]["primary"] for k, v in grid.items()}),
                    heldout=weighted(distribution, {k: v["primary"] for k, v in scores.items()}))
                row["development_gain_vs_fixed_pp"] = 100*(row["development"]-grid["D00"]["development"]["primary"])
                row["heldout_gain_vs_fixed_pp"] = 100*(row["heldout"]-scores["D00"]["primary"])
                rows.append(row)
                if slot:
                    events.append(dict(seed=seed, policy=policy, slot=slot, **direction_event(rows[-2], row)))
            if policy in report["policies"]:
                expected = next(x for x in report["policies"][policy]["per_seed"] if x["seed"] == seed)["primary"]
                if abs(rows[-1]["heldout"]-expected) > EPS:
                    raise ValueError(f"Policy-report endpoint mismatch: {seed}/{policy}")
            for context in sorted(scores["D00"]["per_context"]):
                distribution = prefix[policy][-1]
                context_rows.append(dict(seed=seed, policy=policy, context=context,
                    development=weighted(distribution, {k:v["development"]["per_context"][context]["primary"] for k,v in grid.items()}),
                    heldout=weighted(distribution, {k:v["per_context"][context]["primary"] for k,v in scores.items()})))
        from scipy.stats import spearmanr
        rank = spearmanr([grid[k]["development"]["primary"] for k in sorted(grid)],
                         [scores[k]["primary"] for k in sorted(grid)])
        correlation.append(dict(seed=seed, candidates=len(grid), spearman=float(rank.statistic),
            description="Descriptive across 16 already-trained candidates; not independent biological replicates"))
    aggregate = aggregate_rows(rows)
    return dict(schema="fbhk-prefix-audit-v1", source_sha256=sha(Path(__file__)), status="COMPLETE",
        scope="Post-hoc frozen-selection diagnostic of already scored models; no new training, generation or held-out access",
        selection="Original development primary, then lower development loss, earliest complete ties; never choose a prefix by held-out score",
        endpoint="Equal-context within-context gene-macro Top-1",
        uncertainty="Mean +/- sample SD of three paired training/controller seeds, not confidence intervals",
        random="Exact expectation of development-selected single predictors at each prefix; not an ensemble or a single sequential trajectory",
        source_sha256s=sources, per_seed=rows, aggregate=aggregate, local_events=events,
        development_up_test_down_events=[e for e in events if e["development_up_test_down"]],
        heldout_below_initial=[r for r in rows if r["heldout_gain_vs_fixed_pp"] < -1e-10],
        final_per_context=context_rows, candidate_rank_correlation=correlation,
        changes_from_original="Larger gene-disjoint groups, four study-context clients, five fixed rosters per gene/context, 512 training-selected response genes, altered training/candidate library; bundled changes do not isolate a repair cause")


def figures(result):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    plt.rcParams.update({"font.family":"DejaVu Sans", "font.size":8, "axes.titlesize":10,
                         "pdf.fonttype":42, "ps.fonttype":42, "svg.fonttype":"none"})
    styles = {"fixed":("#555555", "--", None), "direct":("#0072B2", "-", "o"),
        "raw":("#E69F00", ":", "x"), "structured":("#D55E00", "-", "s"),
        "random":("#009E73", "--", None), "random_shared_first":("#999999", ":", None),
        "gp_ei":("#8E5EA2", "-.", "^")}
    fig, axes = plt.subplots(1, 2, figsize=(7.25,3.25), sharex=True, sharey=True)
    for axis, metric, title in zip(axes, ("development","heldout"), ("(a) Development selection", "(b) Held-out evaluation")):
        for policy in POLICIES:
            row = [r for r in result["aggregate"] if r["policy"] == policy]
            y = np.array([r[metric]["mean"] for r in row])*100
            sd = np.array([r[metric]["sample_sd"] for r in row])*100
            color, line, marker = styles[policy]
            axis.plot(range(7), y, label=LABELS[policy], color=color, ls=line, marker=marker,
                      linewidth=1.6, markersize=3.5, zorder=3 if policy in ("structured","raw") else 2)
            axis.fill_between(range(7), y-sd, y+sd, color=color, alpha=.055, linewidth=0)
        axis.set_title(title, loc="left")
        axis.set_xlabel("Proposal requests after the initial design")
        axis.set_xticks(range(7))
        axis.grid(axis="y", alpha=.2, linewidth=.6)
        axis.spines[["top","right"]].set_visible(False)
    axes[0].set_ylabel("Top-1 accuracy (%)")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=4, frameon=False, fontsize=7.3,
               bbox_to_anchor=(.5,.005), handlelength=2, columnspacing=1.2)
    fig.subplots_adjust(left=.08,right=.985,top=.89,bottom=.29,wspace=.12)
    FIG.mkdir(parents=True, exist_ok=True)
    for ext in ("pdf","svg","png"):
        fig.savefig(FIG / f"history_prefix_dev_test.{ext}", dpi=200, metadata={"Creator":"BioCoLoop prefix audit"} if ext == "pdf" else None)
    plt.close(fig)


def main():
    result = build()
    save(OUT / "prefix_audit.json", result)
    OUT.mkdir(parents=True, exist_ok=True)
    for name, records in (("prefix_per_seed",result["per_seed"]), ("local_direction_events",result["local_events"]),
                          ("final_per_context",result["final_per_context"])):
        fields = [k for k in records[0] if k != "selected_weights"]
        with (OUT / f"{name}.csv").open("w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(records)
    figures(result)
    print(json.dumps({"status":result["status"], "rows":len(result["per_seed"]),
        "below_initial":len(result["heldout_below_initial"]),
        "dev_up_test_down":result["development_up_test_down_events"],
        "candidate_rank_correlation":result["candidate_rank_correlation"]}, indent=2))


if __name__ == "__main__":
    main()
