"""Complete, outcome-independent fixed-design laboratory-identity sensitivity.

All 40 single-laboratory fits are new CPU fits. No GPU/CPU cached models are
mixed. The unchanged V3 coordinator and previously documented CPU local-update
transport are reused; only the list of locally loaded adapters is restricted.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OUT = ROOT / "results/fbhk_followup_20261109/lab_identity"
TABLES = ROOT / "paper/tables/fbhk_followup_20261109"
BASE = ROOT / "results/unified_bio_20260918"
TASKS = ("ptpc_neural", "vcc_corrected", "norman_double_corrected", "tahoe_drug_corrected")
CONFIG = dict(lr=.001, weight_decay=.001, prox_mu=0., server_momentum=0., residual=False)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp-{os.getpid()}")
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    os.replace(tmp, path)


def prepare():
    registration = OUT / "protocol.json"
    if registration.exists():
        p = read(registration)
        for path, digest in p["bindings"].items():
            if sha(path) != digest:
                raise ValueError("Registered source/data changed: " + path)
        return p
    old = ROOT / "extensions/unified_bio_20260918"
    cpu = ROOT / "extensions/rebuttal_20261109/allocation"
    files = [Path(__file__), HERE / "test_run.py"]
    files += [old / n for n in ("core.py", "core_v3.py", "adapters.py", "run_v6.py",
        "run_native_tapb.py", "run_ptpc_neural.py", "ptpc_neural_adapter.py", "heldout_ptpc_neural.py")]
    files += [cpu / n for n in ("cpu_runtime.py", "allocation_shared.py", "run.py")]
    files += [ROOT / "extensions/core_ablation_20260922/common.py",
        ROOT / "extensions/federated_bio_20260918/engine.py",
        ROOT / "extensions/federated_bio_20260918/scdebart.py",
        ROOT / "extensions/proteomics/ptpc_model.py", ROOT / "extensions/proteomics/scoring.py"]
    for task in TASKS:
        manifest = BASE / task / "data/manifest.json"
        files.append(manifest)
        source = manifest.parent if task == "ptpc_neural" else Path(read(manifest)["data_root"])
        files += [source / f"clients/{lab}/{role}.npz" for lab in range(10) for role in ("train", "dev")]
        if task != "ptpc_neural":
            files += [source / n for n in ("manifest.json", "public_hidden.npy", "initial_head.pt", "scoring_mask.npy")]
    p = dict(schema="fbhk-fixed-lab-identity-cpu-v1", frozen_unix=time.time(),
        tasks=list(TASKS), labs=list(range(10)), seed=42, config=CONFIG, rounds=100,
        fits=40, implementation="unchanged core_v3 coordinator; existing cpu_runtime local-update transport",
        access="Exactly one adapter for the designated lab; its own train and dev measurements",
        selection="Local development primary, then lower loss; earliest full tie; evaluate every five rounds",
        runtime="CPU, two intra-op threads, one active fit, no GPU use; all forty fits new",
        initial_reference="Shared task initialization and seed; CPU arithmetic is not asserted bitwise equal to historical GPU runs",
        all_labs_reporting="All forty outcomes reported including ties, decreases and failures; no favorable-lab selection",
        test_rule="All forty development-selected checkpoints sealed before any new heldout scoring",
        scope="Fixed D00 only; no controller, random-search or DTI lab-rotation claim",
        bindings={str(f): sha(f) for f in sorted(set(files))})
    dump(registration, p)
    return p


def runtime():
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(ROOT / "extensions/core_ablation_20260922"))
    common = importlib.import_module("common")
    sys.path.insert(0, str(ROOT / "extensions/rebuttal_20261109/allocation"))
    cpu = importlib.import_module("cpu_runtime")
    common.torch.set_num_threads(2)
    return common, cpu


def fit(task, lab):
    if task not in TASKS or lab not in range(10):
        raise ValueError("Unregistered task/lab")
    p = prepare()
    target = OUT / task / f"lab{lab}" / "fit"
    if (target / "receipt.json").exists():
        return verify(task, lab)
    if target.exists():
        raise RuntimeError("Preserve unreceipted partial fit: " + str(target))
    common, cpu = runtime()
    import adapters

    class LocalCPU(cpu.CPUFederation):
        def __init__(self):
            self.path = BASE / task / "data"
            self.adapters = {lab: adapters.load_adapter(self.path, lab, "cpu")}
            self.models, self.configs = {}, {}

        def rpc(self, clients, requests):
            if clients != [lab] or len(requests) != 1:
                raise ValueError("Local fit refuses another laboratory")
            return super().rpc(clients, requests)

    federation = LocalCPU()
    try:
        assert list(federation.adapters) == [lab]
        n = federation.adapters[lab].n_train
        record = federation.fit(CONFIG, [lab], target, seed=p["seed"], rounds=100)
        receipt = dict(task=task, lab=lab, seed=p["seed"], config=CONFIG, rounds=100,
            protocol_sha256=sha(OUT / "protocol.json"), record_sha256=sha(target / "fit.json"),
            checkpoint_sha256=sha(target / "best.pt"), n_train=n, new_fit=True, device="cpu",
            local_optimizer_steps=100 * ((n + 63) // 64), examples_seen=100 * n,
            training_seconds=record["training_seconds"], completed_unix=time.time(),
            torch_version=common.torch.__version__, cpu_threads=common.torch.get_num_threads(),
            numerical_note="Fresh CPU sensitivity, not bitwise replication of historical CUDA results")
        dump(target / "receipt.json", receipt)
    finally:
        federation.close()
    return verify(task, lab)


def verify(task, lab):
    target = OUT / task / f"lab{lab}" / "fit"
    receipt, record = read(target / "receipt.json"), read(target / "fit.json")
    assert receipt["protocol_sha256"] == sha(OUT / "protocol.json")
    assert receipt["record_sha256"] == sha(target / "fit.json")
    assert receipt["checkpoint_sha256"] == sha(target / "best.pt")
    assert record["config"] == CONFIG and record["clients"] == [lab] and record["seed"] == 42
    assert record["rounds"] == 100 and len(record["history"]) == 100 and record["test_read"] is False
    eligible = [r for r in record["history"] if "development" in r]
    assert [r["round"] for r in eligible] == list(range(5, 101, 5))
    expected = max(eligible, key=lambda r: (r["development"]["primary"], -r["development"]["loss"]))
    assert record["best"] == expected
    record["checkpoint"] = str(target / "best.pt")
    return record


def train():
    prepare()
    start = time.time()
    completed = []
    for task in TASKS:
        for lab in range(10):
            result = fit(task, lab)
            completed.append(dict(task=task, lab=lab, fit_seconds=result["training_seconds"]))
            status = dict(status="RUNNING", completed=completed, count=len(completed),
                          elapsed_seconds=time.time()-start, updated_unix=time.time())
            dump(OUT / "status.json", status)
            print(json.dumps(status), flush=True)
    selected = {task: {f"lab{lab}": verify(task, lab) for lab in range(10)} for task in TASKS}
    dump(OUT / "selected_development.json", selected)
    seal = dict(status="SEALED_BEFORE_HELDOUT", sealed_unix=time.time(),
        protocol_sha256=sha(OUT / "protocol.json"), selected_sha256=sha(OUT / "selected_development.json"),
        all_fits=[dict(task=t, lab=l, receipt_sha256=sha(OUT/t/f"lab{l}"/"fit/receipt.json"))
                  for t in TASKS for l in range(10)], physical_new_fits=40, gpu_hours=0)
    dump(OUT / "selection_seal.json", seal)
    dump(OUT / "status.json", dict(status="DEVELOPMENT_COMPLETE", count=40, updated_unix=time.time()))


def evaluate():
    prepare()
    seal = read(OUT / "selection_seal.json")
    assert seal["selected_sha256"] == sha(OUT / "selected_development.json")
    for r in seal["all_fits"]:
        assert r["receipt_sha256"] == sha(OUT/r["task"]/f"lab{r['lab']}"/"fit/receipt.json")
        verify(r["task"], r["lab"])
    common, _ = runtime()
    selected = read(OUT / "selected_development.json")
    for task in TASKS:
        common.evaluate_selected(task, selected[task], OUT/task/"heldout", "cpu")
    report()


def report():
    rows = []
    for task in TASKS:
        payload = read(OUT / task / "heldout/results.json")
        values = [payload["results"][f"lab{lab}"]["primary"] * 100 for lab in range(10)]
        rows.append(dict(task=task, lab_scores=values, lab0=values[0], mean=statistics.mean(values),
                         sd=statistics.stdev(values), minimum=min(values), maximum=max(values)))
    result = dict(schema="fbhk-fixed-lab-identity-report-v1", rows=rows, n_labs=10, seed=42,
        new_fits=40, all_outcomes_included=True, variation="Across simulated lab identities, not training seeds",
        scope="Fixed D00 only; separate CPU sensitivity, no DTI or all-lab-controller evaluation",
        fit_elapsed_seconds=sum(read(OUT/t/f"lab{l}"/"fit/receipt.json")["training_seconds"] for t in TASKS for l in range(10)),
        protocol_sha256=sha(OUT / "protocol.json"), selection_seal_sha256=sha(OUT / "selection_seal.json"))
    dump(OUT / "report.json", result)
    dump(TABLES / "lab_identity.json", result)
    names = {"ptpc_neural": "Proteomics AP", "vcc_corrected": "VCC Top-1",
             "norman_double_corrected": "Norman Top-1", "tahoe_drug_corrected": "Tahoe Top-1"}
    lines = [r"\begin{table}[t]", r"\centering", r"\small",
        r"\caption{Fixed-design sensitivity to the identity of the single participating laboratory. Each of ten laboratories independently fits D00 for 100 rounds and selects a checkpoint on its own development panel (seed 42). All 40 fits are fresh CPU runs under the same training equations; the SD and range describe laboratory identities, not training seeds. This diagnostic does not rerun research controllers.}",
        r"\label{tab:fbhk-lab-identity}", r"\begin{tabular}{lrrr}", r"\toprule",
        r"Endpoint & Lab 0 & Ten-lab mean $\pm$ SD & Range \\", r"\midrule"]
    for r in rows:
        lines.append(f"{names[r['task']]} & {r['lab0']:.2f} & ${r['mean']:.2f} \\pm {r['sd']:.2f}$ & {r['minimum']:.2f}--{r['maximum']:.2f} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    (TABLES / "lab_identity.tex").write_text("\n".join(lines) + "\n")
    dump(OUT / "status.json", dict(status="COMPLETE", count=40, updated_unix=time.time()))
    print(json.dumps(result), flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("command", choices=("prepare", "benchmark", "train", "evaluate", "report"))
    args = p.parse_args()
    if args.command == "prepare":
        print(json.dumps(prepare()), flush=True)
    elif args.command == "benchmark":
        result = fit("vcc_corrected", 1)
        print(json.dumps(dict(training_seconds=result["training_seconds"],
            rough_40fit_seconds=40*result["training_seconds"], benchmark_included_in_frozen_full_study=True)), flush=True)
    else:
        globals()[args.command]()


if __name__ == "__main__":
    main()
