import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location("lab_identity_run", Path(__file__).with_name("run.py"))
run = importlib.util.module_from_spec(spec)
spec.loader.exec_module(run)


class ContractTests(unittest.TestCase):
    def test_complete_light_scope(self):
        self.assertEqual(len(run.TASKS), 4)
        self.assertNotIn("native_tapb", run.TASKS)
        self.assertEqual(len(run.TASKS) * len(range(10)), 40)

    def test_canonical_d00(self):
        self.assertEqual(run.CONFIG, dict(lr=.001, weight_decay=.001, prox_mu=0.,
            server_momentum=0., residual=False))

    def test_refuses_unregistered_task_before_loading_runtime(self):
        with self.assertRaises(ValueError):
            run.fit("native_tapb", 1)

    def test_refuses_unregistered_client_before_loading_runtime(self):
        with self.assertRaises(ValueError):
            run.fit("ptpc_neural", 10)


if __name__ == "__main__":
    unittest.main()
