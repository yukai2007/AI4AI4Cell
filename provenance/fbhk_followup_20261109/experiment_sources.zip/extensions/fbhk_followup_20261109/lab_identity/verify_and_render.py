"""Independently re-score all saved predictions and clarify table labels.

Presentation-only replacement of an ambiguous header; the frozen trainer and
registered scientific protocol are unchanged.
"""
from collections import defaultdict
import csv
import math
from pathlib import Path

import numpy as np
from sklearn.metrics import average_precision_score
import run


def main():
    protocol = run.prepare()
    seal = run.read(run.OUT / "selection_seal.json")
    assert len(seal["all_fits"]) == 40
    assert seal["selected_sha256"] == run.sha(run.OUT / "selected_development.json")
    checks, bindings = [], {}
    for task in run.TASKS:
        output = run.OUT / task / "heldout"
        scores, heldout_seal = run.read(output / "results.json"), run.read(output / "seal.json")
        assert heldout_seal["sealed_unix"] >= seal["sealed_unix"]
        assert scores["seal_sha256"] == run.sha(output / "seal.json")
        if task == "ptpc_neural":
            truth_path = run.ROOT / "data/proteomics/ptpc_release_20260911/final/final.npz"
            labels = np.load(truth_path)["y"]
        else:
            manifest = run.read(run.BASE / task / "data/manifest.json")
            truth_path = Path(manifest["data_root"]) / "test/query.npz"
            with np.load(truth_path, allow_pickle=False) as query:
                expected_ids, expected_choices = query["ids"], query["choices"]
        bindings[str(truth_path)] = run.sha(truth_path)
        for lab in range(10):
            run.verify(task, lab)
            name = f"lab{lab}"
            if task == "ptpc_neural":
                path = output / f"{name}_predictions.npz"
                probability = np.load(path)["probability"]
                assert probability.shape == labels.shape and np.isfinite(probability).all()
                primary = float(average_precision_score(labels, probability))
            else:
                path = output / f"{name}_predictions.json"
                groups = defaultdict(list)
                prediction_rows = run.read(path)
                assert len(prediction_rows) == len(expected_ids)
                for index, row in enumerate(prediction_rows):
                    assert row["intervention"] == int(expected_ids[index])
                    assert row["choices"] == expected_choices[index].tolist()
                    assert row["choices"].count(row["intervention"]) == 1
                    truth = row["choices"].index(row["intervention"])
                    order = sorted(range(len(row["scores"])), key=lambda i: -row["scores"][i])
                    rank = order.index(truth) + 1
                    assert row["rank"] == rank
                    assert all(math.isfinite(x) for x in row["scores"])
                    groups[row["intervention"]].append(rank == 1)
                primary = sum(sum(v)/len(v) for v in groups.values())/len(groups)
            expected = scores["results"][name]["primary"]
            assert abs(primary - expected) < 1e-12
            checks.append(dict(task=task, lab=lab, verified_primary=primary,
                               source_sha256=run.sha(path)))
            bindings[str(path)] = run.sha(path)
    report = run.read(run.OUT / "report.json")
    with (run.OUT / "per_lab.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["task", "lab", "primary_percent", "seed", "design", "device"])
        for row in report["rows"]:
            for lab, value in enumerate(row["lab_scores"]):
                writer.writerow([row["task"], lab, value, 42, "D00", "cpu"])
    table = run.TABLES / "lab_identity.tex"
    text = table.read_text()
    text = text.replace("Ten-lab mean $\\pm$ SD", "Single-lab mean $\\pm$ SD")
    table.write_text(text)
    validation = dict(status="PASS", new_fits_verified=40, prediction_scores_verified=40,
        protocol_sha256=run.sha(run.OUT / "protocol.json"),
        report_sha256=run.sha(run.OUT / "report.json"), prediction_bindings=bindings,
        all_fits_sealed_before_heldout=True, no_gpu_models_mixed=True, checks=checks,
        rendering_note="Header clarifies mean over ten separate single-lab fits, not a collaboratively trained model",
        renderer_sha256=run.sha(__file__), table_sha256=run.sha(table))
    run.dump(run.OUT / "verification.json", validation)
    run.dump(run.TABLES / "lab_identity.provenance.json", validation)
    print("PASS: 40 complete fits, 40 independently verified primary scores, all labs retained.")


if __name__ == "__main__":
    main()
