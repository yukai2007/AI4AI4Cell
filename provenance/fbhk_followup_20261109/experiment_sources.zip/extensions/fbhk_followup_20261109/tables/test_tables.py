"""Regression checks for complete, non-selective evidence-table rendering."""
import importlib.util
from pathlib import Path
import re
import unittest

SPEC = importlib.util.spec_from_file_location("fbhk_tables", Path(__file__).with_name("build_tables.py"))
TABLES = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(TABLES)


class TablesTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = TABLES.extract()

    def test_original_protocols_remain_separate(self):
        rows = self.data["old_studies"]
        self.assertEqual(len(rows), 18)
        self.assertEqual({r["design_count"] for r in rows if r["protocol"] == "short6"}, {12})
        self.assertEqual({r["design_count"] for r in rows if r["protocol"] == "long24"}, {36})
        self.assertFalse(any(r["task"] == "native_tapb" and r["protocol"] == "long24" for r in rows))

    def test_scores_match_every_original_published_row(self):
        generated = TABLES.original_scores(self.data)
        for source in ["short6.tex", "long24.tex"]:
            text = (TABLES.ROOT / "paper/tables/completed_ablation" / source).read_text()
            for line in text.splitlines():
                if re.match(r"^(DTI|PTPC|VCC|Norman|Tahoe) &", line):
                    expected = line.replace("PTPC", "Proteomics").rstrip("\\ ")
                    if source == "short6.tex":
                        expected += " & -- & --"
                    self.assertIn(expected + r" \\", generated)

    def test_all_dynamics_rows_preserved(self):
        generated = TABLES.original_dynamics(self.data)
        for source in ["dynamics_short6.tex", "dynamics_long24.tex"]:
            text = (TABLES.ROOT / "paper/tables/completed_ablation" / source).read_text()
            for line in text.splitlines():
                if re.match(r"^(DTI|PTPC|VCC|Norman|Tahoe) &", line):
                    self.assertIn(line.replace("PTPC", "Proteomics"), generated)

    def test_new_table_includes_all_main_controls_and_negative_contrast(self):
        rows = {r["policy"]: r for r in self.data["new_study"]["results"]}
        self.assertEqual(set(rows), {"fixed_D00", "direct", "raw", "structured", "random", "gp_ei"})
        self.assertGreater(rows["gp_ei"]["heldout_mean"], rows["structured"]["heldout_mean"])
        contrasts = self.data["new_study"]["contrasts"]
        self.assertEqual([(r["wins"], r["ties"], r["losses"]) for r in contrasts],
                         [(2, 1, 0), (2, 0, 1), (0, 2, 1)])
        for row in contrasts:
            self.assertLess(row["gene_cluster_ci95"][0], 0)
            self.assertGreater(row["gene_cluster_ci95"][1], 0)

    def test_budget_and_invalid_slots_are_not_hidden(self):
        rows = {r["policy"]: r for r in self.data["new_study"]["results"]}
        for key in ["direct", "structured", "random", "gp_ei"]:
            self.assertEqual(rows[key]["fitting_cost"]["rounds"]["mean"], 140)
            self.assertEqual(rows[key]["fitting_cost"]["optimizer_steps"]["mean"], 16940)
            self.assertEqual(rows[key]["fitting_cost"]["examples_seen"]["mean"], 532840)
        self.assertEqual(rows["raw"]["invalid_slots"], 3)
        self.assertEqual(rows["raw"]["fitting_cost"]["candidate_fit_count"]["mean"], 6)
        self.assertEqual(rows["fixed_D00"]["fitting_cost"]["rounds"]["mean"], 20)

    def test_artifacts_are_reproducible(self):
        for name, value in TABLES.artifacts().items():
            self.assertEqual((TABLES.OUT / name).read_text(), value, name)


if __name__ == "__main__":
    unittest.main()
