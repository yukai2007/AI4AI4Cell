"""Rebuild complete FBhK comparison tables from frozen result artifacts.

No fitting, model selection, test evaluation, or result filtering occurs here.
Run from any directory; --check verifies that checked-in tables are current.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "paper/tables/fbhk_followup_20261109"
OLD = "paper/tables/completed_ablation/snapshot.json"
HELDOUT = "results/history_repair_20261109/training_heldout_genetic_v1/policy_report.json"
SEARCH = "results/history_repair_20261109/search_genetic_v3/search_analysis.json"
SOURCES = [
    OLD, HELDOUT, SEARCH,
    "paper/tables/completed_ablation/short6.tex",
    "paper/tables/completed_ablation/long24.tex",
    "paper/tables/completed_ablation/dynamics_short6.tex",
    "paper/tables/completed_ablation/dynamics_long24.tex",
    "results/history_repair_20261109/search_genetic_v3/protocol.json",
    "results/history_repair_20261109/search_genetic_v3/registration.json",
    "results/history_repair_20261109/training_heldout_genetic_v1/protocol.json",
    "results/history_repair_20261109/training_heldout_genetic_v1/authorization.json",
    "results/history_repair_20261109/training_heldout_genetic_v1/verification.json",
]
TASKS = {
    "native_tapb": "DTI", "ptpc_neural": "Proteomics", "vcc_corrected": "VCC",
    "norman_double_corrected": "Norman", "tahoe_drug_corrected": "Tahoe",
}
POLICIES = [
    ("fixed_D00", "fixed", "Fully trained fixed D00"),
    ("direct", "direct", "Direct (no feedback)"),
    ("raw", "raw", "Raw history"),
    ("structured", "structured", "Structured history"),
    ("random", "random", "Random without replacement"),
    ("gp_ei", "gp_ei", "GP--EI"),
]


def read(path):
    return json.loads((ROOT / path).read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def json_text(value):
    return json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n"


def extract():
    old, heldout, search = read(OLD), read(HELDOUT), read(SEARCH)
    assert heldout["status"] == "COMPLETE"
    assert search["training_seeds"] == [61, 62, 63]
    rows = []
    for study in old["loops"]:
        rows.append({key: study[key] for key in [
            "task", "backend", "seed", "protocol", "slots", "design_count",
            "prefixes", "common_development_target", "modes",
        ]})
    rows.sort(key=lambda x: (0 if x["protocol"] == "short6" else 1,
                            list(TASKS).index(x["task"]), x["backend"]))
    assert len(rows) == 18
    assert sum(row["protocol"] == "short6" for row in rows) == 10
    results = []
    for key, search_key, label in POLICIES:
        h, s = heldout["policies"][key], search["aggregate"][search_key]
        results.append({
            "policy": key, "label": label,
            "heldout_mean": h["primary"],
            "heldout_seed_sd": h["across_training_controller_seed_sd"],
            "heldout_per_seed": [{"seed": v["seed"], "primary": v["primary"]}
                                 for v in h["per_seed"]],
            "development": s["development"]["primary"],
            "fitting_cost": s["fitting_cost"],
            "invalid_slots": s["invalid_slots"],
            "llm_logical_usage_total": s["llm_logical_usage_total"],
        })
    contrasts = []
    structured = {v["seed"]: v["primary"] for v in heldout["policies"]["structured"]["per_seed"]}
    for other in ["direct", "random", "gp_ei"]:
        p = heldout["paired_differences"][f"structured_minus_{other}"]
        differences = [structured[v["seed"]] - v["primary"]
                       for v in heldout["policies"][other]["per_seed"]]
        contrasts.append({
            "comparison": f"structured_minus_{other}", **p,
            "per_seed_difference": dict(zip(search["training_seeds"], differences)),
            "wins": sum(d > 1e-12 for d in differences),
            "ties": sum(abs(d) <= 1e-12 for d in differences),
            "losses": sum(d < -1e-12 for d in differences),
        })
    return {
        "schema": "fbhk-complete-tables-v1", "old_studies": rows,
        "new_study": {"training_controller_seeds": search["training_seeds"],
                      "results": results, "contrasts": contrasts,
                      "bootstrap": heldout["bootstrap"],
                      "interpretation": heldout["explanation"],
                      "development_prefixes": {key: search["aggregate"][key]["prefix_primary"]
                                               for key in ["direct", "raw", "structured", "random", "gp_ei"]}},
        "source_sha256": {name: sha(ROOT / name) for name in SOURCES},
    }


def table_start(caption, labels, cols, headers):
    return [r"\begin{table}[htbp]", "\\caption{" + caption + "}",
            *["\\label{" + label + "}" for label in labels],
            r"\centering\small", r"\setlength{\tabcolsep}{3pt}",
            r"\begin{tabularx}{\linewidth}{" + cols + "}", r"\toprule",
            headers + r" \\", r"\midrule"]


def table_end(lines):
    return "\n".join(lines + [r"\bottomrule", r"\end{tabularx}", r"\end{table}", ""])


def pct(value, bold=False):
    result = f"{100 * value:.2f}"
    return r"\textbf{" + result + "}" if bold else result


def original_scores(data):
    lines = table_start(
        "Original and extended proposal searches, shown together without mixing configuration libraries. "
        "D and H denote direct and history-guided search, and @ denotes the number of proposal slots. "
        "Every candidate receives 100 training rounds using the same ten laboratories. "
        "Panel (a) uses DTI seed 42 and other-task seed 61; panel (b) uses seed 61. "
        "The six-slot prefixes in the two panels belong to different searches. "
        "DTI uses AUROC, proteomics uses average precision, and cell tasks use Top-1, all multiplied by 100. "
        "Bold denotes the highest displayed score in each row, including ties; dashes indicate runs not performed.",
        ["tab:proposal-heldout-combined", "tab:completed-short6", "tab:completed-long24"],
        "@{}Xlrrrrr@{}", r"Task & Proposer & Fixed & D@6 & H@6 & D@24 & H@24")
    for protocol, panel in [("short6", "(a) 12 designs, six proposal slots"),
                            ("long24", "(b) 36 designs, 24 proposal slots")]:
        if protocol == "long24":
            lines.append(r"\midrule")
        lines.append(r"\multicolumn{7}{l}{\textit{" + panel + r"}} \\")
        for row in data["old_studies"]:
            if row["protocol"] != protocol:
                continue
            prefixes = {x["budget"]: x for x in row["prefixes"]}
            p0, p6 = prefixes[0], prefixes[6]
            assert p0["direct_heldout_primary"] == p0["loop_heldout_primary"]
            vals = [p0["direct_heldout_primary"], p6["direct_heldout_primary"], p6["loop_heldout_primary"]]
            vals += ([prefixes[24]["direct_heldout_primary"], prefixes[24]["loop_heldout_primary"]]
                     if protocol == "long24" else [None, None])
            best = max(v for v in vals if v is not None)
            cells = ["--" if v is None else pct(v, abs(v - best) < 1e-12) for v in vals]
            lines.append(" & ".join([TASKS[row["task"]], row["backend"].title(), *cells]) + r" \\")
    return table_end(lines)


def original_dynamics(data):
    lines = table_start(
        "Retrospective development-trajectory diagnostics for the two proposal-search protocols. "
        "Each D/H pair gives direct/history. The target is the lower terminal development score "
        "of the two runs; First is its earliest attainment, with slot 0 denoting initialization. "
        "Last gain records the final strict primary-score increase; Last retain also includes loss-tiebreak selections. "
        "All six or 24 slots were executed: these target crossings are descriptive and did not save training budget. "
        "Valid counts report accepted proposal formats, not retained model improvements.",
        ["tab:proposal-dynamics-combined", "tab:completed-dynamics-short6", "tab:completed-dynamics-long24"],
        "@{}Xlrrrrr@{}",
        r"Task & Proposer & \shortstack{Dev.\\target} & \shortstack{First\\D/H} & "
        r"\shortstack{Last gain\\D/H} & \shortstack{Last retain\\D/H} & \shortstack{Valid\\D/H}")
    for protocol, panel in [("short6", "(a) 12 designs, six proposal slots"),
                            ("long24", "(b) 36 designs, 24 proposal slots")]:
        if protocol == "long24":
            lines.append(r"\midrule")
        lines.append(r"\multicolumn{7}{l}{\textit{" + panel + r"}} \\")
        for row in data["old_studies"]:
            if row["protocol"] != protocol:
                continue
            d, h = row["modes"]["direct"], row["modes"]["loop"]
            cells = [f"{d[k]}/{h[k]}" for k in ["first_common_target", "last_primary_improvement", "last_retained", "valid"]]
            lines.append(" & ".join([TASKS[row["task"]], row["backend"].title(),
                                     pct(row["common_development_target"]), *cells]) + r" \\")
    return table_end(lines)


def new_history(data):
    study = data["new_study"]
    lines = table_start(
        "Fresh history-feedback comparison on the gene-disjoint, four-context cell benchmark "
        "(three paired training/controller seeds). This benchmark is separate from the original VCC, Norman and Tahoe tasks. "
        "Top-1 scores are percentages; $\\pm$ reports the sample standard deviation across seeds. "
        "Search methods share the same 16 designs, four clients, development panels and six proposal slots; "
        "each valid candidate is fitted for 20 rounds. Fits include the initial-design fit. "
        "Random search integrates all size-six subsets of the 15 non-initial designs and selects using development evidence, "
        "not test scores. Raw history has three invalid slots across 18; direct and structured history complete all 18. "
        "Bold marks the best mean development or test score.",
        ["tab:fresh-history-comparison"], "@{}Xrrr@{}",
        r"Search method & Development & Held-out & Fits")
    max_dev = max(r["development"]["mean"] for r in study["results"])
    max_test = max(r["heldout_mean"] for r in study["results"])
    for row in study["results"]:
        d = row["development"]
        dtext = f"{100*d['mean']:.2f} \\pm {100*d['sample_sd']:.2f}"
        ttext = f"{100*row['heldout_mean']:.2f} \\pm {100*row['heldout_seed_sd']:.2f}"
        if abs(d["mean"] - max_dev) < 1e-12:
            dtext = r"\mathbf{" + dtext + "}"
        if abs(row["heldout_mean"] - max_test) < 1e-12:
            ttext = r"\mathbf{" + ttext + "}"
        fits = row["fitting_cost"]["candidate_fit_count"]
        ftext = f"{fits['mean']:.0f}" if fits["sample_sd"] == 0 else f"${fits['mean']:.0f} \\pm {fits['sample_sd']:.0f}$"
        lines.append(f"{row['label']} & ${dtext}$ & ${ttext}$ & {ftext}" + r" \\")
    lines += [r"\midrule", r"\multicolumn{4}{l}{\textit{Paired held-out contrasts (percentage points)}} \\",
              r"Contrast & Mean difference & 95\% CI & W/T/L \\"]
    names = {"direct": "Direct", "random": "Random", "gp_ei": "GP--EI"}
    for row in study["contrasts"]:
        key = row["comparison"].removeprefix("structured_minus_")
        lo, hi = [100*v for v in row["gene_cluster_ci95"]]
        lines.append(f"Structured $-$ {names[key]} & ${100*row['difference']:+.3f}$ & "
                     f"$[{lo:.3f}, {hi:.3f}]$ & {row['wins']}/{row['ties']}/{row['losses']}" + r" \\")
    lines += [r"\midrule", r"\multicolumn{4}{@{}p{\linewidth}@{}}{\footnotesize "
              r"W/T/L counts paired seeds. Confidence intervals use 10,000 paired perturbation-gene "
              r"bootstrap resamples and describe conditional test-gene uncertainty for the fixed selected "
              r"models, rather than uncertainty over additional training or controller runs.} \\"]
    return table_end(lines)


def costs(data):
    lines = table_start(
        "Resource accounting for the fresh history comparison. Training columns are per-seed means; "
        "the last two columns total all three seeds. Fits are evaluated from a shared cache, with "
        "each policy charged for every candidate it requests. Raw-history invalid slots consume "
        "proposal budget without a candidate fit. Identical rounds, steps and examples do not imply "
        "identical FLOPs or language-model costs. Calls include permitted retries and logically "
        "charge the shared first proposal to each language-model arm.",
        ["tab:fresh-history-cost"], "@{}Xrrrrr@{}",
        r"Method & Rounds & Steps & Examples & \shortstack{Invalid\\slots} & \shortstack{LLM\\calls}")
    for row in data["new_study"]["results"]:
        cost = row["fitting_cost"]
        values = [f"{cost[k]['mean']:,.0f}" for k in ["rounds", "optimizer_steps", "examples_seen"]]
        lines.append(" & ".join([row["label"], *values, str(row["invalid_slots"]),
                                  str(row["llm_logical_usage_total"]["calls"])]) + r" \\")
    return table_end(lines)


def artifacts():
    data = extract()
    outputs = {
        "proposal_heldout_combined.tex": original_scores(data),
        "proposal_dynamics_combined.tex": original_dynamics(data),
        "fresh_history.tex": new_history(data),
        "fresh_history_cost.tex": costs(data),
        "snapshot.json": json_text(data),
    }
    manifest = {"schema": "fbhk-table-build-v1", "generator": str(Path(__file__).relative_to(ROOT)),
                "generator_sha256": sha(Path(__file__)), "source_sha256": data["source_sha256"],
                "artifact_sha256": {name: hashlib.sha256(text.encode()).hexdigest()
                                    for name, text in outputs.items()},
                "selection_policy": "All original study rows and all six new main policies are retained.",
                "reproduction_command": "python extensions/fbhk_followup_20261109/tables/build_tables.py --check"}
    outputs["provenance.json"] = json_text(manifest)
    return outputs


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    outputs = artifacts()
    if args.check:
        mismatches = [name for name, text in outputs.items()
                      if not (OUT / name).exists() or (OUT / name).read_text() != text]
        if mismatches:
            raise SystemExit("Stale or absent artifacts: " + ", ".join(mismatches))
        print(f"PASS: {len(outputs)} artifacts reproduce exactly")
    else:
        OUT.mkdir(parents=True, exist_ok=True)
        for name, text in outputs.items():
            (OUT / name).write_text(text)
        print(f"Wrote {len(outputs)} artifacts to {OUT}")


if __name__ == "__main__":
    main()
