"""Versioned JSON-envelope compatibility; inherited Qwen transport is unchanged.

Only a complete external Markdown fence and invalid *string* escapes are
normalized. Scientific fields, numbers, IDs, and schema remain caller-owned.
Old backend.py and its v2 receipts are deliberately untouched.
"""
from __future__ import annotations

import copy
import json
import math
import re

from extensions.history_repair_20261109.backend import (
    LocalQwenBackend as _OriginalBackend, _dump, _messages, _sha,
)


class DecodeFailure(ValueError):
    def __init__(self, message, normalized_text, transformations):
        super().__init__(message)
        self.normalized_text = normalized_text
        self.transformations = copy.deepcopy(transformations)


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key: " + key)
        result[key] = value
    return result


def _constant(value):
    raise ValueError("Nonfinite JSON constant is forbidden: " + value)


def _float(value):
    result = float(value)
    if not math.isfinite(result):
        raise ValueError("JSON number overflows to a nonfinite value: " + value)
    return result


def _unicode_scalars(value):
    if isinstance(value, str) and any(0xD800 <= ord(char) <= 0xDFFF for char in value):
        raise ValueError("Unpaired Unicode surrogate is forbidden")
    if isinstance(value, dict):
        for key, item in value.items():
            _unicode_scalars(key)
            _unicode_scalars(item)
    elif isinstance(value, list):
        for item in value:
            _unicode_scalars(item)


def decode_json_response(raw_response):
    """Return {parsed, normalized_text, transformations}, or DecodeFailure.

    Legal JSON escapes are never reinterpreted as LaTeX. Thus an existing
    ``\\t`` stays a tab escape; only otherwise-invalid ``\\(``, etc. retain
    their literal backslash. This does not repair punctuation or scientific
    content, extract an inner object, or ignore surrounding prose.
    """
    transformations = []
    if not isinstance(raw_response, str):
        raise DecodeFailure("Response must be text", None, transformations)
    text = raw_response.strip()
    try:
        if text.startswith("```"):
            match = re.fullmatch(r"```(?:json)?[ \t]*\r?\n([\s\S]*?)\r?\n```", text)
            if match is None or re.search(r"(?m)^\s*```", match.group(1)):
                raise ValueError("Only one complete external JSON/code fence is accepted")
            text = match.group(1)
            transformations.append({"operation": "strip_complete_external_fence"})
        output, inside, index, escaped_positions = [], False, 0, []
        while index < len(text):
            char = text[index]
            if char == '"':
                inside = not inside
                output.append(char)
                index += 1
                continue
            if inside and char == "\\":
                if index + 1 == len(text):
                    raise ValueError("Trailing backslash inside JSON string")
                following = text[index + 1]
                if following == "u":
                    digits = text[index + 2:index + 6]
                    if len(digits) != 4 or re.fullmatch(r"[0-9a-fA-F]{4}", digits) is None:
                        raise ValueError("Malformed Unicode escape; not repaired")
                    output.append(text[index:index + 6])
                    index += 6
                    continue
                if following in '"\\/bfnrt':
                    output.append(text[index:index + 2])
                    index += 2
                    continue
                if ord(following) < 0x20:
                    raise ValueError("Control character after backslash; not repaired")
                output.append("\\\\" + following)
                escaped_positions.append(index)
                index += 2
                continue
            output.append(char)
            index += 1
        text = "".join(output)
        if escaped_positions:
            transformations.append({"operation": "preserve_invalid_string_escape_as_literal_backslash",
                                    "count": len(escaped_positions), "source_positions": escaped_positions})
        parsed = json.loads(text, object_pairs_hook=_object, parse_constant=_constant, parse_float=_float)
        if not isinstance(parsed, dict):
            raise ValueError("JSON response must be an object")
        _unicode_scalars(parsed)
        return {"parsed": parsed, "normalized_text": text, "transformations": transformations}
    except (ValueError, TypeError) as error:
        raise DecodeFailure(str(error), text, transformations) from error


class LocalQwenBackend(_OriginalBackend):
    """The original generate/limits/receipts, with an auditable decoder only."""
    def generate_json(self, messages, *, seed, context=None, validator=None,
                      schema_description="Return one valid JSON object.",
                      max_repairs=1, purpose="proposal"):
        if type(max_repairs) is not int or max_repairs not in (0, 1, 2):
            raise ValueError("max_repairs must be 0, 1, or 2")
        if not isinstance(schema_description, str):
            raise ValueError("schema_description must be a string")
        working = _messages(messages)
        with self.lock:
            request_id = self.requests
            self.requests += 1
        record = dict(request_id=request_id, valid=False, parsed=None, max_repairs=max_repairs,
                      attempts=[], context=copy.deepcopy(context or {}), decoder_version=3,
                      decoder_source_sha256=_sha(__file__), normalizations=[])
        path = self.output_dir / f"request_{request_id:05d}.json"
        _dump(path, record)
        for attempt in range(max_repairs + 1):
            receipt = self.generate(working, seed=seed + 10000 * attempt,
                                    context=dict(context or {}, schema_request_id=request_id, schema_attempt=attempt),
                                    purpose=purpose if attempt == 0 else "schema_repair")
            record["attempts"].append(receipt)
            normalized = {"normalized_text": None, "transformations": []}
            try:
                decoded = decode_json_response(receipt["raw_response"])
                normalized = {key: decoded[key] for key in ("normalized_text", "transformations")}
                parsed = decoded["parsed"]
                if validator is not None:
                    validator(copy.deepcopy(parsed))
                record.update(valid=True, parsed=parsed)
            except (ValueError, KeyError, TypeError) as error:
                if isinstance(error, DecodeFailure):
                    normalized = {"normalized_text": error.normalized_text, "transformations": error.transformations}
                receipt["schema_error"] = f"{type(error).__name__}: {error}"
            receipt["json_normalization"] = dict(decoder_version=3, **copy.deepcopy(normalized))
            record["normalizations"].append(dict(call_id=receipt["call_id"], **copy.deepcopy(normalized)))
            _dump(receipt["receipt_path"], receipt)
            _dump(path, record)
            if record["valid"]:
                return record
            if attempt < max_repairs:
                working.extend([
                    {"role": "assistant", "content": receipt["raw_response"]},
                    {"role": "user", "content": (
                        "JSON/schema validation failed: " + receipt["schema_error"]
                        + ". Correct the response using the unchanged task and schema. " + schema_description)}])
        record["error"] = "All bounded JSON/schema attempts failed; no fallback"
        _dump(path, record)
        return record


Backend = LocalQwenBackend
