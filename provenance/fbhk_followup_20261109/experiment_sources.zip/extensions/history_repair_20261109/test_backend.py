import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from extensions.history_repair_20261109 import backend as b


MESSAGES = [{"role": "system", "content": "Return JSON only."},
            {"role": "user", "content": "Return status ready."}]


class FakeTransport:
    def __init__(self, responses):
        self.responses = iter(responses)
        self.definition = {"actual_model": "unit-test fake transport"}
        self.seeds = []
        self.prompts = []

    def generate(self, messages, seed):
        self.seeds.append(seed)
        self.prompts.append(messages)
        response = next(self.responses)
        if isinstance(response, Exception):
            raise response
        return dict(raw_response=response, input_tokens=20, output_tokens=5,
                    seconds=.01, generation_seconds=.009, prompt_text="fake rendered prompt")


class BackendTests(unittest.TestCase):
    def make_backend(self, folder, responses, **kwargs):
        fake = FakeTransport(responses)
        self.loads = 0
        def factory(**settings):
            self.loads += 1
            self.settings = settings
            return fake
        return b.LocalQwenBackend(folder, transport_factory=factory, **kwargs), fake

    def test_lazy_reused_across_trajectories_with_explicit_seeds(self):
        with tempfile.TemporaryDirectory() as folder:
            backend, fake = self.make_backend(folder, ['{"status":"ready"}'] * 2)
            self.assertEqual(self.loads, 0)
            one = backend.generate(MESSAGES, seed=42, context={"trajectory": "raw"})
            two = backend.generate(MESSAGES, seed=42, context={"trajectory": "structured"})
            self.assertEqual(self.loads, 1)
            self.assertEqual(fake.seeds, [42, 42])
            self.assertEqual(one["requested_model"], b.MODEL_NAME)
            self.assertEqual(one["actual_model"], "unit-test fake transport")
            self.assertTrue(one["settings"]["injected_transport"])
            self.assertEqual(one["messages"], MESSAGES)
            self.assertEqual(two["input_tokens"], 20)
            self.assertEqual(two["context"]["trajectory"], "structured")
            self.assertIn("total_attempt_seconds", two)

    def test_two_total_attempts_and_no_silent_fallback(self):
        with tempfile.TemporaryDirectory() as folder:
            backend, fake = self.make_backend(folder, ["not json", "still not json"])
            result = backend.generate_json(MESSAGES, seed=42)
            self.assertFalse(result["valid"])
            self.assertIsNone(result["parsed"])
            self.assertEqual(fake.seeds, [42, 10042])
            self.assertEqual(len(result["attempts"]), 2)
            self.assertEqual(fake.prompts[1][-2]["content"], "not json")
            self.assertIn("unchanged task and schema", fake.prompts[1][-1]["content"])
            self.assertIn("schema_error", result["attempts"][0])
            self.assertEqual(json.loads((Path(folder) / "request_00000.json").read_text()), result)

    def test_caller_validator_controls_schema_and_cannot_mutate_parsed(self):
        def validate(value):
            if set(value) != {"status"} or value["status"] != "ready":
                raise ValueError("status must equal ready")
            value["private_mutation"] = True
        with tempfile.TemporaryDirectory() as folder:
            backend, fake = self.make_backend(folder, ['{"status":"bad"}', '{"status":"ready"}'])
            result = backend.generate_json(MESSAGES, seed=7, validator=validate)
            self.assertTrue(result["valid"])
            self.assertEqual(result["parsed"], {"status": "ready"})
            self.assertEqual(fake.seeds, [7, 10007])

    def test_hard_cap_raises_without_extra_generation(self):
        with tempfile.TemporaryDirectory() as folder:
            backend, fake = self.make_backend(folder, ["{}"], max_calls=1)
            backend.generate(MESSAGES, seed=0)
            with self.assertRaisesRegex(RuntimeError, "Hard model-call cap"):
                backend.generate(MESSAGES, seed=0)
            self.assertEqual(len(fake.seeds), 1)

    def test_transport_failure_preserves_counts_and_is_not_schema_repaired(self):
        with tempfile.TemporaryDirectory() as folder:
            failure = b.TransportFailure("input cap", {"input_tokens": 28001,
                                                       "output_tokens": None})
            backend, fake = self.make_backend(folder, [failure])
            with self.assertRaises(b.BackendFailure) as caught:
                backend.generate_json(MESSAGES, seed=8)
            receipt = json.loads(Path(caught.exception.receipt_path).read_text())
            self.assertEqual(receipt["status"], "FAILED")
            self.assertEqual(receipt["input_tokens"], 28001)
            self.assertEqual(fake.seeds, [8])

    def test_returned_token_limits_are_enforced(self):
        with tempfile.TemporaryDirectory() as folder:
            backend, _ = self.make_backend(folder, ["{}"], max_input_tokens=10)
            with self.assertRaisesRegex(b.BackendFailure, "token cap"):
                backend.generate(MESSAGES, seed=0)

    def test_model_identity_and_fresh_receipt_directory(self):
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaisesRegex(ValueError, "only the named local Qwen"):
                b.LocalQwenBackend(folder, requested_model="another model")
            self.make_backend(folder, [])
            with self.assertRaisesRegex(ValueError, "fresh backend directory"):
                b.LocalQwenBackend(folder)

    def test_no_framework_imports_at_module_import(self):
        root = Path(__file__).resolve().parents[2]
        result = subprocess.run([
            sys.executable, "-B", "-c",
            "import sys; from extensions.history_repair_20261109 import backend; "
            "assert 'torch' not in sys.modules; assert 'transformers' not in sys.modules"],
            cwd=root, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_invalid_message_seed_or_repair_budget_does_not_load(self):
        with tempfile.TemporaryDirectory() as folder:
            backend, _ = self.make_backend(folder, [])
            with self.assertRaises(ValueError):
                backend.generate([], seed=0)
            with self.assertRaises(ValueError):
                backend.generate(MESSAGES, seed=True)
            with self.assertRaises(ValueError):
                backend.generate_json(MESSAGES, seed=0, max_repairs=3)
            self.assertEqual(self.loads, 0)


if __name__ == "__main__":
    unittest.main()
