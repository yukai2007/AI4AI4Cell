import json
import math
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from extensions.history_repair_20261109 import report_search as r


def fit(primary, cost, loss=1.):
    return dict(development=dict(primary=primary, loss=loss), rounds=20,
                actual_optimizer_steps=80, actual_examples_seen=1000,
                seconds=cost, allocated_gpu_hours=cost / 3600)


def receipt(identifier, input_tokens=100, output_tokens=20):
    return dict(call_id=identifier, status="COMPLETE", input_tokens=input_tokens,
                output_tokens=output_tokens, generation_seconds=2., total_attempt_seconds=3.)


class ReportTests(unittest.TestCase):
    def test_random_cost_is_attempted_inclusion_not_selected_checkpoint(self):
        grid = {"D00": fit(.5, 1), "D01": fit(.1, 100), "D02": fit(.2, 1000)}
        row = r.random_summary(grid, budget=1)
        self.assertEqual(row["selected_weights"], {"D00": 1.})
        self.assertEqual(row["inclusion_probabilities"], {"D00": 1., "D01": .5, "D02": .5})
        self.assertEqual(row["fitting_cost"]["measured_fit_seconds_sum"], 551)
        self.assertEqual(row["fitting_cost"]["candidate_fit_count"], 2)
        self.assertEqual(row["fitting_cost"]["rounds"], 40)

    def test_fixed_first_and_5005_distribution_cost(self):
        grid = {f"D{i:02d}": fit(i / 16, i + 1) for i in range(16)}
        unconditional = r.random_summary(grid)
        self.assertEqual(unconditional["subsets"], 5005)
        self.assertAlmostEqual(unconditional["fitting_cost"]["candidate_fit_count"], 7.)
        fixed = r.random_inclusion_weights(grid, 6, "D04")
        self.assertEqual(fixed["D00"], 1)
        self.assertEqual(fixed["D04"], 1)
        self.assertAlmostEqual(fixed["D15"], 5 / 14)
        self.assertAlmostEqual(sum(fixed.values()), 7)

    def test_uniform_random_score_moments_and_saved_distribution_validation(self):
        grid = {"D00": fit(0, 1), "D01": fit(0, 1), "D02": fit(1, 1)}
        row = r.random_summary(grid, 1)
        self.assertEqual(row["development"]["primary"], .5)
        self.assertEqual(row["conditional_search_policy_sd"]["primary"], .5)
        with self.assertRaises(ValueError):
            r.random_summary(grid, 1, recorded={"subsets": 2, "weights": {"D00": 1.}})

    def test_actual_shared_call_count_differs_from_logical_sum(self):
        shared, a, b, c = receipt(0), receipt(1), receipt(2), receipt(3)
        physical = r.usage([shared, a, b, c])
        logical = r.add_usage([r.usage([shared, a]), r.usage([shared, b]), r.usage([shared, c])])
        self.assertEqual(physical["calls"], 4)
        self.assertEqual(logical["calls"], 6)
        self.assertEqual(physical["input_tokens"], 400)
        with self.assertRaises(ValueError):
            r.usage([shared, shared])

    def test_sample_sd_is_not_sem_or_population_sd(self):
        value = r.mean_sd([1., 2., 3.])
        self.assertEqual(value, {"n": 3, "mean": 2., "sample_sd": 1.})
        self.assertIsNone(r.mean_sd([1.])["sample_sd"])

    def test_failed_nonfinite_or_unbacked_cost_rejected(self):
        grid = {"D00": fit(.2, 1)}
        grid["D00"]["seconds"] = float("nan")
        with self.assertRaises(ValueError):
            r.fit_cost(grid, {"D00": 1.})
        with self.assertRaises(ValueError):
            r.fit_cost(grid, {"D01": 1.})
        bad = receipt(0)
        bad["status"] = "FAILED"
        with self.assertRaises(ValueError):
            r.usage([bad])

    def test_deterministic_cost_includes_all_queries_and_earlier_ties(self):
        grid = {"D00": fit(.5, 10), "D01": fit(.5, 20), "D02": fit(.1, 30)}
        row = r.deterministic_summary(grid, "D00", ["D00", "D02", "D01"])
        self.assertEqual(row["fitting_cost"]["measured_fit_seconds_sum"], 60)
        with self.assertRaises(ValueError):
            r.deterministic_summary(grid, "D01", ["D00", "D01"])

    def test_all_seals_checked_before_any_seed_summary_is_read(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "protocol.json").write_text(json.dumps({"training_seeds": [61, 62, 63]}))
            (root / "seed61").mkdir()
            (root / "seed61/selection_seal.json").write_text("{}")
            with patch.object(r, "summarize_seed") as mocked:
                with self.assertRaisesRegex(FileNotFoundError, "WAITING_SEALS: 62, 63"):
                    r.summarize(root)
                mocked.assert_not_called()

    def test_changed_sealed_file_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "record.json"
            path.write_text('{"score":0}')
            digest = r.sha(path)
            path.write_text('{"score":1}')
            with self.assertRaisesRegex(ValueError, "Sealed input changed"):
                r.checked(path, digest)

    def test_projected_grid_costs_are_bound_to_full_fit_receipts(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)
            checkpoint = path / "best.pt"
            checkpoint.write_bytes(b"test checkpoint")
            config = {"lr": .001}
            training = dict(candidates={"D00": config}, rounds=20, optimizer_steps_per_fit=80,
                            examples_per_fit=1000, source_sha256="registered-code")
            full = dict(fit(.5, 360), design_id="D00", seed=61, status="COMPLETE", config=config,
                        checkpoint=str(checkpoint), checkpoint_sha256=r.sha(checkpoint),
                        training_registration_sha256="registration", source_sha256="registered-code",
                        test_expression_read=False)
            (path / "summary.json").write_text(json.dumps(full))
            projection = {"D00": {k: full[k] for k in ("design_id", "seed", "config", "checkpoint", "seconds")}}
            complete, hashes = r.complete_fit_records(projection, training, "registration", 61)
            self.assertEqual(r.fit_cost(complete, {"D00": 1})["measured_fit_gpu_hours_sum"], .1)
            self.assertIn(str(path / "summary.json"), hashes)
            projection["D00"]["seconds"] = 1
            with self.assertRaisesRegex(ValueError, "Projected grid differs"):
                r.complete_fit_records(projection, training, "registration", 61)


if __name__ == "__main__":
    unittest.main()
