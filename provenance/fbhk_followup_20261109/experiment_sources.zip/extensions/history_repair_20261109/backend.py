"""Resident local Qwen text transport; no candidate selection or scientific rules.

``generate`` returns a receipt. ``generate_json`` returns ``valid`` (bool),
``parsed`` (a JSON object or None), and ``attempts`` (all charged call receipts).
The default ``max_repairs=1`` means two total attempts, identically for all arms.
Importing this module does not import torch, load weights, or call any model.
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
from pathlib import Path
import threading
import time


MODEL_NAME = "Qwen2.5-7B-Instruct"
MODEL_PATH = Path("/liziqing/yukai/.cache/modelscope/Qwen2.5-7B-Instruct")
LOADER_REFERENCE = "extensions/unified_bio_20260918/research.py:Researcher.__init__"


def _dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp-{os.getpid()}")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                    allow_nan=False) + "\n")
    os.replace(temporary, path)


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _messages(messages):
    if not isinstance(messages, list) or not messages:
        raise ValueError("Nonempty text messages required")
    for message in messages:
        if (not isinstance(message, dict)
                or message.get("role") not in {"system", "user", "assistant", "tool"}
                or not isinstance(message.get("content"), str)):
            raise ValueError("Only explicit text messages are accepted")
    return copy.deepcopy(messages)


class TransportFailure(RuntimeError):
    def __init__(self, message, measured=None):
        super().__init__(message)
        self.measured = measured or {}


class BackendFailure(RuntimeError):
    """A charged call failed; its receipt is retained in ``receipt_path``."""
    def __init__(self, message, receipt_path):
        super().__init__(message)
        self.receipt_path = str(receipt_path)


class _LocalQwenTransport:
    """The existing Researcher loading/generation recipe, without its task imports."""
    def __init__(self, *, device, max_input_tokens, max_new_tokens):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        torch.set_num_threads(2)
        self.torch = torch
        self.device = device
        self.max_input_tokens = max_input_tokens
        self.max_new_tokens = max_new_tokens
        self.tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, local_files_only=True)
        self.model = AutoModelForCausalLM.from_pretrained(
            MODEL_PATH, local_files_only=True, torch_dtype=torch.bfloat16,
            device_map={"": device}, attn_implementation="sdpa").eval()
        actual_path = str(self.model.config._name_or_path)
        if Path(actual_path).resolve() != MODEL_PATH.resolve():
            raise RuntimeError("Loaded model path differs from the requested local model")
        self.definition = {
            "actual_model": actual_path,
            "actual_model_architecture": list(self.model.config.architectures or []),
            "tokenizer_name_or_path": str(self.tokenizer.name_or_path),
            "torch_version": torch.__version__,
            "loader_reference": LOADER_REFERENCE,
            "loader_recipe": "Transformers local_files_only/bfloat16/sdpa/eval",
            "configuration_sha256": {
                name: _sha(MODEL_PATH / name)
                for name in ("config.json", "generation_config.json", "tokenizer.json",
                             "tokenizer_config.json", "model.safetensors.index.json")
                if (MODEL_PATH / name).is_file()},
            "configuration_hashes_are_not_full_weight_hashes": True,
        }

    def generate(self, messages, seed):
        started = time.monotonic()
        measured = {"input_tokens": None, "output_tokens": None,
                    "raw_response": "", "prompt_text": None}
        try:
            prompt = self.tokenizer.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True)
            measured["prompt_text"] = prompt
            batch = self.tokenizer(prompt, return_tensors="pt")
            measured["input_tokens"] = int(batch.input_ids.shape[1])
            if measured["input_tokens"] > self.max_input_tokens:
                raise ValueError("Declared input-token cap exceeded; no truncation")
            batch = batch.to(self.device)
            self.torch.manual_seed(seed)
            if str(self.device).startswith("cuda"):
                self.torch.cuda.synchronize(self.device)
            generation_started = time.monotonic()
            with self.torch.inference_mode():
                tokens = self.model.generate(
                    **batch, max_new_tokens=self.max_new_tokens,
                    do_sample=True, temperature=.7, top_p=.9,
                    pad_token_id=self.tokenizer.eos_token_id)
            if str(self.device).startswith("cuda"):
                self.torch.cuda.synchronize(self.device)
            measured["generation_seconds"] = time.monotonic() - generation_started
            generated = tokens[0, measured["input_tokens"]:]
            measured["output_tokens"] = int(generated.shape[0])
            measured["raw_response"] = self.tokenizer.decode(
                generated, skip_special_tokens=True)
            measured["seconds"] = time.monotonic() - started
            return measured
        except Exception as error:
            measured["seconds"] = time.monotonic() - started
            raise TransportFailure(f"{type(error).__name__}: {error}", measured) from error


class LocalQwenBackend:
    """One lazily loaded model shared across arbitrarily many named trajectories.

    ``seed`` is explicit per generation; no hidden global call-index seed offset.
    The caller owns experiment pairing, scientific schemas, and candidate choice.
    Use a fresh backend output directory. A supplied transport_factory is intended
    for unit tests and is explicitly marked as injected in the metadata.
    """
    def __init__(self, output_dir, *, device="cuda:0", requested_model=MODEL_NAME,
                 max_calls=1000, max_input_tokens=28000, max_new_tokens=512,
                 transport_factory=None):
        if requested_model not in (MODEL_NAME, str(MODEL_PATH)):
            raise ValueError("This backend supports only the named local Qwen model")
        for name, value in {"max_calls": max_calls, "max_input_tokens": max_input_tokens,
                            "max_new_tokens": max_new_tokens}.items():
            if type(value) is not int or value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        if ((self.output_dir / "backend.json").exists()
                or any(self.output_dir.glob("call_*.json"))
                or any(self.output_dir.glob("request_*.json"))):
            raise ValueError("Use a fresh backend directory; receipts cannot be overwritten")
        self.device = device
        self.requested_model = requested_model
        self.max_calls = max_calls
        self.max_input_tokens = max_input_tokens
        self.max_new_tokens = max_new_tokens
        self.transport_factory = transport_factory or _LocalQwenTransport
        self.transport = None
        self.calls = 0
        self.requests = 0
        self.lock = threading.Lock()
        self.definition = dict(
            requested_model=requested_model, requested_model_path=str(MODEL_PATH),
            actual_model=None, transport="local Transformers",
            injected_transport=transport_factory is not None,
            device=device, cuda_visible_devices=os.environ.get("CUDA_VISIBLE_DEVICES"),
            max_calls=max_calls, max_input_tokens=max_input_tokens,
            max_new_tokens=max_new_tokens, silent_truncation=False,
            seed_supported=True, sampling=dict(temperature=.7, top_p=.9),
            generated_code_executed=False, loader_reference=LOADER_REFERENCE,
            backend_source_sha256=_sha(__file__))
        _dump(self.output_dir / "backend.json", self.definition)

    def generate(self, messages, *, seed, context=None, purpose="proposal"):
        messages = _messages(messages)
        if type(seed) is not int or seed < 0 or seed >= 2**63:
            raise ValueError("seed must be a nonnegative signed-64-bit integer")
        context = copy.deepcopy(context or {})
        json.dumps(context, allow_nan=False)
        with self.lock:
            if self.calls >= self.max_calls:
                raise RuntimeError("Hard model-call cap reached; no fallback")
            call_id = self.calls
            self.calls += 1
            path = self.output_dir / f"call_{call_id:05d}.json"
            started = time.monotonic()
            receipt = dict(
                call_id=call_id, purpose=purpose, seed=seed, generation_seed_requested=seed,
                generation_seed_supported=True, messages=messages, context=context,
                requested_model=self.requested_model, actual_model=None,
                input_tokens=None, output_tokens=None, raw_response="",
                status="STARTED", receipt_path=str(path), settings=copy.deepcopy(self.definition))
            _dump(path, receipt)
            try:
                if self.transport is None:
                    self.transport = self.transport_factory(
                        device=self.device, max_input_tokens=self.max_input_tokens,
                        max_new_tokens=self.max_new_tokens)
                    self.definition.update(self.transport.definition)
                    _dump(self.output_dir / "backend.json", self.definition)
                receipt["actual_model"] = self.transport.definition["actual_model"]
                receipt["settings"] = copy.deepcopy(self.definition)
                measured = self.transport.generate(messages, seed)
                receipt.update(measured)
                if (type(receipt["input_tokens"]) is not int
                        or type(receipt["output_tokens"]) is not int
                        or receipt["input_tokens"] < 0 or receipt["output_tokens"] < 0
                        or not isinstance(receipt["raw_response"], str)):
                    raise ValueError("Transport did not return measured token counts and text")
                if (receipt["input_tokens"] > self.max_input_tokens
                        or receipt["output_tokens"] > self.max_new_tokens):
                    raise ValueError("Transport exceeded its declared token cap")
                receipt["status"] = "COMPLETE"
            except Exception as error:
                if isinstance(error, TransportFailure):
                    receipt.update(error.measured)
                receipt.update(status="FAILED", error=f"{type(error).__name__}: {error}")
                receipt["total_attempt_seconds"] = time.monotonic() - started
                _dump(path, receipt)
                raise BackendFailure(receipt["error"], path) from error
            receipt["total_attempt_seconds"] = time.monotonic() - started
            _dump(path, receipt)
            return receipt

    def generate_json(self, messages, *, seed, context=None, validator=None,
                      schema_description="Return one valid JSON object.",
                      max_repairs=1, purpose="proposal"):
        """Bounded syntax/schema repair only; invalid attempts never pick a design.

        ``validator`` receives a parsed dict and should raise ValueError on failure.
        Its return value is ignored. The returned ``parsed`` is the unchanged JSON.
        ``valid=False, parsed=None`` after exhaustion; no candidate fallback.
        Transport failures raise BackendFailure instead of masquerading as JSON errors.
        """
        if type(max_repairs) is not int or max_repairs not in (0, 1, 2):
            raise ValueError("max_repairs must be 0, 1, or 2")
        if not isinstance(schema_description, str):
            raise ValueError("schema_description must be a string")
        working = _messages(messages)
        with self.lock:
            request_id = self.requests
            self.requests += 1
        record = dict(request_id=request_id, valid=False, parsed=None,
                      max_repairs=max_repairs, attempts=[], context=copy.deepcopy(context or {}))
        path = self.output_dir / f"request_{request_id:05d}.json"
        _dump(path, record)
        for attempt in range(max_repairs + 1):
            attempt_context = dict(context or {}, schema_request_id=request_id,
                                   schema_attempt=attempt)
            receipt = self.generate(
                working, seed=seed + 10000 * attempt, context=attempt_context,
                purpose=purpose if attempt == 0 else "schema_repair")
            record["attempts"].append(receipt)
            try:
                parsed = json.loads(receipt["raw_response"])
                if not isinstance(parsed, dict):
                    raise ValueError("JSON response must be an object")
                if validator is not None:
                    validator(copy.deepcopy(parsed))
                record.update(valid=True, parsed=parsed)
                _dump(path, record)
                return record
            except (ValueError, KeyError, TypeError) as error:
                receipt["schema_error"] = f"{type(error).__name__}: {error}"
                _dump(receipt["receipt_path"], receipt)
                _dump(path, record)
                if attempt < max_repairs:
                    working.extend([
                        {"role": "assistant", "content": receipt["raw_response"]},
                        {"role": "user", "content": (
                            "JSON/schema validation failed: " + str(error)
                            + ". Correct the response using the unchanged task and schema. "
                            + schema_description)}])
        record["error"] = "All bounded JSON/schema attempts failed; no fallback"
        _dump(path, record)
        return record


Backend = LocalQwenBackend
