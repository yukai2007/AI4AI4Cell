"""Matched fresh candidate cache; full budgets, no held-out/test loader.

Every candidate runs the same complete local epochs. The cache supports later
paired research controllers, but cache construction itself is not an agent run.
"""
from __future__ import annotations

import argparse
import copy
import itertools
import math
import multiprocessing as mp
from pathlib import Path
import sys
import time

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.nn import functional as F

from training_data import OUT, ROOT, read_json, save_json, sha
sys.path.insert(0, str(ROOT / "extensions/federated_bio_20260918"))
from scdebart import make_head


def candidates():
    base = dict(lr=1e-4, head="full", objective="mse", weight_decay=.001, server_momentum=0.)
    configs = [base]
    for lr, head, objective in itertools.product((1e-5, 3e-5, 1e-4, 3e-4), ("full", "residual"), ("mse", "mse_contrastive")):
        value = dict(lr=lr, head=head, objective=objective, weight_decay=.001, server_momentum=0.)
        if value != base:
            configs.append(value)
    assert len(configs) == 16
    return {f"D{i:02d}": config for i, config in enumerate(configs)}


def freeze(data=OUT):
    path = data / "training_registration.json"
    if path.exists():
        value = read_json(path)
        if value["source_sha256"] != sha(__file__):
            raise ValueError("Registered training source changed")
        return value
    prepared = read_json(data / "data_ready.json")
    rows = pd.read_csv(data / "train_dev_memberships.csv")
    counts = rows[rows.planned_role == "train"].groupby("scenario_id").size().to_dict()
    value = dict(schema="history-genetic-matched-training-v1", status="FROZEN_BEFORE_NEW_FITS",
                 created_unix=time.time(), source_sha256=sha(__file__), candidates=candidates(),
                 training_seeds=[61], optional_predeclared_replication_seeds=[62, 63],
                 rounds=20, batch_size=32, local_epochs_per_round=1, evaluation_rounds=[0, 2, 5, 10, 20],
                 eligible_selection_rounds=[2, 5, 10, 20], round0="Pretrained prediction diagnostic only; not selected by trained-candidate protocol",
                 selection="Highest equal-context mean macro Top-1; then lower equal-context CE; then earlier checkpoint",
                 training="Client-local AdamW, optimizer reset at each local round, shared pretrained start, example-weighted parameter averaging, no coordinator momentum",
                 head="Full: update pretrained 768-512-1 MLP; residual: freeze this MLP and add zero-output-initialized 768-32-1 residual MLP",
                 objective="Raw mean(log1pCP10K) response-delta MSE; optionally +0.1 in-batch cosine CE (temperature0.1); negatives only local training batch",
                 scoring="Five locked five-option rosters per development gene per context; cosine ranking; jointly mask the five candidate perturbation genes when present in response panel",
                 primary="Equal-context mean of within-context gene-macro Top-1",
                 uncertainty_unit="Global gene identities; repeated rosters and contexts are not independent observations",
                 cost_policy="Equal data, candidates, rounds, local epochs, and batches; head-dependent parameter counts and measured runtimes reported, not claimed FLOP-identical",
                 gradient_clip=1., no_early_stopping=True, train_counts=counts,
                 optimizer_steps_per_fit=20 * sum(math.ceil(int(n) / 32) for n in counts.values()),
                 examples_per_fit=20 * sum(int(n) for n in counts.values()),
                 train_dev_data_sha256=sha(data / "data_ready.json"),
                 initial_head_sha256=prepared["initial_head_sha256"],
                 fixed_file_sha256={name: sha(data / name) for name in ["panel_seal.json", "train_dev_memberships.csv", "responses.npy", "development_rosters.json", "gene_ids.npy"]},
                 test_expression_read=False, cache_not_new_agent_runs=True)
    save_json(path, value)
    return value


def build_model(initial, config, seed, device):
    torch.manual_seed(seed)
    model = make_head(initial, {"residual": config["head"] == "residual"})
    if config["head"] == "residual":
        model.base.requires_grad_(False)
    return model.to(device)


def state(model):
    return {key: value.detach().clone() for key, value in model.state_dict().items()}


def choice_metrics(predictions, response, truth, choices, pert_positions):
    """Return query metrics; masking is identical across each query's options."""
    ranks, losses = [], []
    for begin in range(0, len(truth), 128):
        actual, opts = truth[begin:begin + 128], choices[begin:begin + 128]
        target = response[actual].clone()
        predicted = predictions[opts].clone()
        mask_positions = pert_positions[opts]
        for col in range(opts.shape[1]):
            valid = mask_positions[:, col] >= 0
            row = torch.nonzero(valid, as_tuple=True)[0]
            gene = mask_positions[valid, col]
            target[row, gene] = 0
            predicted[row, :, gene] = 0
        scores = (F.normalize(target, dim=-1)[:, None, :] * F.normalize(predicted, dim=-1)).sum(-1)
        labels = (opts == actual[:, None]).long().argmax(-1)
        assert torch.all((opts == actual[:, None]).sum(-1) == 1)
        order = torch.argsort(scores, dim=-1, descending=True, stable=True)
        rank = (order == labels[:, None]).long().argmax(-1) + 1
        ranks.append(rank.cpu().numpy())
        losses.append(F.cross_entropy(scores / .1, labels, reduction="none").cpu().numpy())
    return np.concatenate(ranks), np.concatenate(losses)


class Trainer:
    def __init__(self, data, device):
        self.data, self.device = Path(data), device
        self.registration = freeze(self.data)
        self.rows = pd.read_csv(self.data / "train_dev_memberships.csv")
        self.x = torch.as_tensor(np.array(np.load(self.data / "hidden.npy", mmap_mode="r")), device=device)
        self.y = torch.as_tensor(np.load(self.data / "responses.npy"), device=device)
        self.initial = torch.load(self.data / "initial_head.pt", map_location="cpu", weights_only=True)
        self.pert_pos = torch.as_tensor(self.rows.perturbation_panel_position.to_numpy(), device=device)
        self.rosters = read_json(self.data / "development_rosters.json")
        self.clients = {str(c): frame.feature_id.to_numpy() for c, frame in
                        self.rows[self.rows.planned_role == "train"].groupby("scenario_id", sort=True)}
        self.dev_ids = self.rows.loc[self.rows.planned_role == "dev", "feature_id"].to_numpy()

    @torch.inference_mode()
    def evaluate(self, model):
        model.eval()
        predictions = torch.zeros_like(self.y)
        for begin in range(0, len(self.dev_ids), 32):
            ids = self.dev_ids[begin:begin + 32]
            predictions[ids] = model(self.x[ids].float())
        panels, gene_rows = {}, []
        for context, roster in self.rosters.items():
            truth = torch.tensor(roster["truth"], device=self.device)
            choices = torch.tensor(roster["choices"], device=self.device)
            rank, ce = choice_metrics(predictions, self.y, truth, choices, self.pert_pos)
            actual = np.asarray(roster["truth"])
            unique = np.unique(actual)
            gene_scores = []
            for value in unique:
                indices = actual == value
                acc = float(np.mean(rank[indices] == 1))
                gene_scores.append(acc)
                gene_rows.append(dict(gene=str(self.rows.iloc[value].identity_group), context=context,
                                      top1=acc, ce=float(ce[indices].mean()), condition_id=str(self.rows.iloc[value].condition_id)))
            p = predictions[unique]
            t = self.y[unique]
            unit = F.normalize(p[:128], dim=-1)
            pair = unit @ unit.T
            offdiag = ~torch.eye(len(unit), dtype=torch.bool, device=self.device)
            panels[context] = dict(primary=float(np.mean(gene_scores)), loss=float(ce.mean()),
                mse=float(F.mse_loss(p, t)), queries=len(rank), genes=len(unique),
                prediction_rms=float(p.square().mean().sqrt()), target_rms=float(t.square().mean().sqrt()),
                prediction_target_rms_ratio=float(p.square().mean().sqrt() / t.square().mean().sqrt().clamp_min(1e-12)),
                mean_pairwise_prediction_cosine=float(pair[offdiag].mean()), mrr=float(np.mean(1 / rank)))
        frame = pd.DataFrame(gene_rows)
        return dict(primary=float(np.mean([p["primary"] for p in panels.values()])),
                    loss=float(np.mean([p["loss"] for p in panels.values()])),
                    global_gene_macro=float(frame.groupby("gene").top1.mean().mean()),
                    unique_genes=frame.gene.nunique(), per_context=panels, per_gene=gene_rows)

    def fit(self, design_id, seed):
        config = self.registration["candidates"][design_id]
        out = self.data / f"fits/seed{seed}/{design_id}"
        if (out / "summary.json").exists():
            return read_json(out / "summary.json")
        if out.exists():
            raise FileExistsError(f"Incomplete fit requires explicit inspection: {out}")
        out.mkdir(parents=True)
        start = time.monotonic()
        model = build_model(self.initial, config, seed, self.device)
        trainable = [p for p in model.parameters() if p.requires_grad]
        initial_state = state(model)
        shared = state(model)
        initial_evidence = self.evaluate(model)
        trajectory = [dict(round=0, development=initial_evidence, diagnostic_only=True)]
        best_key, best_round, best_evidence = None, None, None
        steps, examples = 0, 0
        losses, all_rounds = [], []
        for round_id in range(1, self.registration["rounds"] + 1):
            aggregate = {k: torch.zeros_like(v, dtype=torch.float64) for k, v in shared.items()}
            round_losses = {}
            for client_index, (context, ids) in enumerate(self.clients.items()):
                model.load_state_dict(shared, strict=True)
                model.train()
                optimizer = torch.optim.AdamW(trainable, lr=config["lr"], weight_decay=config["weight_decay"])
                order = np.random.default_rng(seed + round_id * 100 + client_index).permutation(ids)
                weighted_loss = 0.
                for begin in range(0, len(order), self.registration["batch_size"]):
                    batch = order[begin:begin + self.registration["batch_size"]]
                    p = model(self.x[batch].float())
                    target = self.y[batch]
                    loss = F.mse_loss(p, target)
                    if config["objective"] == "mse_contrastive":
                        similarity = F.normalize(target, dim=-1) @ F.normalize(p, dim=-1).T / .1
                        loss = loss + .1 * F.cross_entropy(similarity, torch.arange(len(batch), device=self.device))
                    if not torch.isfinite(loss):
                        raise FloatingPointError(f"Non-finite training loss {design_id}/{round_id}/{context}")
                    optimizer.zero_grad(set_to_none=True)
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(trainable, self.registration["gradient_clip"])
                    optimizer.step()
                    weighted_loss += float(loss.detach()) * len(batch)
                    steps += 1
                    examples += len(batch)
                round_losses[context] = weighted_loss / len(ids)
                weight = len(ids) / sum(len(v) for v in self.clients.values())
                for key, value in model.state_dict().items():
                    aggregate[key].add_(value, alpha=weight)
            shared = {key: value.to(initial_state[key].dtype) for key, value in aggregate.items()}
            model.load_state_dict(shared, strict=True)
            record = dict(round=round_id, train_loss_by_context=round_losses,
                          train_loss=float(np.mean(list(round_losses.values()))), optimizer_steps=steps, examples_seen=examples)
            all_rounds.append(record)
            if round_id in self.registration["eligible_selection_rounds"]:
                evidence = self.evaluate(model)
                record = dict(record, development=evidence)
                trajectory.append(record)
                key = (evidence["primary"], -evidence["loss"], -round_id)
                if best_key is None or key > best_key:
                    best_key, best_round, best_evidence = key, round_id, evidence
                    torch.save({k: v.cpu() for k, v in shared.items()}, out / "best.pt")
            save_json(out / "progress.json", dict(status="RUNNING", design_id=design_id, round=round_id,
                      planned_rounds=self.registration["rounds"], seconds=time.monotonic() - start, optimizer_steps=steps,
                      examples_seen=examples, train_loss_by_context=round_losses, latest_development=trajectory[-1]["development"]["primary"]))
        torch.cuda.synchronize(self.device)
        elapsed = time.monotonic() - start
        assert steps == self.registration["optimizer_steps_per_fit"]
        assert examples == self.registration["examples_per_fit"]
        torch.save({k: v.cpu() for k, v in shared.items()}, out / "last.pt")
        result = dict(status="COMPLETE", design_id=design_id, config=config, seed=seed,
                      development=best_evidence, best_round=best_round, trajectory=trajectory,
                      training_rounds=all_rounds, checkpoint=str(out / "best.pt"),
                      checkpoint_sha256=sha(out / "best.pt"), final_checkpoint_sha256=sha(out / "last.pt"),
                      initial_diagnostic=initial_evidence, actual_optimizer_steps=steps, actual_examples_seen=examples,
                      rounds=20, seconds=elapsed, allocated_gpu_hours=elapsed / 3600,
                      trainable_parameters=sum(p.numel() for p in trainable), all_parameters=sum(p.numel() for p in model.parameters()),
                      device=self.device, torch_version=torch.__version__, dtype="float32 predictor, float16 feature cache",
                      training_registration_sha256=sha(self.data / "training_registration.json"),
                      features_complete_sha256=sha(self.data / "features_complete.json"),
                      test_expression_read=False, inference_scope="development only", source_sha256=sha(__file__))
        save_json(out / "summary.json", result)
        print(f"{design_id} seed{seed}: dev={best_evidence['primary']:.6f} round={best_round} seconds={elapsed:.1f}", flush=True)
        return result


def worker(data, device, identifiers, seeds):
    torch.set_num_threads(2)
    torch.backends.cuda.matmul.allow_tf32 = False
    trainer = Trainer(data, device)
    for seed in seeds:
        for design_id in identifiers:
            trainer.fit(design_id, seed)


def summarize(data, seeds):
    summaries = {}
    for seed in seeds:
        summaries[str(seed)] = {}
        for design_id in candidates():
            path = data / f"fits/seed{seed}/{design_id}/summary.json"
            if path.exists():
                full = read_json(path)
                summaries[str(seed)][design_id] = {key: full[key] for key in (
                    "design_id", "config", "seed", "development", "best_round", "trajectory", "checkpoint",
                    "checkpoint_sha256", "seconds", "actual_optimizer_steps", "actual_examples_seen", "trainable_parameters")}
    complete = all(len(summaries[str(seed)]) == 16 for seed in seeds)
    for seed in seeds:
        save_json(data / f"seed{seed}/development_grid.json", summaries[str(seed)])
    result = dict(status="COMPLETE" if complete else "PARTIAL", schema="history-candidate-cache-v1",
                  seeds=seeds, data_root=str(data), candidates=candidates(), results=summaries,
                  total_fit_gpu_hours=sum(row["seconds"] for run in summaries.values() for row in run.values()) / 3600,
                  role="Fresh train/development cache, NOT held-out evidence or an online-agent run",
                  test_expression_read=False, registration_sha256=sha(data / "training_registration.json"))
    save_json(data / "candidate_cache.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["freeze", "fit", "summarize"])
    parser.add_argument("--data", type=Path, default=OUT)
    parser.add_argument("--gpus", default="5,6,7")
    parser.add_argument("--seeds", default="61")
    parser.add_argument("--designs", default="all")
    args = parser.parse_args()
    if args.command == "freeze":
        print(freeze(args.data))
        return
    seeds = [int(v) for v in args.seeds.split(",")]
    if args.command == "fit":
        freeze(args.data)
        if not (args.data / "features_complete.json").exists():
            raise ValueError("Features must complete before training")
        if any(seed not in [61, 62, 63] for seed in seeds):
            raise ValueError("Seed not in preregistered set")
        gpus = [int(v) for v in args.gpus.split(",")]
        designs = list(candidates()) if args.designs == "all" else args.designs.split(",")
        ctx = mp.get_context("spawn")
        jobs = [ctx.Process(target=worker, args=(args.data, f"cuda:{gpu}", designs[i::len(gpus)], seeds))
                for i, gpu in enumerate(gpus)]
        for job in jobs:
            job.start()
        for job in jobs:
            job.join()
        if any(job.exitcode != 0 for job in jobs):
            raise RuntimeError("A candidate-training worker failed")
    result = summarize(args.data, seeds)
    print(result["status"], result["total_fit_gpu_hours"])


if __name__ == "__main__":
    main()
