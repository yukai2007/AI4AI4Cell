"""Prospectively frozen feedback experiment on newly trained candidate records.

The model sees only requested candidates. No held-out scoring is performed here.
The grid is a shared experimental cache, not a prompt-visible leaderboard.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from extensions.history_repair_20261109.evidence_cards import build_evidence_card
from extensions.history_repair_20261109.evidence_cards import DIAGNOSTIC_FIELDS

ARMS = ("direct", "raw", "structured")
BUDGET = 6
SCOPE = {
    "training_clients": "four study-context clients from Replogle and Nadig; two source studies",
    "development_panels": "the same four source contexts; globally gene-disjoint development identities",
    "selection": "equal-context mean Top-1 after averaging fixed five-way rosters per perturbation",
    "secondary": "lower development task loss; exact ties retain incumbent",
    "individual_rows_visible_to_researcher": False,
}
SYSTEM = (
    "You choose biological prediction experiments to maximize the final retained development score "
    "within the remaining candidate-request budget. You are not rewarded for confirming a predicted "
    "decrease. Exploration is allowed when it has a clear rationale for finding a better final model. "
    "Use only the supplied candidate configurations and observed evidence. All candidates receive "
    "the same complete 20-round training schedule on the same four study-context clients; neither "
    "history nor your explanation changes that schedule. Candidates restart from the registered "
    "initialization. The scDEBART encoder is fixed; head, learning rate and loss choices are given "
    "in the menu. head='full' means fitting the pretrained response head; head='residual' means freezing that "
    "head and fitting its zero-output-initialized residual adapter. A learning-rate change does not "
    "add an adapter. objective='mse' fits measured response deltas; 'mse_contrastive' adds "
    "0.1 times within-training-batch contrastive cross-entropy at temperature 0.1. "
    "Development primary is maximized and cosine-ranking cross-entropy breaks exact primary ties. "
    "Return one concise JSON object with exactly design_id, reference_id, changed_fields, hypothesis, "
    "experiment, expected_effect, prediction. Choose an available untried design_id. Copy reference_id "
    "from the supplied proposal_reference_id. changed_fields is the exact list of configuration keys "
    "whose values differ from reference_config; explain those changes, not imagined components. "
    "hypothesis, experiment and expected_effect are nonempty strings. prediction has exactly metric "
    "('primary' or 'loss'), direction ('increase' or 'decrease'), min_delta (nonnegative absolute "
    "metric units). 0.01 primary is one percentage point. Predictions refer to candidate minus "
    "reference at their selected development checkpoints. Distinguish observations from hypotheses. "
    "Do not invent scores or individual sample data. JSON only, under 512 output tokens."
)
SCHEMA = (
    '{"design_id":"<available ID>","reference_id":"<proposal_reference_id>",'
    '"changed_fields":["<exact changed configuration key>"],'
    '"hypothesis":"reason tied to the actual change",'
    '"experiment":"specific comparison",'
    '"expected_effect":"anticipated direction",'
    '"prediction":{"metric":"primary","direction":"increase","min_delta":0.0}}'
)


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if read(path) != value:
            raise ValueError(f"Refusing to replace an experiment record: {path}")
        return
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def key(row):
    return row["development"]["primary"], -row["development"]["loss"]


def observed_record(record, identifier, menu):
    """Project a full fit receipt into aggregate development-only observations."""
    if record["config"] != menu[identifier]:
        raise ValueError("Fit configuration differs from the registered menu")
    dev = record["development"]
    if not all(math.isfinite(dev[k]) for k in ("primary", "loss")):
        raise ValueError("This study requires finite complete fits before controller execution")
    safe_dev = {k: dev[k] for k in ("primary", "loss")}
    for field in DIAGNOSTIC_FIELDS:
        if isinstance(dev.get(field), (int, float)) and math.isfinite(dev[field]):
            safe_dev[field] = dev[field]
    if isinstance(dev.get("per_context"), dict):
        safe_dev["per_context"] = {
            label: {k: value[k] for k in ("primary", "loss", *DIAGNOSTIC_FIELDS)
                    if isinstance(value.get(k), (int, float)) and math.isfinite(value[k])}
            for label, value in dev["per_context"].items()}
    result = dict(design_id=identifier, config=deepcopy(menu[identifier]),
                  development=safe_dev,
                  best_round=record["best_round"], status="COMPLETE")
    points = []
    for row in record.get("trajectory", []):
        if "development" in row and all(k in row["development"] for k in ("primary", "loss")):
            point = {"round": row["round"], "development": {
                k: row["development"][k] for k in ("primary", "loss")}}
            if isinstance(row.get("train_loss"), (int, float)):
                point["train_loss"] = row["train_loss"]
            points.append(point)
    result["development_trajectory"] = points
    panels = dev.get("per_context", {})
    if isinstance(panels, dict):
        panels = [dict(panel_id=name, development=value) for name, value in panels.items()]
    if isinstance(panels, list):
        clean_panels = []
        for panel in panels:
            measurement = panel.get("development", panel)
            label = panel.get("panel_id", panel.get("context", panel.get("context_name")))
            if label is not None and all(k in measurement for k in ("primary", "loss")):
                clean_panels.append(dict(panel_id=str(label), development={
                    k: measurement[k] for k in ("primary", "loss")}))
        if clean_panels:
            result["per_panel_development"] = clean_panels
    return result


def validate_grid(records, registration, registration_path, seed):
    """Bind every projected score to a complete, identical-budget fresh fit."""
    menu = registration["candidates"]
    if set(records) != set(menu):
        raise ValueError("Incomplete candidate grid")
    for identifier, record in records.items():
        checkpoint = Path(record["checkpoint"])
        fit = read(checkpoint.with_name("summary.json"))
        if (fit["status"] != "COMPLETE" or fit["design_id"] != identifier
                or fit["seed"] != seed or record["seed"] != seed
                or fit["config"] != menu[identifier]
                or fit["rounds"] != registration["rounds"]
                or fit["actual_optimizer_steps"] != registration["optimizer_steps_per_fit"]
                or fit["actual_examples_seen"] != registration["examples_per_fit"]
                or fit["test_expression_read"] is not False
                or fit["training_registration_sha256"] != sha(registration_path)
                or fit["source_sha256"] != registration["source_sha256"]
                or fit["best_round"] not in registration["eligible_selection_rounds"]):
            raise ValueError(f"Unmatched or incomplete fit: {identifier}")
        if any(record[k] != fit[k] for k in record):
            raise ValueError(f"Grid summary differs from actual fit: {identifier}")
        if sha(checkpoint) != fit["checkpoint_sha256"]:
            raise ValueError(f"Changed checkpoint: {identifier}")
        selected = max((row for row in fit["trajectory"]
                        if row["round"] in registration["eligible_selection_rounds"]),
                       key=lambda r: (r["development"]["primary"], -r["development"]["loss"]))
        if selected["round"] != fit["best_round"] or selected["development"] != fit["development"]:
            raise ValueError(f"Nonregistered checkpoint selection: {identifier}")


def make_messages(history, arm, menu, slot):
    # Shared cold start: no baseline outcome is disclosed to any arm at slot 1.
    mode = "direct" if slot == 1 else arm
    card = build_evidence_card(history, mode, designs=menu,
                               evaluation_scope=SCOPE, total_slots=BUDGET)
    reference = next(k for k, v in menu.items() if v == card["reference_config"])
    card["proposal_reference_id"] = reference
    card["available_changed_fields"] = {
        name: sorted(k for k in config if config[k] != card["reference_config"][k])
        for name, config in card["available_designs"].items()}
    return [dict(role="system", content=SYSTEM),
            dict(role="user", content=json.dumps(card, ensure_ascii=False, allow_nan=False))], card


def validate_proposal(value, card):
    required = {"design_id", "reference_id", "changed_fields", "hypothesis", "experiment",
                "expected_effect", "prediction"}
    if not isinstance(value, dict) or set(value) != required:
        raise ValueError("Return exactly the seven fields in the schema")
    identifier = value["design_id"]
    if not isinstance(identifier, str) or identifier not in card["available_designs"]:
        raise ValueError("design_id must be an available untried ID")
    if value["reference_id"] != card["proposal_reference_id"]:
        raise ValueError("reference_id must equal " + card["proposal_reference_id"])
    fields = value["changed_fields"]
    if (not isinstance(fields, list) or not all(isinstance(k, str) for k in fields)
            or sorted(fields) != card["available_changed_fields"][identifier]):
        raise ValueError("changed_fields must be " + json.dumps(card["available_changed_fields"][identifier]))
    for field in ("hypothesis", "experiment", "expected_effect"):
        if not isinstance(value[field], str) or not value[field].strip():
            raise ValueError(field + " must be a nonempty string")
    p = value["prediction"]
    if (not isinstance(p, dict) or set(p) != {"metric", "direction", "min_delta"}
            or p["metric"] not in ("primary", "loss")
            or p["direction"] not in ("increase", "decrease")
            or not isinstance(p["min_delta"], (int, float)) or isinstance(p["min_delta"], bool)
            or not math.isfinite(p["min_delta"]) or p["min_delta"] < 0):
        raise ValueError("Invalid quantitative prediction schema")


def next_history(history, request, records, menu, card):
    result = deepcopy(history)
    if not request["valid"]:
        result.append(dict(invalid="Both bounded output-validation attempts failed", accepted=False))
        return result
    proposal = request["parsed"]
    identifier = proposal["design_id"]
    row = observed_record(records[identifier], identifier, menu)
    incumbent = max((r for r in result if r.get("development")), key=key)
    row["accepted"] = key(row) > key(incumbent)
    row["proposal"] = deepcopy(proposal)
    # This records the reference used for the forecast, not a retrospectively
    # substituted better model. In direct search it is always D00.
    reference = next(r for r in result if r.get("design_id") == card["proposal_reference_id"])
    row["reference"] = {k: deepcopy(reference[k]) for k in
                        ("design_id", "config", "development", "best_round")}
    result.append(row)
    return result


def freeze_protocol(training_path, output):
    output = Path(output)
    registration = read(training_path)
    menu = registration["candidates"]
    if len(menu) != 16 or "D00" not in menu:
        raise ValueError("Require the registered sixteen-design menu")
    sources = [Path(__file__), Path(__file__).with_name("evidence_cards.py"),
               Path(__file__).with_name("backend.py"), Path(__file__).with_name("controls.py")]
    protocol = dict(schema="prospective-genetic-feedback-20261109-v2", arms=list(ARMS),
        training_registration=str(Path(training_path).resolve()), training_sha256=sha(training_path),
        menu=menu, training_seeds=[61, 62, 63], agent_seed_rule="100000 * training_seed + slot; repairs add 10000",
        candidate_budget=BUDGET, baseline="D00 outside the six-request budget",
        training_rounds_per_candidate=20, selection="primary desc; loss asc; earlier exact ties",
        feedback_contrast="raw and structured contain the same observed facts; deterministic transformations only",
        feedback_facts="observed scores, selected-checkpoint aggregate context diagnostics, aggregate learning curves, own prior proposals",
        frozen_scope="controller protocol frozen before new LLM rollouts and held-out evaluation; training separately registered before fits",
        cold_start="One real slot-1 sample is shared across all three arms; charged once per logical trajectory",
        invalid="Two total attempts; failed slot charged; no default/fake proposal or extra slot",
        backend=dict(model="Qwen2.5-7B-Instruct", temperature=.7, top_p=.9,
                     max_input_tokens=28000, max_new_tokens=512, total_attempts_per_slot=2),
        controls="Exact without-replacement random; shared-first sensitivity; GP-EI six requests",
        evaluation_scope=SCOPE, physical_and_logical_costs_reported_separately=True,
        endpoints=["selected development primary", "prefix incumbent curve", "schema valid rate",
                   "forecast direction", "tokens", "candidate requests", "held-out selected-model score after sealing"],
        training_cache="new fits shared across policies; unrequested candidate results are never sent to proposer",
        source_sha256={str(p): sha(p) for p in sources}, system=SYSTEM, schema_example=SCHEMA)
    dump(output / "protocol.json", protocol)
    if not (output / "registration.json").exists():
        dump(output / "registration.json", dict(registered_utc=datetime.now(timezone.utc).isoformat(),
             protocol_sha256=sha(output / "protocol.json"), heldout_evaluation_read=False,
             llm_rollouts_started=False))
    return protocol


def run(training_path, grid_path, output, seed, device):
    from extensions.history_repair_20261109.backend import LocalQwenBackend
    from extensions.history_repair_20261109.controls import exact_random_weights, select_gp, random_prefix_curve
    output = Path(output)
    protocol = freeze_protocol(training_path, output)
    if seed not in protocol["training_seeds"]:
        raise ValueError("Unregistered seed")
    initial_grid_sha = sha(grid_path)
    records, menu = read(grid_path), protocol["menu"]
    if sha(grid_path) != initial_grid_sha:
        raise ValueError("Grid changed while being read")
    validate_grid(records, read(training_path), training_path, seed)
    for identifier, record in records.items():
        observed_record(record, identifier, menu)
    base = output / f"seed{seed}"
    if (base / "selections.json").exists():
        raise ValueError("This seed has already been selected; do not rerun it silently")
    dump(base / "inputs.json", dict(grid_path=str(Path(grid_path).resolve()), grid_sha256=initial_grid_sha,
         protocol_sha256=sha(output / "protocol.json"), source_training_seed=seed))
    backend = LocalQwenBackend(base / "backend", device=device, max_calls=32)
    baseline = observed_record(records["D00"], "D00", menu)
    baseline["accepted"] = True
    histories = {arm: [deepcopy(baseline)] for arm in ARMS}
    messages, card = make_messages(histories["direct"], "direct", menu, 1)
    shared = backend.generate_json(messages, seed=100000*seed+1,
        context=dict(training_seed=seed, slot=1, arm="shared_cold_start"),
        validator=lambda v: validate_proposal(v, card), schema_description=SCHEMA, max_repairs=1)
    dump(base / "shared_first.json", shared)
    for arm in ARMS:
        histories[arm] = next_history(histories[arm], shared, records, menu, card)
        dump(base / arm / "slot1.json", dict(request=shared, history=histories[arm], shared_request=True))
    # Interleave arms at each slot; no arm receives another arm's feedback.
    for slot in range(2, BUDGET+1):
        for arm in ARMS:
            messages, card = make_messages(histories[arm], arm, menu, slot)
            request = backend.generate_json(messages, seed=100000*seed+slot,
                context=dict(training_seed=seed, slot=slot, arm=arm),
                validator=lambda v: validate_proposal(v, card), schema_description=SCHEMA, max_repairs=1)
            histories[arm] = next_history(histories[arm], request, records, menu, card)
            dump(base / arm / f"slot{slot}.json", dict(request=request, history=histories[arm]))
            print(json.dumps(dict(seed=seed, arm=arm, slot=slot, valid=request["valid"],
                  design=(request.get("parsed") or {}).get("design_id"))), flush=True)
    selections = {}
    for arm, history in histories.items():
        valid_rows = [r for r in history if r.get("development")]
        selected = max(valid_rows, key=key)
        curve, incumbent = [], baseline
        for row in history:
            if row.get("development") and key(row) > key(incumbent):
                incumbent = row
            curve.append(incumbent["development"])
        selections[arm] = dict(design_id=selected["design_id"], development=selected["development"],
            candidate_ids=[r["design_id"] for r in valid_rows], invalid_slots=len(history)-len(valid_rows),
            logical_training_rounds=20*len(valid_rows), prefix_development=curve)
    normalized = {k: observed_record(v, k, menu) for k, v in records.items()}
    weights, count = exact_random_weights(normalized, budget=BUDGET)
    controls = dict(random=dict(weights=weights, subsets=count),
                    random_prefix=random_prefix_curve(normalized, max_budget=BUDGET))
    first = (shared.get("parsed") or {}).get("design_id")
    w, n = exact_random_weights(normalized, budget=BUDGET if first else BUDGET-1, first=first)
    controls["random_shared_first"] = dict(weights=w, subsets=n, shared_first=first,
                                           shared_failed_first_slot=first is None)
    for arm, selection in selections.items():
        if selection["invalid_slots"]:
            w, n = exact_random_weights(normalized, budget=len(selection["candidate_ids"])-1)
            controls[f"random_valid_fit_count_{arm}"] = dict(weights=w, subsets=n)
    trace, selected, ids = select_gp(menu, lambda k: deepcopy(normalized[k]), seed, budget=BUDGET)
    controls["gp_ei"] = dict(design_id=selected, candidate_ids=ids, trace=trace,
                              development=normalized[selected]["development"])
    if sha(grid_path) != initial_grid_sha:
        raise ValueError("Candidate grid changed during experiment; selections not sealed")
    dump(base / "selections.json", selections)
    dump(base / "controls.json", controls)
    dump(base / "selection_seal.json", dict(protocol_sha256=sha(output / "protocol.json"),
         grid_sha256=initial_grid_sha, selections_sha256=sha(base / "selections.json"),
         controls_sha256=sha(base / "controls.json"), sealed_utc=datetime.now(timezone.utc).isoformat(),
         heldout_evaluation_read=False, actual_llm_calls=backend.calls,
         transcript_sha256={str(p): sha(p) for p in sorted(base.rglob("*.json"))}))
    print(json.dumps(dict(status="SELECTIONS_SEALED", seed=seed, selections=selections)), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--training-registration", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--grid", type=Path)
    parser.add_argument("--seed", type=int, default=61)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--freeze-only", action="store_true")
    args = parser.parse_args()
    if args.freeze_only:
        freeze_protocol(args.training_registration, args.output)
    elif args.grid is None:
        parser.error("--grid required unless --freeze-only")
    else:
        run(args.training_registration, args.grid, args.output, args.seed, args.device)


if __name__ == "__main__":
    main()
