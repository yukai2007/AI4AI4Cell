"""Fresh train/development-only genetic mechanism benchmark.

This deliberately does not expose a test-data loader.  The 512-gene response
panel is learned only from the registered training rows.  Feature extraction
uses the pinned, mask-corrected scDEBART encoder and control measurements.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import multiprocessing as mp
import os
from pathlib import Path
import pickle
import sys
import time

import h5py
import numpy as np
import pandas as pd
import torch

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "results/history_repair_20261109/training_genetic_v1"
SPLITS = ROOT / "results/tie_audit_20261109/scaleup/genetic"
BULK = Path("/liziqing/VitaCode_Dataset/CellUMM/Pert/02_bulk/bulk.h5")
PANEL = Path("/liziqing/yukai/UMM_Cell/outputs/vccpert_adapted_v1_public_cache_20260830_attempt002/model_cache/gene_panel.csv")
WEIGHTS = ROOT / "data/scdebart_20260918/pretrained.pt"
sys.path.insert(0, str(ROOT / "extensions/scdebart_maskfix_20260918"))
from architecture import load_corrected, scdebart


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(8 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def save_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + f".tmp-{os.getpid()}")
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n")
    os.replace(tmp, path)


def read_json(path):
    return json.loads(Path(path).read_text())


def prepare(out=OUT, size=512):
    if (out / "data_ready.json").exists():
        return read_json(out / "data_ready.json")
    if out.exists():
        raise FileExistsError(f"Incomplete output exists; inspect rather than overwrite: {out}")
    out.mkdir(parents=True)
    train = pd.read_csv(SPLITS / "train.csv")
    dev = pd.read_csv(SPLITS / "dev.csv")
    assert set(train.identity_group).isdisjoint(dev.identity_group)
    genes = pd.read_csv(PANEL)
    vocabulary = scdebart.ROOT / "vendor/scDEBART-main/data/ens2geneid.pkl"
    with vocabulary.open("rb") as f:
        inverse = {v: k for k, v in pickle.load(f).items()}
    gids = np.asarray([inverse.get(e, -1) for e in genes.preferred_ensembl_gene_id], dtype=np.int64)
    symbol_pos = {str(s): i for i, s in enumerate(genes.gene_name) if gids[i] >= 0}
    receipts = []
    with h5py.File(BULK, "r") as bulk:
        assert len(genes) == bulk["perturbed_bulk"].shape[1]
        available = np.logical_and.reduce([bulk["gene_mask"][int(i)].astype(bool)
                                          for i in train.gene_mask_index.unique()])
        eligible = available & (gids >= 0)
        # Avoid ambiguous duplicate gene identifiers in the fixed response panel.
        _, unique_pos = np.unique(gids, return_index=True)
        eligible &= np.isin(np.arange(len(gids)), unique_pos)
        train_perturbations = set(train.perturbation)
        eligible &= ~genes.gene_name.isin(train_perturbations).to_numpy()
        positions = np.flatnonzero(eligible)
        if len(positions) < size:
            raise ValueError("Insufficient common, mapped response genes")
        for frame in (train, dev):
            valid = []
            for r in frame.itertuples():
                p = symbol_pos.get(r.perturbation, -1)
                valid.append(p >= 0 and bool(bulk["gene_mask"][int(r.gene_mask_index), p]))
            receipts.append(dict(original_rows=len(frame), retained_rows=int(sum(valid)),
                                 excluded_condition_ids=frame.loc[~np.asarray(valid), "condition_id"].tolist()))
            frame.drop(index=frame.index[~np.asarray(valid)], inplace=True)
        # Train values alone determine the panel. No development expression is
        # read until this selection has been saved and hashed below.
        sums = np.zeros(len(positions), dtype=np.float64)
        squares = np.zeros(len(positions), dtype=np.float64)
        controls = {int(i): bulk["control_bulk"][int(i)].astype(np.float32)
                    for i in train.control_bulk_index.unique()}
        for r in train.itertuples():
            delta = bulk["perturbed_bulk"][int(r.perturbed_bulk_index)][positions].astype(np.float64)
            delta -= controls[int(r.control_bulk_index)][positions]
            sums += delta
            squares += delta * delta
        variance = np.maximum(squares / len(train) - (sums / len(train)) ** 2, 0)
        selected = positions[np.lexsort((gids[positions], -variance))[:size]]
        selected = selected[np.argsort(gids[selected])]
        np.save(out / "panel_positions.npy", selected)
        np.save(out / "gene_ids.npy", gids[selected])
        save_json(out / "panel_seal.json", dict(
            status="FROZEN_BEFORE_DEVELOPMENT_EXPRESSION", panel_size=size,
            selection="Largest training delta-expression variance, common measured mapped genes; training intervention genes excluded; gene-ID tie break",
            train_sha256=sha(SPLITS / "train.csv"), selected_positions=selected.tolist(),
            gene_ids=gids[selected].tolist(), symbols=genes.iloc[selected].gene_name.tolist(),
            data_semantics="mean(log1p(CP10K)) perturbed minus context control; no second normalization",
            selected_variance=[float(variance[np.where(positions == p)[0][0]]) for p in selected],
            test_expression_read=False, created_unix=time.time()))
        rows = pd.concat([train, dev], ignore_index=True)
        rows["feature_id"] = np.arange(len(rows))
        rows["perturbation_gene_id"] = [int(gids[symbol_pos[s]]) for s in rows.perturbation]
        rows["perturbation_panel_position"] = [int(np.where(selected == symbol_pos[s])[0][0])
                                               if symbol_pos[s] in selected else -1 for s in rows.perturbation]
        rows.to_csv(out / "train_dev_memberships.csv", index=False)
        y = np.lib.format.open_memmap(out / "responses.npy", mode="w+", dtype=np.float32,
                                     shape=(len(rows), size))
        for r in rows.itertuples():
            y[r.feature_id] = bulk["perturbed_bulk"][int(r.perturbed_bulk_index)][selected] - bulk["control_bulk"][int(r.control_bulk_index)][selected]
        y.flush()
        # Control values for input construction are shared within each scenario,
        # and never contain a perturbed response.
        np.savez(out / "controls.npz", **{str(int(i)): bulk["control_bulk"][int(i)]
                                          for i in rows.control_bulk_index.unique()})
        np.save(out / "vocabulary_gene_ids.npy", gids)
    checkpoint = torch.load(WEIGHTS, map_location="cpu", weights_only=True)
    head = {k[len("logfc_head."):]: v.clone() for k, v in checkpoint.items() if k.startswith("logfc_head.")}
    if not head:
        raise ValueError("Missing pretrained head")
    torch.save(head, out / "initial_head.pt")
    np.lib.format.open_memmap(out / "hidden.npy", mode="w+", dtype=np.float16,
                             shape=(len(rows), size, 768)).flush()
    # Query option lists depend on labels and a locked seed, never expression.
    rosters = {}
    rng = np.random.default_rng(110923)
    for context, frame in rows[rows.planned_role == "dev"].groupby("scenario_id", sort=True):
        pool = frame.feature_id.to_numpy()
        choices, truth = [], []
        for actual in pool:
            for _ in range(5):
                candidates = np.r_[actual, rng.choice(pool[pool != actual], 4, replace=False)]
                rng.shuffle(candidates)
                choices.append(candidates.tolist())
                truth.append(int(actual))
        rosters[str(context)] = dict(choices=choices, truth=truth)
    save_json(out / "development_rosters.json", rosters)
    result = dict(status="TRAIN_DEV_DATA_READY_FEATURES_PENDING", schema="genetic-history-mechanism-v1",
                  train_rows=int((rows.planned_role == "train").sum()),
                  dev_rows=int((rows.planned_role == "dev").sum()),
                  train_genes=int(rows[rows.planned_role == "train"].identity_group.nunique()),
                  dev_genes=int(rows[rows.planned_role == "dev"].identity_group.nunique()),
                  panel_size=size, hidden_shape=[len(rows), size, 768],
                  sources=["Replogle", "Nadig"], contexts=sorted(rows.scenario_id.unique()),
                  role_filter_receipts=dict(train=receipts[0], dev=receipts[1]),
                  raw_test_expression_read=False, old_benchmark_modified=False,
                  protocol_scope="New expanded 512-gene mechanism benchmark; not the previous official benchmark",
                  source_sha256={str(p): sha(p) for p in [SPLITS / "train.csv", SPLITS / "dev.csv", PANEL,
                                                        vocabulary, WEIGHTS, Path(__file__)]},
                  bulk_identity=dict(path=str(BULK), bytes=BULK.stat().st_size, mtime_ns=BULK.stat().st_mtime_ns),
                  panel_seal_sha256=sha(out / "panel_seal.json"), initial_head_sha256=sha(out / "initial_head.pt"))
    save_json(out / "data_ready.json", result)
    return result


def feature_worker(out, device, worker_id, workers, limit=0):
    out = Path(out)
    torch.set_num_threads(2)
    rows = pd.read_csv(out / "train_dev_memberships.csv")
    selected = np.load(out / "panel_positions.npy")
    vocab = np.load(out / "vocabulary_gene_ids.npy")
    gene_ids = np.load(out / "gene_ids.npy")
    controls = np.load(out / "controls.npz")
    hidden = np.load(out / "hidden.npy", mmap_mode="r+")
    model = load_corrected(WEIGHTS, device)
    assigned = rows.iloc[worker_id::workers]
    if limit:
        assigned = assigned[assigned.planned_role == "train"].iloc[:limit]
    start = time.monotonic()
    for count, r in enumerate(assigned.itertuples(), 1):
        perturb = int(r.perturbation_gene_id)
        p = int(np.flatnonzero(vocab == perturb)[0])
        positions = selected if perturb in gene_ids else np.r_[selected, p]
        positions = positions[np.argsort(vocab[positions])]
        all_hidden = scdebart.hidden(model, vocab[positions], controls[str(int(r.control_bulk_index))][positions], [perturb])
        index = np.asarray([np.flatnonzero(positions == value)[0] for value in selected])
        hidden[int(r.feature_id)] = all_hidden[index]
        if count % 32 == 0:
            hidden.flush()
            save_json(out / f"feature_worker{worker_id}.json", dict(status="RUNNING", completed=count,
                       total=len(assigned), seconds=time.monotonic() - start, device=device))
    hidden.flush()
    torch.cuda.synchronize(device)
    result = dict(status="SMOKE_COMPLETE" if limit else "COMPLETE", completed=len(assigned), total=len(assigned),
                  seconds=time.monotonic() - start, device=device, peak_memory_bytes=torch.cuda.max_memory_allocated(device),
                  per_condition_seconds=(time.monotonic() - start) / max(1, len(assigned)),
                  feature_sha256=None, test_expression_read=False)
    save_json(out / f"feature_worker{worker_id}{'_smoke' if limit else ''}.json", result)
    print(json.dumps(result), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["prepare", "features", "smoke"])
    parser.add_argument("--out", type=Path, default=OUT)
    parser.add_argument("--gpus", default="4,5,6,7")
    args = parser.parse_args()
    if args.command == "prepare":
        print(json.dumps(prepare(args.out), indent=2))
        return
    gpus = [int(x) for x in args.gpus.split(",")]
    if args.command == "smoke":
        feature_worker(args.out, f"cuda:{gpus[0]}", 0, 1, limit=8)
        return
    ctx = mp.get_context("spawn")
    jobs = [ctx.Process(target=feature_worker, args=(args.out, f"cuda:{gpu}", i, len(gpus)))
            for i, gpu in enumerate(gpus)]
    for job in jobs:
        job.start()
    for job in jobs:
        job.join()
    if any(job.exitcode != 0 for job in jobs):
        raise RuntimeError("Feature extraction worker failed")
    save_json(args.out / "features_complete.json", dict(status="COMPLETE", hidden_sha256=sha(args.out / "hidden.npy"),
              feature_workers=[read_json(args.out / f"feature_worker{i}.json") for i in range(len(gpus))],
              created_unix=time.time(), test_expression_read=False))


if __name__ == "__main__":
    main()
