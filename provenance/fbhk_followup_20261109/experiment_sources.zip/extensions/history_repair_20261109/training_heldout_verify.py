"""Independent post-scoring integrity/accounting checks; no model selection."""
import argparse
from pathlib import Path
import time

import numpy as np
import pandas as pd

from training_data import read_json, save_json, sha


def verify(out):
    protocol = read_json(out / "protocol.json")
    feature_record = read_json(out / "features_complete.json")
    expected_shapes = dict(hidden=[protocol["retained_rows"], 512, 768], responses=[protocol["retained_rows"], 512])
    actual_hashes = {}
    for key, name in (("hidden_sha256", "hidden.npy"), ("response_sha256", "responses.npy")):
        value = sha(out / name)
        assert value == feature_record[key], f"Actual held-out file hash mismatch: {name}"
        actual_hashes[name] = value
        data = np.load(out / name, mmap_mode="r")
        assert list(data.shape) == expected_shapes[Path(name).stem]
        for start in range(0, len(data), 64):
            block = np.array(data[start:start + 64])
            assert np.isfinite(block).all()
            if name == "hidden.npy":
                assert np.all(np.max(np.abs(block), axis=(1, 2)) > 0)
    assert sum(w["rows"] for w in feature_record["workers"]) == protocol["retained_rows"]
    rows = pd.read_csv(out / "memberships.csv")
    expected_ids = set(rows.condition_id)
    scores = {}
    for seed in protocol["seeds"]:
        scores[seed] = {}
        for design_id, reference in protocol["checkpoints"][str(seed)].items():
            path = out / f"scores/seed{seed}/{design_id}.json"
            scored = read_json(path)
            assert scored["seed"] == seed and scored["design_id"] == design_id
            assert scored["checkpoint_sha256"] == reference["checkpoint_sha256"]
            assert sha(reference["checkpoint"]) == reference["checkpoint_sha256"]
            assert scored["best_round"] == reference["best_round"]
            assert scored["protocol_sha256"] == sha(out / "protocol.json")
            value = scored["heldout"]
            frame = pd.DataFrame(value["per_gene"])
            assert set(frame.condition_id) == expected_ids and len(frame) == len(rows)
            assert (frame.n_rosters == 5).all()
            assert frame.groupby(["context", "gene"]).size().max() == 1
            assert abs(frame.groupby("context").top1.mean().mean() - value["primary"]) < 1e-12
            assert abs(frame.groupby("context").mrr.mean().mean() - value["mrr"]) < 1e-12
            assert abs(frame.groupby("context").ce.mean().mean() - value["loss"]) < 2e-7
            assert abs(frame.groupby("gene").top1.mean().mean() - value["global_gene_macro"]) < 1e-12
            scores[seed][design_id] = value
    report_path = out / "policy_report.json"
    report = read_json(report_path)
    for path, expected in report["score_sha256"].items():
        assert sha(path) == expected
    search = Path(protocol["search_root"])
    for name, policy in report["policies"].items():
        assert {r["seed"] for r in policy["per_seed"]} == set(protocol["seeds"])
        for row in policy["per_seed"]:
            seed = row["seed"]
            weights = row["selected_design_probabilities"]
            assert abs(sum(weights.values()) - 1) < 1e-12
            selections = read_json(search / f"seed{seed}/selections.json")
            controls = read_json(search / f"seed{seed}/controls.json")
            if name in selections:
                assert weights == {selections[name]["design_id"]: 1.}
            elif name == "fixed_D00":
                assert weights == {"D00": 1.}
            elif name in controls and "weights" in controls[name]:
                assert weights == controls[name]["weights"]
            elif name in controls and "design_id" in controls[name]:
                assert weights == {controls[name]["design_id"]: 1.}
            elif name.startswith("random_valid_fit_count_"):
                arm = name[len("random_valid_fit_count_"):]
                assert selections[arm]["invalid_slots"] == 0
                assert weights == controls["random"]["weights"]
            else:
                raise AssertionError(f"Unknown unregistered policy {name}")
            for metric in ("primary", "loss", "mrr", "global_gene_macro"):
                expected = sum(weight * scores[seed][design][metric] for design, weight in weights.items())
                assert abs(expected - row[metric]) < 1e-12
        values = [r["primary"] for r in policy["per_seed"]]
        assert abs(np.mean(values) - policy["primary"]) < 1e-12
        assert abs(np.std(values, ddof=1) - policy["across_training_controller_seed_sd"]) < 1e-12
    receipt = dict(status="PASS", created_unix=time.time(), scoring_fits=sum(len(v) for v in scores.values()),
        heldout_rows=protocol["retained_rows"], heldout_genes=protocol["retained_genes"],
        checked_actual_heldout_file_hashes=actual_hashes, features_complete_sha256=sha(out / "features_complete.json"),
        policy_report_sha256=sha(report_path), verified_policies=sorted(report["policies"]),
        checks=["Actual feature/response SHA against saved receipt", "All arrays finite and every feature row written",
                "All 48 checkpoint identities and development-selected rounds", "Per-gene and per-context metric arithmetic",
                "Every policy exactly uses sealed development selections or random probabilities", "All three seeds included and correct sample SD"],
        model_selection_changed=False, source_sha256=sha(__file__))
    save_json(out / "verification.json", receipt)
    return receipt


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parents[2] / "results/history_repair_20261109/training_heldout_genetic_v1")
    args = parser.parse_args()
    value = verify(args.out)
    print(value["status"], value["scoring_fits"], value["verified_policies"])
