"""Synthetic/metadata-only tests; these never read test expression."""
import unittest
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from training_heldout import rosters_from_metadata, paired_cluster_bootstrap, authorize
from training_cache import choice_metrics


class HeldoutTests(unittest.TestCase):
    def test_rosters_fixed_and_context_local(self):
        frame = pd.DataFrame(dict(feature_id=np.arange(12), scenario_id=["a"] * 6 + ["b"] * 6))
        first = rosters_from_metadata(frame)
        self.assertEqual(first, rosters_from_metadata(frame))
        for context, roster in first.items():
            pool = set(frame.loc[frame.scenario_id == context, "feature_id"])
            self.assertEqual(len(roster["truth"]), 30)
            for truth, choices in zip(roster["truth"], roster["choices"]):
                self.assertEqual(choices.count(truth), 1)
                self.assertEqual(len(set(choices)), 5)
                self.assertTrue(set(choices) <= pool)

    def test_authorization_is_required_before_file_access(self):
        with self.assertRaises(PermissionError):
            authorize(Path("/nonexistent/heldout"), None)

    def test_nontruth_responses_are_not_used(self):
        pred = torch.tensor([[1., 0., 0.], [0., 1., 0.], [0., 0., 1.]])
        response = pred.clone()
        first = choice_metrics(pred, response, torch.tensor([0]), torch.tensor([[1, 0, 2]]), torch.tensor([-1, -1, -1]))
        response[1:] = 999
        second = choice_metrics(pred, response, torch.tensor([0]), torch.tensor([[1, 0, 2]]), torch.tensor([-1, -1, -1]))
        np.testing.assert_array_equal(first[0], second[0])
        np.testing.assert_array_equal(first[1], second[1])

    def test_paired_bootstrap_preserves_constant_difference(self):
        base = np.tile(np.linspace(.1, .7, 20), (3, 4, 1))
        better = base + .1
        point, draws = paired_cluster_bootstrap({"base": base, "better": better}, replicates=100)
        self.assertAlmostEqual(point["better"] - point["base"], .1)
        np.testing.assert_allclose(draws["better"] - draws["base"], .1, atol=1e-12)
        self.assertEqual(len(draws["base"]), 100)

    def test_missing_gene_context_does_not_change_pairing(self):
        base = np.tile(np.linspace(.1, .7, 20), (3, 4, 1))
        base[:, 1, :3] = np.nan
        point, draws = paired_cluster_bootstrap({"a": base, "b": base.copy()}, replicates=100)
        self.assertEqual(point["a"], point["b"])
        np.testing.assert_array_equal(draws["a"], draws["b"])


if __name__ == "__main__":
    torch.set_num_threads(2)
    unittest.main()
