"""Pure, development-only evidence projections for a matched prompt experiment.

No filesystem, model, scorer, or transport access. ``history`` contains D00 and
only candidates requested so far, in execution order. Candidate-request slots
exclude D00. The caller owns the immutable training/selection protocol.
"""

from copy import deepcopy
import math
import re


MODES = ("direct", "legacy", "raw", "structured")
OBJECTIVE = (
    "Use the remaining candidate-request budget to maximize the final retained "
    "development primary score, with lower development loss breaking exact "
    "primary-score ties. Predicting an outcome correctly is not itself a model "
    "improvement. Use the exact supplied ID/configuration facts."
)
SELECTION_RULE = "maximize (development.primary, -development.loss); exact ties retain incumbent"
LEGACY_FIELDS = (
    "config", "accepted", "hypothesis", "reused_fit", "development", "best_round",
    "training_diagnostics", "status", "diagnosis", "invalid",
)
RATIONALE_FIELDS = ("hypothesis", "experiment", "expected_effect", "rationale", "prediction")
FAILED = {"NUMERICAL_FAILURE", "FAILED", "FAILURE", "INVALID", "ERROR", "INCOMPLETE"}
DIAGNOSTIC_FIELDS = (
    "mse", "prediction_rms", "target_rms", "prediction_target_rms_ratio",
    "mean_pairwise_prediction_cosine", "mrr", "queries", "genes", "unique_genes",
    "global_gene_macro",
)


def reject_test_fields(value, path="root"):
    """Reject forbidden keys, including under unknown/dropped input fields.

    This is a schema boundary, not a claim that free-text provenance can be
    verified automatically. Callers must still use development-only sources.
    """
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise ValueError(f"Non-string evidence key at {path}")
            normalized = re.sub(r"([a-z])([A-Z])", r"\1_\2", key).lower()
            if re.search(r"(^|_)(test|heldout|held_out)(_|$)", normalized):
                raise ValueError(f"Forbidden test/held-out field: {path}.{key}")
            reject_test_fields(item, f"{path}.{key}")
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            reject_test_fields(item, f"{path}[{index}]")


def _finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _clean(value):
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    if isinstance(value, dict):
        return {key: _clean(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_clean(item) for item in value]
    raise ValueError("Evidence must consist of JSON-compatible values")


def _metrics(value):
    if not isinstance(value, dict):
        return None
    result = {key: float(value[key]) if _finite(value.get(key)) else None
              for key in ("primary", "loss")}
    return result


def _valid_metrics(value):
    return value is not None and all(_finite(value.get(key)) for key in ("primary", "loss"))


def _diagnostics(value):
    """Only recorded, aggregate development diagnostics; never response rows."""
    if not isinstance(value, dict):
        return {}
    result = {key: value[key] for key in DIAGNOSTIC_FIELDS if _finite(value.get(key))}
    if isinstance(value.get("per_context"), dict):
        result["per_context"] = {
            label: {"development": _metrics(metrics), "diagnostics": _diagnostics(metrics)}
            for label, metrics in value["per_context"].items() if isinstance(metrics, dict)}
    return result


def _changes(reference, candidate):
    return [{"field": key, "before": deepcopy(reference.get(key)), "after": deepcopy(candidate.get(key))}
            for key in sorted(set(reference) | set(candidate)) if reference.get(key) != candidate.get(key)]


def _identifier(config, designs):
    matches = [key for key, value in designs.items() if value == config]
    if len(matches) != 1:
        raise ValueError("A supplied configuration must match exactly one registered design")
    return matches[0]


def _rationale(row, key):
    if key in row:
        return _clean(row[key])
    proposal = row.get("proposal")
    return _clean(proposal.get(key)) if isinstance(proposal, dict) else None


def _snapshot(row):
    return {key: deepcopy(row.get(key)) for key in ("design_id", "config", "development", "best_round")}


def _trajectory(row):
    """Whitelist actual aggregate development observations, not arbitrary history."""
    raw = row.get("development_trajectory")
    if raw is None:
        raw = row.get("trajectory", row.get("history"))
    points = []
    if isinstance(raw, list):
        for item in raw:
            if not isinstance(item, dict) or "development" not in item:
                continue
            metrics = _metrics(item["development"])
            if not _valid_metrics(metrics) or not _finite(item.get("round")):
                continue
            point = {"round": item["round"], "development": metrics}
            diagnostics = _diagnostics(item["development"])
            if diagnostics:
                point["development_diagnostics"] = diagnostics
            if _finite(item.get("train_loss")):
                point["train_loss"] = item["train_loss"]
            if isinstance(item.get("train_loss_by_context"), dict):
                point["train_loss_by_context"] = {key: value for key, value in item["train_loss_by_context"].items()
                                                  if _finite(value)}
            if isinstance(item.get("diagnostic_only"), bool):
                point["diagnostic_only"] = item["diagnostic_only"]
            points.append(point)
    if points:
        return {"availability": "recorded_development_points", "points": points}
    diagnostics = row.get("training_diagnostics")
    if not isinstance(diagnostics, dict):
        return {"availability": "unavailable", "points": []}
    for label in ("first", "last"):
        item = diagnostics.get(label)
        if not isinstance(item, dict) or not _finite(item.get("round")):
            continue
        metrics = _metrics(item.get("development"))
        if not _valid_metrics(metrics):
            continue
        point = {"round": item["round"], "development": metrics}
        if _finite(item.get("train_loss")):
            point["train_loss"] = item["train_loss"]
        if point not in points:
            points.append(point)
    return {"availability": "recorded_endpoints_only" if points else "unavailable", "points": points}


def _panel_evidence(row):
    """Require explicit recorded panel/lab labels; never derive from a mean/min."""
    for field in ("per_panel_development", "per_lab_development"):
        values = row.get(field)
        if values is None:
            continue
        if not isinstance(values, list):
            raise ValueError(f"{field} must be an explicitly labelled list")
        clean = []
        for item in values:
            if not isinstance(item, dict) or not any(key in item for key in ("panel_id", "lab_id")):
                raise ValueError("Per-panel/lab evidence requires recorded panel_id or lab_id")
            metrics = _metrics(item.get("development"))
            if not _valid_metrics(metrics):
                raise ValueError("Per-panel/lab evidence requires finite development primary and loss")
            clean.append({**{key: _clean(item[key]) for key in ("panel_id", "lab_id") if key in item},
                          "development": metrics})
        return {"availability": "recorded", "unit": "panel" if field.startswith("per_panel") else "lab",
                "values": clean}
    return {"availability": "unavailable", "values": []}


def _prediction_result(prediction, reference, observed):
    result = {"status": "unavailable", "reason": "no_evaluable_recorded_prediction"}
    if not isinstance(prediction, dict) or set(prediction) != {"metric", "direction", "min_delta"}:
        return result
    metric, direction, threshold = (prediction[key] for key in ("metric", "direction", "min_delta"))
    if metric not in ("primary", "loss") or direction not in ("increase", "decrease") or \
            not _finite(threshold) or threshold < 0:
        return result
    if not _valid_metrics(reference) or not _valid_metrics(observed):
        return {"status": "unavailable", "reason": "missing_reference_or_candidate_development"}
    delta = observed[metric] - reference[metric]
    directed = delta if direction == "increase" else -delta
    met = directed > 0 and (directed >= threshold or math.isclose(directed, threshold, rel_tol=1e-12, abs_tol=0))
    return {"status": "met" if met else "unmet", "metric": metric, "direction": direction,
            "min_delta": threshold, "reference": reference[metric], "observed": observed[metric],
            "delta": delta, "interpretation": "prediction agreement, not candidate acceptance"}


def build_evidence_card(history, mode, *, designs, default_id="D00", evaluation_scope, total_slots=6):
    """Construct one matched prompt card without mutating its inputs.

    Minimal history example (also used in tests)::

        [{"design_id": "D00", "config": designs["D00"],
          "development": {"primary": .4, "loss": 1.2}, "accepted": True}]

    Rows may add flat rationale fields or a nested ``proposal``; ``reference``
    is an optional frozen proposal-time config/development snapshot. Baseline
    is outside ``total_slots``. Invalid output slots have ``invalid`` and no
    design ID. Valid but numerically failed fits still consume their design.
    """
    if mode not in MODES:
        raise ValueError(f"mode must be one of {MODES}")
    if not isinstance(total_slots, int) or isinstance(total_slots, bool) or total_slots < 0:
        raise ValueError("total_slots must be a nonnegative integer")
    if not isinstance(history, list) or not history or len(history) - 1 > total_slots:
        raise ValueError("history must contain baseline and at most total_slots candidate requests")
    if not isinstance(designs, dict) or default_id not in designs:
        raise ValueError("designs must contain the default ID")
    if not evaluation_scope or not isinstance(evaluation_scope, (str, dict)):
        raise ValueError("An explicit evaluation_scope is required")
    reject_test_fields({"history": history, "designs": designs, "evaluation_scope": evaluation_scope})
    rows = []
    seen = []
    for index, raw in enumerate(history):
        if not isinstance(raw, dict):
            raise ValueError("Every history row must be a dictionary")
        row = _clean(raw)
        proposal = row.get("proposal") if isinstance(row.get("proposal"), dict) else {}
        identifier = row.get("design_id", proposal.get("design_id"))
        config = row.get("config", proposal.get("config"))
        if config is not None:
            actual_id = _identifier(config, designs)
            if identifier is not None and identifier != actual_id:
                raise ValueError("Recorded design_id contradicts its configuration")
            identifier = actual_id
        elif identifier is not None:
            if identifier not in designs:
                raise ValueError("Unregistered design ID")
            config = deepcopy(designs[identifier])
        elif index == 0 or not row.get("invalid"):
            raise ValueError("Only an invalid-output slot may omit both ID and configuration")
        if identifier is not None:
            if identifier in seen:
                raise ValueError("Repeated valid design ID in history")
            seen.append(identifier)
        row.update(design_id=identifier, config=config)
        best = row.get("best") if isinstance(row.get("best"), dict) else {}
        raw_development = row.get("development", best.get("development"))
        row["development"] = _metrics(raw_development)
        row["development_diagnostics"] = _diagnostics(raw_development)
        row["best_round"] = row.get("best_round", best.get("round"))
        rows.append(row)
    if rows[0]["design_id"] != default_id or not _valid_metrics(rows[0]["development"]):
        raise ValueError("The first row must be the default design with valid development evidence")

    default = deepcopy(designs[default_id])
    available = {key: deepcopy(value) for key, value in designs.items() if key not in seen}
    card = dict(objective=OBJECTIVE, evaluation_scope=deepcopy(evaluation_scope),
                selection_rule=SELECTION_RULE,
                budget=dict(total_candidate_requests=total_slots, completed_candidate_requests=len(rows)-1,
                            remaining_candidate_requests=total_slots-(len(rows)-1), baseline_is_separate=True),
                default_design=dict(design_id=default_id, config=default),
                available_designs=available,
                available_changes_from_default={key: _changes(default, value) for key, value in available.items()},
                tried_design_ids=list(seen),
                invalid_output_slots=[index for index, row in enumerate(rows) if row.get("invalid")])
    if mode == "direct":
        # Do not leak whether any attempted fit succeeded or improved through
        # statuses, current reference, diagnostic strings, or rationale.
        card.update(reference_config=default, evidence="No development outcome feedback.")
        return card

    incumbent = rows[0]
    structured = []
    raw_facts = []
    for index, row in enumerate(rows):
        before = incumbent
        valid = _valid_metrics(row["development"]) and not row.get("invalid") and row.get("status") not in FAILED
        accepted = index == 0 or (valid and (row["development"]["primary"], -row["development"]["loss"]) >
                                  (incumbent["development"]["primary"], -incumbent["development"]["loss"]))
        reference = row.get("reference")
        if not isinstance(reference, dict):
            reference = _snapshot(before)
        reference_metrics = _metrics(reference.get("development"))
        reference_config = reference.get("config")
        if not isinstance(reference_config, dict):
            reference_config = before["config"]
        reference = dict(design_id=_identifier(reference_config, designs),
                         config=deepcopy(reference_config), development=reference_metrics,
                         best_round=reference.get("best_round"))
        changes = _changes(reference_config, row["config"]) if row["config"] is not None else []
        delta = ({key: row["development"][key] - reference_metrics[key] for key in ("primary", "loss")}
                 if valid and _valid_metrics(reference_metrics) else None)
        points = _trajectory(row)
        panels = _panel_evidence(row)
        prediction = _rationale(row, "prediction")
        result = _prediction_result(prediction, reference_metrics, row["development"] if valid else None)
        unknown = []
        if result["status"] == "unavailable":
            unknown.append("prior_expectation_not_quantitatively_evaluable")
        if points["availability"] != "recorded_development_points":
            unknown.append("interior_learning_trajectory_unavailable")
        if panels["availability"] != "recorded":
            unknown.append("per_panel_or_per_lab_effect_unavailable")
        if len(changes) > 1:
            unknown.append("individual_changed_factor_effects_not_isolated")
        facts = dict(trial=index, design_id=row["design_id"], config=deepcopy(row["config"]),
                    status=row.get("status", "INVALID_OUTPUT" if row.get("invalid") else
                                   "COMPLETE" if valid else "INCOMPLETE"),
                    development=deepcopy(row["development"]),
                    development_diagnostics=deepcopy(row["development_diagnostics"]),
                    best_round=row["best_round"], reference=deepcopy(reference),
                    trajectory=points, panel_evidence=panels)
        if "accepted" in row:
            facts["recorded_accepted"] = row["accepted"]
        if isinstance(row.get("training_diagnostics"), dict):
            facts["recorded_endpoint_diagnostics"] = {
                key: row["training_diagnostics"][key] for key in
                ("primary_gain_last_minus_first", "loss_change_last_minus_first")
                if _finite(row["training_diagnostics"].get(key))}
        for key in RATIONALE_FIELDS:
            value = _rationale(row, key)
            if value is not None:
                facts[key] = value
        for key in ("invalid", "diagnosis"):
            if row.get(key) is not None:
                facts[key] = row[key]
        raw_facts.append(facts)
        item = dict(deepcopy(facts), accepted=bool(accepted), actual_changes=changes,
                    development_delta=delta, prediction_result=result, unresolved_evidence=unknown)
        structured.append(item)
        if accepted:
            incumbent = row
    card["reference_config"] = deepcopy(incumbent["config"])
    if mode == "legacy":
        # Both arms share sanitation/ownership labels. In particular, never
        # propagate nested-evaluator clients=1/worst_client=mean as lab facts.
        evidence = []
        for index, row in enumerate(rows):
            entry = {key: deepcopy(row[key]) for key in LEGACY_FIELDS if key in row}
            if entry.get("training_diagnostics") is not None:
                diagnostics = entry["training_diagnostics"]
                entry["training_diagnostics"] = {
                    key: deepcopy(diagnostics[key]) for key in
                    ("primary_gain_last_minus_first", "loss_change_last_minus_first") if key in diagnostics}
                for label in ("first", "last"):
                    point = diagnostics.get(label)
                    if isinstance(point, dict):
                        entry["training_diagnostics"][label] = {
                            key: deepcopy(point[key]) for key in ("round", "train_loss") if key in point}
                        entry["training_diagnostics"][label]["development"] = _metrics(point.get("development"))
            entry["trial"] = index
            evidence.append(entry)
        card["evidence"] = evidence
    elif mode == "raw":
        # The exact same source facts as structured; no additional observation
        # is reserved for the structured arm. Only deterministic organization
        # and derivations differ. Legacy is a separate, lower-information arm.
        card["evidence"] = dict(trials=raw_facts)
    else:
        card["evidence"] = dict(current_incumbent=_snapshot(incumbent), trials=structured)
    return _clean(card)
