from collections import Counter
import itertools
import math
import random
import unittest

from extensions.history_repair_20261109 import controls as c


def records(values):
    return {key: dict(development=dict(primary=primary, loss=loss))
            for key, (primary, loss) in values.items()}


def menu16():
    configs = list(itertools.product((1e-5, 3e-5, 1e-4, 3e-4),
                                    ("full", "residual"), ("mse", "mse_contrastive")))
    return {f"D{i:02d}": dict(lr=lr, head=head, objective=loss,
                              weight_decay=.001, server_momentum=0.)
            for i, (lr, head, loss) in enumerate(configs)}


class RandomControlTests(unittest.TestCase):
    def test_uniform_orders_exact_ties(self):
        grid = records(dict(D00=(0, 1), D01=(2, 1), D02=(2, 1), D03=(1, 0), D04=(0, 0)))
        weights, count = c.exact_random_weights(grid, budget=2)
        counts = Counter(max(["D00", *order], key=lambda key: c.score_key(grid[key]))
                         for order in itertools.permutations(sorted(set(grid) - {"D00"}), 2))
        self.assertEqual(count, 6)
        for key, value in counts.items():
            self.assertAlmostEqual(weights[key], value / sum(counts.values()))

    def test_early_baseline_and_fixed_first_win_exact_ties(self):
        equal = records(dict(D00=(2, 1), D01=(2, 1), D02=(1, 0)))
        self.assertEqual(c.exact_random_weights(equal, 2)[0], {"D00": 1.})
        grid = records(dict(D00=(0, 1), D01=(2, 1), D02=(2, 1), D03=(1, 1)))
        self.assertEqual(c.exact_random_weights(grid, 2, "D01"), ({"D01": 1.}, 2))

    def test_conditional_first_matches_all_orders(self):
        grid = records({f"D{i:02d}": (i // 2, 1) for i in range(7)})
        weights, count = c.exact_random_weights(grid, 3, "D01")
        counts = Counter(max(["D00", "D01", *order], key=lambda key: c.score_key(grid[key]))
                         for order in itertools.permutations(sorted(set(grid) - {"D00", "D01"}), 2))
        self.assertEqual(count, 10)
        for key, value in counts.items():
            self.assertAlmostEqual(weights[key], value / sum(counts.values()))

    def test_16_design_5005_subsets_and_best_inclusion(self):
        grid = records({f"D{i:02d}": (i / 16, 1) for i in range(16)})
        weights, count = c.exact_random_weights(grid)
        self.assertEqual(count, 5005)
        self.assertAlmostEqual(sum(weights.values()), 1.)
        self.assertAlmostEqual(weights["D15"], 6 / 15)
        self.assertEqual(c.exact_random_weights(grid, first="D04")[1], math.comb(14, 5))

    def test_prefix_curve_and_policy_sd(self):
        grid = records({f"D{i:02d}": (i / 16, 1) for i in range(16)})
        curve = c.random_prefix_curve(grid)
        self.assertEqual([row["budget"] for row in curve], list(range(1, 7)))
        self.assertEqual([row["subsets"] for row in curve], [math.comb(15, k) for k in range(1, 7)])
        means = [row["expected_development"]["primary"] for row in curve]
        self.assertEqual(means, sorted(means))
        self.assertGreater(curve[0]["policy_sd"]["primary"], 0)
        self.assertEqual(curve[0]["policy_sd"]["loss"], 0)
        self.assertEqual(c.random_prefix_curve(grid, max_budget=3), curve[:3])

    def test_zero_budget_and_loss_tiebreak(self):
        grid = records(dict(D00=(2, 1), D01=(2, 0), D02=(1, -2)))
        self.assertEqual(c.exact_random_weights(grid, 0), ({"D00": 1.}, 1))
        self.assertEqual(c.exact_random_weights(grid, 2)[0], {"D01": 1.})

    def test_invalid_budget_first_and_baseline(self):
        grid = records(dict(D00=(1, 1), D01=(2, 1)))
        for budget, first in ((6, None), (-1, None), (True, None), (1, "D00"), (0, "D01"), (1, "bad")):
            with self.assertRaises(ValueError):
                c.exact_random_weights(grid, budget, first)
        with self.assertRaises(ValueError):
            c.exact_random_weights({"D01": grid["D01"]}, 0)

    def test_metrics_finite_and_no_test_fields(self):
        for record in ({"development": {"primary": float("nan"), "loss": 1}},
                       {"development": {"primary": .5, "loss": float("inf")}},
                       {"development": {"primary": True, "loss": 1}},
                       {"development": {"primary": .5, "loss": 1}, "aux": {"test_score": .9}},
                       {"development": {"primary": .5, "loss": 1}, "heldOut": {"score": .9}},
                       {"development": {"primary": .5, "loss": 1}, "test_expression_read": False},
                       {"development": {"primary": .5, "loss": 1}, "status": "NUMERICAL_FAILURE"}):
            with self.assertRaises(ValueError):
                c.score_key(record)

    def test_legacy_record_consistency(self):
        legacy = {"best": {"development": {"primary": .5, "loss": 1}}}
        self.assertEqual(c.score_key(legacy), (.5, -1.))
        legacy["development"] = {"primary": .6, "loss": 1}
        with self.assertRaises(ValueError):
            c.score_key(legacy)


class GPControlTests(unittest.TestCase):
    def test_features_are_menu_scaled_loglr_and_category_onehots(self):
        ids, rows, encoding = c.menu_features(menu16())
        self.assertEqual(ids, sorted(menu16()))
        self.assertEqual(len(rows[0]), 5)
        self.assertEqual([x["field"] for x in encoding], ["head", "lr", "objective"])
        self.assertEqual(encoding[1]["kind"], "log10_minmax")
        self.assertEqual(rows[0][2], 0)
        self.assertEqual(rows[-1][2], 1)
        self.assertAlmostEqual(rows[4][2], math.log10(3) / math.log10(30))
        renamed = {key: {("loss" if field == "objective" else field): value
                         for field, value in config.items()} for key, config in menu16().items()}
        self.assertIn("loss", [x["field"] for x in c.menu_features(renamed)[2]])

    def test_gp_only_requests_seven_chosen_records_and_uses_two_warmstarts(self):
        menu = menu16()
        requested = []
        def get_record(key):
            self.assertNotIn(key, requested)
            requested.append(key)
            return dict(design_id=key, config=menu[key], development=dict(primary=int(key[1:]) / 20, loss=1.))
        trace, selected, ids = c.select_gp(menu, get_record, seed=61)
        self.assertEqual(len(ids), 7)
        self.assertEqual(ids, requested)
        self.assertEqual(ids[0], "D00")
        self.assertEqual(ids[1:3], random.Random(61).sample(sorted(set(menu) - {"D00"}), 2))
        self.assertEqual(len(trace), 6)
        self.assertEqual(sum(row["acquisition"]["rule"] == "GP expected improvement" for row in trace), 4)
        self.assertEqual(selected, max(ids, key=lambda key: int(key[1:])))
        for index, row in enumerate(trace):
            self.assertEqual(row["acquisition"]["observed_ids"], ids[:index + 1])
            if "acquisition" in row["acquisition"]:
                self.assertEqual(set(row["acquisition"]["acquisition"]), set(menu) - set(ids[:index + 1]))

    def test_fixed_first_is_charged_and_exact_ties_keep_baseline(self):
        menu = menu16()
        def get_record(key):
            return dict(development=dict(primary=.5, loss=1.))
        trace, selected, ids = c.select_gp(menu, get_record, seed=9, first="D09")
        self.assertEqual(len(ids), 7)
        self.assertEqual(ids[:2], ["D00", "D09"])
        self.assertEqual(trace[0]["acquisition"]["rule"], "fixed shared first")
        self.assertEqual(selected, "D00")
        self.assertEqual(c.select_gp(menu, get_record, seed=9, budget=0), ([], "D00", ["D00"]))

    def test_repeated_gp_is_deterministic_without_hidden_callbacks(self):
        menu = menu16()
        a, b = [], []
        def callback(sink):
            def get_record(key):
                sink.append(key)
                return dict(development=dict(primary=(int(key[1:]) % 7) / 10, loss=1.))
            return get_record
        one = c.select_gp(menu, callback(a), seed=17)
        two = c.select_gp(menu, callback(b), seed=17)
        self.assertEqual(one, two)
        self.assertEqual(a, b)

    def test_bad_record_stops_at_requested_candidate(self):
        menu = menu16()
        requests = []
        def bad(key):
            requests.append(key)
            return dict(development=dict(primary=.5, loss=1.), metadata={"heldout": 42})
        with self.assertRaises(ValueError):
            c.select_gp(menu, bad, seed=1)
        self.assertEqual(requests, ["D00"])

    def test_returned_id_or_config_mismatch_rejected(self):
        menu = menu16()
        for extra in ({"design_id": "D01"}, {"config": menu["D01"]}):
            with self.assertRaises(ValueError):
                c.select_gp(menu, lambda key: dict(development=dict(primary=.5, loss=1.), **extra), seed=1)

    def test_menu_rejects_outcomes_duplicate_config_and_invalid_lr(self):
        menu = menu16()
        menu["D01"] = dict(menu["D00"])
        with self.assertRaises(ValueError):
            c.menu_features(menu)
        for value in (0., -1., float("inf")):
            menu = menu16()
            menu["D00"]["lr"] = value
            with self.assertRaises(ValueError):
                c.menu_features(menu)
        menu = menu16()
        menu["D00"]["test_score"] = .9
        with self.assertRaises(ValueError):
            c.menu_features(menu)


if __name__ == "__main__":
    unittest.main()
