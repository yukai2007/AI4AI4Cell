"""Read sealed search records and write independent, development-only summaries.

No training, generation, candidate selection, or held-out evaluation is run here.
All requested seed seals must exist before any seed results are read. Derived
reports are separate from frozen inputs. Exact-random fitting cost uses candidate
INCLUSION probabilities, never probabilities of the finally selected checkpoint.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from extensions.history_repair_20261109.controls import exact_random_weights, score_key

DEFAULT_ROOT = ROOT / "results/history_repair_20261109/search_genetic_v2"
COST_FIELDS = {
    "rounds": "rounds", "optimizer_steps": "actual_optimizer_steps",
    "examples_seen": "actual_examples_seen", "measured_fit_seconds_sum": "seconds",
    "measured_fit_gpu_hours_sum": "allocated_gpu_hours",
}
USAGE_FIELDS = ("input_tokens", "output_tokens", "generation_seconds", "total_attempt_seconds")


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def checked(path, expected):
    if sha(path) != expected:
        raise ValueError(f"Sealed input changed: {path}")
    return read(path)


def absolute(path, project_root=ROOT):
    path = Path(path)
    return path if path.is_absolute() else Path(project_root) / path


def mean_sd(values):
    values = list(values)
    if not values or any(not math.isfinite(value) for value in values):
        raise ValueError("Finite observations required")
    return dict(n=len(values), mean=statistics.mean(values),
                sample_sd=statistics.stdev(values) if len(values) > 1 else None)


def metrics(record):
    # Deliberately project only known development metrics from the fit receipt.
    value = record["development"]
    key = score_key(dict(development={k: value[k] for k in ("primary", "loss")}))
    return dict(primary=key[0], loss=-key[1])


def fit_cost(grid, inclusion):
    """Expected cost of attempted fits, or actual equivalent cost for 0/1 inclusion."""
    if any(key not in grid or not math.isfinite(p) or not 0 <= p <= 1 for key, p in inclusion.items()):
        raise ValueError("Invalid fitting inclusion probabilities")
    result = dict(candidate_fit_count=math.fsum(inclusion.values()))
    for output_name, input_name in COST_FIELDS.items():
        values = []
        for key, probability in inclusion.items():
            value = grid[key][input_name]
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
                raise ValueError(f"Invalid recorded fitting cost: {key}.{input_name}")
            values.append(probability * value)
        result[output_name] = math.fsum(values)
    return result


def random_inclusion_weights(ids, budget=6, first=None):
    ids = set(ids)
    if "D00" not in ids or type(budget) is not int or not 0 <= budget <= len(ids) - 1:
        raise ValueError("Invalid random budget or missing baseline")
    if first is not None and (first == "D00" or first not in ids or budget < 1):
        raise ValueError("Invalid fixed first candidate")
    fixed = {"D00"} | ({first} if first is not None else set())
    remaining = ids - fixed
    draws = budget - int(first is not None)
    probability = draws / len(remaining) if remaining else 0.
    return {key: 1. if key in fixed else probability for key in sorted(ids)}


def random_summary(grid, budget=6, first=None, recorded=None):
    normalized = {key: dict(development=metrics(value)) for key, value in grid.items()}
    weights, subsets = exact_random_weights(normalized, budget, first)
    if recorded is not None:
        if (recorded["subsets"] != subsets or set(recorded["weights"]) != set(weights)
                or any(abs(recorded["weights"][key] - value) > 1e-12 for key, value in weights.items())):
            raise ValueError("Stored random distribution differs from its exact definition")
    dev = {name: math.fsum(weight * normalized[key]["development"][name] for key, weight in weights.items())
           for name in ("primary", "loss")}
    sd = {name: math.sqrt(math.fsum(weight * (normalized[key]["development"][name] - dev[name]) ** 2
                                  for key, weight in weights.items())) for name in dev}
    inclusion = random_inclusion_weights(grid, budget, first)
    return dict(development=dev, selected_weights=weights, subsets=subsets, first=first,
                proposal_budget=budget, conditional_search_policy_sd=sd,
                inclusion_probabilities=inclusion, fitting_cost=fit_cost(grid, inclusion),
                invalid_slots=0, llm_logical_usage=usage([]))


def usage(receipts):
    receipts = list(receipts)
    ids = [receipt["call_id"] for receipt in receipts]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate physical call ID in a usage group")
    result = dict(calls=len(receipts))
    for receipt in receipts:
        if receipt["status"] != "COMPLETE":
            raise ValueError("Unexpected transport failure in a sealed successful search")
    for field in USAGE_FIELDS:
        values = [receipt[field] for receipt in receipts]
        if any(isinstance(value, bool) or not isinstance(value, (int, float))
               or not math.isfinite(value) or value < 0 for value in values):
            raise ValueError(f"Missing/nonfinite measured usage: {field}")
        result[field] = sum(values)
    return result


def add_usage(groups):
    groups = list(groups)
    return {field: sum(group[field] for group in groups) for field in ("calls", *USAGE_FIELDS)}


def deterministic_summary(grid, selected, ids):
    if not ids or ids[0] != "D00" or len(ids) != len(set(ids)):
        raise ValueError("Each deterministic policy must begin with one unique D00")
    expected = max(ids, key=lambda key: score_key(dict(development=metrics(grid[key]))))
    if selected != expected:
        raise ValueError("Selection does not follow development score and earliest ties")
    return dict(design_id=selected, candidate_ids=ids, development=metrics(grid[selected]),
                fitting_cost=fit_cost(grid, {key: 1. for key in ids}), invalid_slots=0,
                llm_logical_usage=usage([]))


def validate_source_files(protocol, project_root):
    for path, digest in protocol.get("source_sha256", {}).items():
        resolved = absolute(path, project_root)
        if sha(resolved) != digest:
            raise ValueError(f"Frozen controller source changed: {resolved}")


def complete_fit_records(projected, training, registration_sha256, seed, project_root=ROOT):
    """The sealed grid is a projection; bind cost metadata to its full fit receipts."""
    complete, source_hashes = {}, {}
    for key, row in projected.items():
        checkpoint = absolute(row["checkpoint"], project_root)
        path = checkpoint.with_name("summary.json")
        fit = read(path)
        if any(name not in fit or value != fit[name] for name, value in row.items()):
            raise ValueError(f"Projected grid differs from full fit receipt: {key}")
        if (fit["seed"] != seed or fit["design_id"] != key or fit["config"] != training["candidates"][key]
                or fit["status"] != "COMPLETE" or fit["rounds"] != training["rounds"]
                or fit["actual_optimizer_steps"] != training["optimizer_steps_per_fit"]
                or fit["actual_examples_seen"] != training["examples_per_fit"]
                or fit["training_registration_sha256"] != registration_sha256
                or fit["source_sha256"] != training["source_sha256"]
                or fit["test_expression_read"] is not False
                or sha(checkpoint) != fit["checkpoint_sha256"]):
            raise ValueError(f"Fit identity/budget/checkpoint mismatch: {seed}/{key}")
        complete[key] = fit
        source_hashes[str(path)] = sha(path)
    return complete, source_hashes


def summarize_seed(search_root, seed, protocol, training, project_root=ROOT):
    base = search_root / f"seed{seed}"
    seal = read(base / "selection_seal.json")
    if seal.get("heldout_evaluation_read") is not False:
        raise ValueError("Expected a development-only selection seal")
    if seal["protocol_sha256"] != sha(search_root / "protocol.json"):
        raise ValueError("Protocol/seal hash mismatch")
    for path, digest in seal["transcript_sha256"].items():
        if sha(absolute(path, project_root)) != digest:
            raise ValueError(f"Sealed transcript changed: {path}")
    inputs = read(base / "inputs.json")
    if (inputs["protocol_sha256"] != seal["protocol_sha256"]
            or inputs["source_training_seed"] != seed or inputs["grid_sha256"] != seal["grid_sha256"]):
        raise ValueError("Input identity differs from selection seal")
    grid_path = absolute(inputs["grid_path"], project_root)
    grid = checked(grid_path, seal["grid_sha256"])
    selections = checked(base / "selections.json", seal["selections_sha256"])
    controls = checked(base / "controls.json", seal["controls_sha256"])
    menu = protocol["menu"]
    if set(grid) != set(menu):
        raise ValueError("Incomplete sealed fitting grid")
    grid, supporting_fit_sha256 = complete_fit_records(grid, training, protocol["training_sha256"], seed, project_root)
    for key, record in grid.items():
        metrics(record)
    physical_calls = [read(path) for path in sorted((base / "backend").glob("call_*.json"))]
    physical_usage = usage(physical_calls)
    if physical_usage["calls"] != seal["actual_llm_calls"]:
        raise ValueError("Physical call count differs from sealed count")
    physical_requests = [read(path) for path in sorted((base / "backend").glob("request_*.json"))]
    if sum(len(request["attempts"]) for request in physical_requests) != physical_usage["calls"]:
        raise ValueError("Physical request attempts do not sum to the sealed call count")
    calls_by_id = {receipt["call_id"]: receipt for receipt in physical_calls}
    shared = read(base / "shared_first.json")
    shared_usage = usage(shared["attempts"])
    policies = {"fixed": deterministic_summary(grid, "D00", ["D00"])}
    budget = protocol["candidate_budget"]
    for arm in protocol["arms"]:
        selection = selections[arm]
        item = deterministic_summary(grid, selection["design_id"], selection["candidate_ids"])
        requests = [read(base / arm / f"slot{slot}.json")["request"] for slot in range(1, budget + 1)]
        if requests[0] != shared:
            raise ValueError("First request was not physically shared across arms")
        attempts = [receipt for request in requests for receipt in request["attempts"]]
        for receipt in attempts:
            if receipt != calls_by_id.get(receipt["call_id"]):
                raise ValueError("Logical request is not backed by the sealed physical receipt")
        invalid = sum(not request["valid"] for request in requests)
        valid_ids = ["D00"] + [request["parsed"]["design_id"] for request in requests if request["valid"]]
        if invalid != selection["invalid_slots"] or valid_ids != selection["candidate_ids"]:
            raise ValueError("Logical request/fit count differs from selection")
        if selection["logical_training_rounds"] != item["fitting_cost"]["rounds"]:
            raise ValueError("Declared fitting rounds do not match all attempted candidates")
        prefix = [{key: value[key] for key in ("primary", "loss")} for value in selection["prefix_development"]]
        if len(prefix) != budget + 1 or prefix[-1] != item["development"]:
            raise ValueError("Incorrect saved prefix curve")
        item.update(invalid_slots=invalid, requested_slots=budget, prefix_development=prefix,
                    llm_logical_usage=usage(attempts),
                    exclusive_physical_llm_usage=usage([r for request in requests[1:] for r in request["attempts"]]),
                    shared_first_usage=shared_usage,
                    nominal_max_fit_rounds=(budget + 1) * training["rounds"])
        policies[arm] = item
    gp = controls["gp_ei"]
    item = deterministic_summary(grid, gp["design_id"], gp["candidate_ids"])
    if len(gp["candidate_ids"]) != budget + 1:
        raise ValueError("GP candidate budget differs")
    item["prefix_development"] = [metrics(grid["D00"])] + [row["incumbent_development"] for row in gp["trace"]]
    policies["gp_ei"] = item
    policies["random"] = random_summary(grid, budget, recorded=controls["random"])
    policies["random"]["prefix_development"] = [metrics(grid["D00"])] + [
        random_summary(grid, b)["development"] for b in range(1, budget + 1)]
    first = shared["parsed"]["design_id"] if shared["valid"] else None
    effective_budget = budget if first is not None else budget - 1
    policies["random_shared_first"] = random_summary(
        grid, effective_budget, first, controls["random_shared_first"])
    policies["random_shared_first"]["shared_failed_first_slot"] = first is None
    policies["random_shared_first"]["invalid_slots"] = int(first is None)
    policies["random_shared_first"]["requested_slots"] = budget
    policies["random_shared_first"]["llm_logical_usage"] = shared_usage
    for arm in protocol["arms"]:
        name = f"random_valid_fit_count_{arm}"
        if name in controls:
            policies[name] = random_summary(grid, len(selections[arm]["candidate_ids"]) - 1,
                                            recorded=controls[name])
    return dict(seed=seed, policies=policies, physical_llm_usage=physical_usage,
                physical_request_count=len(physical_requests),
                physical_invalid_requests=sum(not request["valid"] for request in physical_requests),
                shared_first_usage=shared_usage, physical_training_cache_cost=fit_cost(grid, {key: 1. for key in grid}),
                source_seal=str(base / "selection_seal.json"), source_seal_sha256=sha(base / "selection_seal.json"),
                grid_sha256=seal["grid_sha256"], supporting_fit_sha256=supporting_fit_sha256,
                actual_fits_are_shared_cache_not_policy_reruns=True,
                no_new_training_performed_by_search_or_report=True)


def summarize(search_root, *, project_root=ROOT, role=None):
    search_root = Path(search_root).resolve()
    protocol = read(search_root / "protocol.json")
    seeds = protocol["training_seeds"]
    missing = [seed for seed in seeds if not (search_root / f"seed{seed}" / "selection_seal.json").is_file()]
    if missing:
        raise FileNotFoundError("WAITING_SEALS: " + ", ".join(map(str, missing)))
    validate_source_files(protocol, project_root)
    training = checked(absolute(protocol["training_registration"], project_root), protocol["training_sha256"])
    runs = [summarize_seed(search_root, seed, protocol, training, project_root) for seed in seeds]
    names = sorted(set.intersection(*(set(row["policies"]) for row in runs)))
    aggregate = {}
    for name in names:
        rows = [run["policies"][name] for run in runs]
        entry = dict(development={metric: mean_sd(row["development"][metric] for row in rows)
                                  for metric in ("primary", "loss")},
                     fitting_cost={field: mean_sd(row["fitting_cost"][field] for row in rows)
                                   for field in rows[0]["fitting_cost"]},
                     invalid_slots=sum(row["invalid_slots"] for row in rows),
                     llm_logical_usage_total=add_usage(row["llm_logical_usage"] for row in rows))
        if all("prefix_development" in row for row in rows):
            entry["prefix_primary"] = [mean_sd(row["prefix_development"][slot]["primary"] for row in rows)
                                       for slot in range(protocol["candidate_budget"] + 1)]
        aggregate[name] = entry
    contrasts = {}
    for reference in ("raw", "direct", "random", "gp_ei"):
        differences = [run["policies"]["structured"]["development"]["primary"]
                       - run["policies"][reference]["development"]["primary"] for run in runs]
        contrasts[f"structured_minus_{reference}"] = dict(
            primary_difference=mean_sd(differences), per_seed=dict(zip(map(str, seeds), differences)),
            primary_wins=sum(x > 0 for x in differences), primary_ties=sum(x == 0 for x in differences),
            primary_losses=sum(x < 0 for x in differences))
    if role is None:
        role = "ENGINEERING_DIAGNOSTIC" if search_root.name.endswith("_v2") else "DEVELOPMENT_EVALUATION"
    return dict(schema="sealed-search-development-analysis-v1", role=role,
                search_root=str(search_root), protocol_sha256=sha(search_root / "protocol.json"),
                generated_utc=datetime.now(timezone.utc).isoformat(), source_sha256=sha(__file__),
                training_seeds=seeds, arms=protocol["arms"], budget=protocol["candidate_budget"],
                evaluation="pre-held-out development only; no held-out scorer/data read by this report",
                uncertainty="Across three paired training+generation seed runs: mean and sample SD; not independent large-sample evidence. Random-search policy SD is separate within each fixed training seed.",
                cost_interpretation="Policy fitting costs sum attempted cached fits (or inclusion-weighted sums); physical cache training is counted once. Logical LLM use includes the shared first call in each arm; actual use counts it once.",
                engineering_note=("v2 preserved as an engineering diagnostic: strict JSON decoding rejected wrapped output; do not interpret these failures as evidence for or against history efficacy."
                                  if role == "ENGINEERING_DIAGNOSTIC" else None),
                per_seed=runs, aggregate=aggregate, paired_contrasts=contrasts,
                physical_request_count=sum(run["physical_request_count"] for run in runs),
                physical_invalid_requests=sum(run["physical_invalid_requests"] for run in runs),
                physical_llm_usage_total=add_usage(run["physical_llm_usage"] for run in runs),
                physical_training_cache_cost_total={field: sum(run["physical_training_cache_cost"][field] for run in runs)
                                                    for field in runs[0]["physical_training_cache_cost"]})


def markdown(report):
    aggregate, runs = report["aggregate"], report["per_seed"]
    names = [name for name in ("fixed", "direct", "raw", "structured", "gp_ei", "random", "random_shared_first")
             if name in aggregate]
    labels = dict(fixed="D00 固定模型", direct="无结果反馈", raw="原始历史反馈", structured="结构化历史反馈",
                  gp_ei="GP-EI", random="精确 Random@6", random_shared_first="固定共同首候选 Random")
    lines = ["# 新异质细胞实验：已封存搜索结果", "", f"版本：`{Path(report['search_root']).name}`；状态：`{report['role']}`。", "",
             "本报告只分析开发集搜索结果。独立 held-out 评价由另外的流程生成；这里不据开发集结果宣称泛化增益。", ""]
    if report["role"] == "ENGINEERING_DIAGNOSTIC":
        lines += ["**本版保留为工程诊断。** v2 的严格 JSON 解码拒绝了部分带代码围栏等包装的输出；因此不能把本版格式失败解释为历史反馈机制的科学优劣。后续修复版单独封存、单独汇总，不覆盖本版。", ""]
    lines += ["## 开发集终点", "", "三个 seed 是训练种子与生成种子配对的三个运行。均值 ± 样本标准差不是大样本显著性结论；Random 的每个 seed 数字是精确搜索策略期望，搜索策略方差另存于 JSON。", "",
              "| 方法 | seed 61 | seed 62 | seed 63 | 均值 ± 样本 SD（%） | 无效提案槽数 / 18 |",
              "|---|---:|---:|---:|---:|---:|"]
    for name in names:
        values = [100 * run["policies"][name]["development"]["primary"] for run in runs]
        mean = aggregate[name]["development"]["primary"]
        sd = 100 * mean["sample_sd"] if mean["sample_sd"] is not None else float("nan")
        invalid = str(aggregate[name]["invalid_slots"]) if name in report["arms"] else "—"
        lines.append(f"| {labels[name]} | " + " | ".join(f"{x:.3f}" for x in values)
                     + f" | {100 * mean['mean']:.3f} ± {sd:.3f} | {invalid} |")
    lines += ["", "## 配对对比", "", "| 结构化反馈减去 | 平均差（百分点） | 差值样本 SD | 胜 / 平 / 负 |", "|---|---:|---:|---:|"]
    for reference in ("raw", "direct", "random", "gp_ei"):
        row = report["paired_contrasts"][f"structured_minus_{reference}"]
        value = row["primary_difference"]
        lines.append(f"| {labels[reference]} | {100*value['mean']:+.3f} | {100*value['sample_sd']:.3f} | {row['primary_wins']} / {row['primary_ties']} / {row['primary_losses']} |")
    lines += ["", "## 搜索过程", "", "每列为对应候选请求数后的开发集 Top-1 三 seed 均值（%）；0 为共同 D00，无效提案照样消耗请求槽。", "",
              "| 方法 | " + " | ".join(map(str, range(report["budget"] + 1))) + " |",
              "|---|" + "---:|" * (report["budget"] + 1)]
    for name in names:
        if "prefix_primary" in aggregate[name]:
            lines.append(f"| {labels[name]} | " + " | ".join(f"{100*v['mean']:.3f}" for v in aggregate[name]["prefix_primary"]) + " |")
    lines += ["", "各 seed 保留的设计与实际尝试：", ""]
    for run in runs:
        lines.append(f"- seed {run['seed']}：" + "；".join(
            f"{labels[name]} → {run['policies'][name]['design_id']}（{','.join(run['policies'][name]['candidate_ids'])}，无效槽 {run['policies'][name]['invalid_slots']}）"
            for name in (*report["arms"], "gp_ei")))
    lines += ["", "## 预算与实际成本", "", "下面是每个策略按实际尝试候选求和后的三 seed 平均等效成本，含 D00；不是只算最终 checkpoint。Random 用每个候选被尝试的入选概率加权，不使用胜出概率计算成本。", "",
              "| 方法 | fit 数 | 训练轮数 | optimizer steps | 训练样本曝光数 | 实测 fit 秒数求和 | GPU·小时 |",
              "|---|---:|---:|---:|---:|---:|---:|"]
    for name in names:
        cost = aggregate[name]["fitting_cost"]
        lines.append(f"| {labels[name]} | {cost['candidate_fit_count']['mean']:.2f} | {cost['rounds']['mean']:.1f} | {cost['optimizer_steps']['mean']:.1f} | {cost['examples_seen']['mean']:.1f} | {cost['measured_fit_seconds_sum']['mean']:.2f} | {cost['measured_fit_gpu_hours_sum']['mean']:.4f} |")
    physical = report["physical_training_cache_cost_total"]
    lines += ["", f"来源缓存的物理训练共 {physical['candidate_fit_count']:.0f} 个 fits，累计 {physical['rounds']:.0f} 轮、{physical['optimizer_steps']:.0f} optimizer steps、{physical['examples_seen']:.0f} 样本曝光，实测占卡时间 {physical['measured_fit_gpu_hours_sum']:.4f} GPU·小时。此处是候选预测头训练成本，不包含共享 encoder 特征缓存生成或数据准备。搜索与本报告没有新增训练；所有策略及使用同一缓存的不同搜索版本共享这些 fits，不能跨策略或跨版本重复相加作为实际训练开销。", "",
              "| LLM arm（三 seed 合计，逻辑） | 调用数 | 输入 tokens | 输出 tokens | 生成秒数 |",
              "|---|---:|---:|---:|---:|"]
    for name in report["arms"]:
        value = aggregate[name]["llm_logical_usage_total"]
        lines.append(f"| {labels[name]} | {value['calls']} | {value['input_tokens']} | {value['output_tokens']} | {value['generation_seconds']:.2f} |")
    actual = report["physical_llm_usage_total"]
    lines += ["", f"唯一物理 LLM 调用合计 **{actual['calls']} 次**，输入 {actual['input_tokens']} tokens、输出 {actual['output_tokens']} tokens，生成 {actual['generation_seconds']:.2f} 秒；对应 {report['physical_request_count']} 个唯一提案请求，其中 {report['physical_invalid_requests']} 个在有界修复后仍无效。每 seed 共同冷启动实际只调用一次，而在三个 arm 的逻辑用量中各记一次；表中逻辑调用不能直接相加当作物理总数。", "",
              "完整的单 seed 条件随机策略标准差、实际有效 fit 数匹配的 Random 对照、按候选入选概率计算的成本和逐 seed 成本均见对应 `search_analysis.json`。", "",
              "## 来源", "", f"搜索根目录：`{report['search_root']}`。所有 seed 的 selection seal、源代码 hash、输入 grid hash 和调用记录 hash 已逐项验证。未改动任何旧分数、冻结控制器或原始轨迹。", ""]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--search-root", type=Path, default=DEFAULT_ROOT)
    parser.add_argument("--output-prefix", type=Path)
    parser.add_argument("--role", choices=("ENGINEERING_DIAGNOSTIC", "DEVELOPMENT_EVALUATION"))
    args = parser.parse_args()
    try:
        report = summarize(args.search_root, role=args.role)
    except FileNotFoundError as error:
        print(json.dumps(dict(status="WAITING_SEALS_OR_INPUT", reason=str(error))))
        raise SystemExit(2)
    suffix = args.search_root.name.rsplit("_", 1)[-1]
    prefix = args.output_prefix or ROOT / "docs/history_repair_20261109" / f"SEARCH_RESULTS_{suffix}"
    if len(prefix.parts) == 1:
        prefix = ROOT / "docs/history_repair_20261109" / prefix
    output_json = args.search_root / "search_analysis.json"
    output_md = Path(str(prefix) + ".zh-CN.md")
    output_md.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    output_md.write_text(markdown(report))
    print(json.dumps(dict(status="REPORTED", role=report["role"], seeds=report["training_seeds"],
                         json=str(output_json), markdown=str(output_md),
                         actual_llm_calls=report["physical_llm_usage_total"]["calls"])))


if __name__ == "__main__":
    main()
