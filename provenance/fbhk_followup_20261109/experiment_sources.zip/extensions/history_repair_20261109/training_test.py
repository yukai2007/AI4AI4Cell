"""CPU unit tests for the new registered training/scoring boundary."""
import unittest

import numpy as np
import torch

from training_cache import candidates, choice_metrics, build_model
from training_data import ROOT


class TrainingTests(unittest.TestCase):
    def test_candidate_space(self):
        grid = candidates()
        self.assertEqual(len(grid), 16)
        self.assertEqual(grid["D00"]["lr"], 1e-4)
        self.assertEqual(grid["D00"]["head"], "full")
        self.assertEqual(grid["D00"]["objective"], "mse")
        self.assertEqual(len({tuple(sorted(c.items())) for c in grid.values()}), 16)
        self.assertTrue(all(c["server_momentum"] == 0 for c in grid.values()))

    def test_query_mask_is_shared_across_choices(self):
        # The first coordinate is a directly perturbed gene and must not make
        # the wrong candidate appear more similar to the observed response.
        pred = torch.tensor([[100., 0., 1.], [0., 1., 0.], [0., 1., 1.]])
        response = torch.tensor([[0., 1., 0.], [100., 0., 1.], [0., 1., 1.]])
        rank, loss = choice_metrics(pred, response, torch.tensor([1]), torch.tensor([[0, 1]]), torch.tensor([0, -1, -1]))
        self.assertEqual(rank.tolist(), [2])
        self.assertTrue(np.isfinite(loss).all())

    def test_ties_respect_option_order(self):
        pred = torch.tensor([[1., 1.], [1., 1.]])
        rank, _ = choice_metrics(pred, pred, torch.tensor([0]), torch.tensor([[1, 0]]), torch.tensor([-1, -1]))
        self.assertEqual(rank.tolist(), [2])

    def test_new_residual_shares_initial_predictions_and_freezes_base(self):
        weights = torch.load(ROOT / "data/scdebart_20260918/pretrained.pt", map_location="cpu", weights_only=True)
        initial = {k[len("logfc_head."):]: v.clone() for k, v in weights.items() if k.startswith("logfc_head.")}
        full = build_model(initial, {"head": "full"}, 61, "cpu")
        residual = build_model(initial, {"head": "residual"}, 61, "cpu")
        torch.manual_seed(1)
        x = torch.randn(2, 4, 768)
        torch.testing.assert_close(full(x), residual(x), rtol=0, atol=0)
        self.assertTrue(all(not p.requires_grad for p in residual.base.parameters()))
        self.assertTrue(all(p.requires_grad for p in residual.adapter.parameters()))


if __name__ == "__main__":
    torch.set_num_threads(2)
    unittest.main()
