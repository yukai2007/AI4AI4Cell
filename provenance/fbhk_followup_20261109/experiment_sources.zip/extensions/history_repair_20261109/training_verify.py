"""Read-only verification of the fresh train/development cache and budgets."""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from training_data import OUT, PANEL, read_json, save_json, sha


def verify(data):
    ready = read_json(data / "data_ready.json")
    registration = read_json(data / "training_registration.json")
    rows = pd.read_csv(data / "train_dev_memberships.csv")
    train, dev = rows[rows.planned_role == "train"], rows[rows.planned_role == "dev"]
    assert set(rows.planned_role) == {"train", "dev"}
    assert set(train.identity_group).isdisjoint(dev.identity_group)
    assert set(train.perturbation_gene_id).isdisjoint(dev.perturbation_gene_id)
    bulk_panel_path = Path("/liziqing/VitaCode_Dataset/CellUMM/Pert/00_manifest/gene_panel.parquet")
    bulk_panel = pd.read_parquet(bulk_panel_path).sort_values("index")
    supplied_panel = pd.read_csv(PANEL)
    assert np.array_equal(bulk_panel["index"].to_numpy(), supplied_panel.gene_index.to_numpy())
    assert np.array_equal(bulk_panel.gene_name.to_numpy(), supplied_panel.gene_name.to_numpy())
    assert len(rows) == ready["hidden_shape"][0]
    assert ready["raw_test_expression_read"] is False
    assert set(read_json(data / "panel_seal.json")["symbols"]).isdisjoint(train.perturbation)
    for name, value in registration["fixed_file_sha256"].items():
        assert sha(data / name) == value, name
    hidden = np.load(data / "hidden.npy", mmap_mode="r")
    response = np.load(data / "responses.npy", mmap_mode="r")
    assert list(hidden.shape) == ready["hidden_shape"]
    assert response.shape == hidden.shape[:2]
    for start in range(0, len(rows), 64):
        block = np.array(hidden[start:start + 64])
        assert np.isfinite(block).all()
        assert np.all(np.max(np.abs(block), axis=(1, 2)) > 0), "Unwritten feature rows"
    assert np.isfinite(response).all()
    features = read_json(data / "features_complete.json")
    assert sha(data / "hidden.npy") == features["hidden_sha256"]
    assert sum(worker["completed"] for worker in features["feature_workers"]) == len(rows)
    fit_rows = []
    for path in sorted(data.glob("fits/seed*/D*/summary.json")):
        fit = read_json(path)
        assert fit["rounds"] == registration["rounds"] == 20
        assert fit["actual_optimizer_steps"] == registration["optimizer_steps_per_fit"]
        assert fit["actual_examples_seen"] == registration["examples_per_fit"]
        assert fit["config"] == registration["candidates"][fit["design_id"]]
        assert fit["test_expression_read"] is False
        assert fit["best_round"] in registration["eligible_selection_rounds"]
        assert [r["round"] for r in fit["trajectory"]] == [0, 2, 5, 10, 20]
        assert sha(Path(fit["checkpoint"])) == fit["checkpoint_sha256"]
        selected = max(fit["trajectory"][1:], key=lambda r: (r["development"]["primary"], -r["development"]["loss"], -r["round"]))
        assert selected["round"] == fit["best_round"]
        assert selected["development"] == fit["development"]
        fit_rows.append(dict(seed=fit["seed"], design_id=fit["design_id"], primary=fit["development"]["primary"],
                             best_round=fit["best_round"], seconds=fit["seconds"]))
    result = dict(status="PASS", rows=len(rows), train_rows=len(train), dev_rows=len(dev),
                  train_genes=train.identity_group.nunique(), dev_genes=dev.identity_group.nunique(),
                  train_dev_global_gene_overlap=0, test_expression_read=False,
                  scdebart_train_dev_gene_id_overlap=0,
                  bulk_gene_order_identity="21523 names and positions exactly match the supplied encoder gene panel",
                  bulk_gene_panel_sha256=sha(bulk_panel_path),
                  feature_cache_sha256=features["hidden_sha256"], validated_fits=len(fit_rows), fits=fit_rows)
    save_json(data / "verification.json", result)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=OUT)
    args = parser.parse_args()
    result = verify(args.data)
    print(result["status"], "fits", result["validated_fits"], "rows", result["rows"])
