"""Standard-library-only tests; fixtures contain development metrics only."""

from copy import deepcopy
import json
import unittest

from extensions.history_repair_20261109.evidence_cards import build_evidence_card


# Minimal runner fixture: baseline does not consume a candidate-request slot.
DESIGNS = {
    "D00": {"lr": .001, "residual": False},
    "D01": {"lr": .0001, "residual": False},
    "D02": {"lr": .001, "residual": True},
    "D03": {"lr": .0001, "residual": True},
}
BASELINE = {"design_id": "D00", "config": DESIGNS["D00"],
            "development": {"primary": .4, "loss": 1.2}, "accepted": True}
SCOPE = {"selection": "equal target development-panel mean", "training_labs": 4,
         "development_panels": 10, "panels_are_not_training_labs": True}


def card(history, mode="structured", **kwargs):
    return build_evidence_card(history, mode, designs=DESIGNS,
                               evaluation_scope=SCOPE, **kwargs)


class EvidenceCardTests(unittest.TestCase):
    def test_minimal_baseline_and_separate_slot_budget(self):
        result = card([BASELINE])
        self.assertEqual(result["budget"]["completed_candidate_requests"], 0)
        self.assertEqual(result["budget"]["remaining_candidate_requests"], 6)
        self.assertEqual(result["evidence"]["current_incumbent"]["design_id"], "D00")
        self.assertEqual(set(result["available_designs"]), {"D01", "D02", "D03"})

    def test_direct_does_not_leak_scores_or_fit_failure_status(self):
        row = {"design_id": "D01", "development": {"primary": .7, "loss": .9},
               "status": "NUMERICAL_FAILURE", "diagnosis": "bad fit", "accepted": False}
        result = card([BASELINE, row, {"invalid": "schema failure", "accepted": False}], "direct")
        self.assertEqual(result["reference_config"], DESIGNS["D00"])
        self.assertEqual(result["invalid_output_slots"], [2])
        payload = json.dumps(result)
        for secret in ('0.7', '0.9', 'NUMERICAL_FAILURE', 'bad fit', 'accepted', 'diagnosis'):
            self.assertNotIn(secret, payload)
        self.assertEqual(result["tried_design_ids"], ["D00", "D01"])

    def test_same_shared_protocol_and_unrestricted_menu(self):
        rows = [BASELINE, {"design_id": "D02", "development": {"primary": .5, "loss": 1.1}, "accepted": True}]
        cards = [card(rows, mode) for mode in ("direct", "legacy", "structured")]
        for key in ("objective", "selection_rule", "budget", "evaluation_scope", "available_designs",
                    "available_changes_from_default", "tried_design_ids"):
            self.assertEqual(cards[0][key], cards[1][key])
            self.assertEqual(cards[1][key], cards[2][key])
        self.assertEqual(cards[1]["reference_config"], cards[2]["reference_config"])
        self.assertIn("D01", cards[2]["available_designs"])  # Two-factor move remains legal.

    def test_raw_and_structured_have_identical_observed_source_facts(self):
        baseline = deepcopy(BASELINE)
        row = {"design_id": "D02", "development": {"primary": .5, "loss": 1.1, "prediction_rms": .8},
               "accepted": True, "hypothesis": "Add the adapter", "experiment": "Compare D02 with D00",
               "expected_effect": "Primary increases", "prediction": {"metric": "primary", "direction": "increase", "min_delta": .01},
               "reference": deepcopy(BASELINE),
               "per_panel_development": [{"panel_id": "target-A", "development": {"primary": .5, "loss": 1.1}}],
               "trajectory": [{"round": 2, "train_loss_by_context": {"lab-A": .7},
                               "development": {"primary": .3, "loss": 1.2, "prediction_rms": .6}},
                              {"round": 5, "development": {"primary": .5, "loss": 1.1, "prediction_rms": .8}}],
               "training_diagnostics": {"primary_gain_last_minus_first": .2}}
        rows = [baseline, row, {"invalid": "Schema error", "accepted": False}]
        raw = card(rows, "raw")
        structured = card(rows, "structured")
        self.assertEqual(raw["reference_config"], structured["reference_config"])
        for source, enriched in zip(raw["evidence"]["trials"], structured["evidence"]["trials"]):
            derived = {"accepted", "actual_changes", "development_delta", "prediction_result", "unresolved_evidence"}
            self.assertEqual(source, {key: value for key, value in enriched.items() if key not in derived})
        self.assertEqual(raw["evidence"]["trials"][1]["development_diagnostics"]["prediction_rms"], .8)
        self.assertEqual(len(raw["evidence"]["trials"][1]["trajectory"]["points"]), 2)
        self.assertIn("expected_effect", raw["evidence"]["trials"][1])
        self.assertEqual(raw["evidence"]["trials"][2]["invalid"], "Schema error")

    def test_exact_tie_retains_incumbent(self):
        row = {"design_id": "D02", "development": {"primary": .4, "loss": 1.2}, "accepted": False}
        result = card([BASELINE, row])["evidence"]
        self.assertEqual(result["current_incumbent"]["design_id"], "D00")
        self.assertFalse(result["trials"][1]["accepted"])

    def test_prediction_agreement_is_not_acceptance(self):
        row = {"design_id": "D02", "development": {"primary": .3, "loss": 1.3}, "accepted": False,
               "proposal": {"hypothesis": "A measured comparison", "expected_effect": "decrease",
                            "prediction": {"metric": "primary", "direction": "decrease", "min_delta": .05}}}
        trial = card([BASELINE, row])["evidence"]["trials"][1]
        self.assertEqual(trial["prediction_result"]["status"], "met")
        self.assertFalse(trial["accepted"])
        self.assertEqual(trial["actual_changes"], [{"field": "residual", "before": False, "after": True}])

    def test_frozen_reference_not_replaced_by_new_incumbent(self):
        row = {"design_id": "D02", "development": {"primary": .5, "loss": 1.1}, "accepted": True,
               "reference": {"config": DESIGNS["D00"], "development": {"primary": .4, "loss": 1.2}}}
        trial = card([BASELINE, row])["evidence"]["trials"][1]
        self.assertAlmostEqual(trial["development_delta"]["primary"], .1)
        self.assertEqual(trial["reference"]["config"], DESIGNS["D00"])

    def test_missing_panel_values_not_invented_from_nested_mean(self):
        baseline = deepcopy(BASELINE)
        baseline["development"].update(worst_client=.4, clients=1)
        for mode in ("legacy", "structured"):
            result = card([baseline], mode)
            self.assertNotIn('"worst_client"', json.dumps(result))
            self.assertNotIn('"clients"', json.dumps(result))
        trial = card([baseline])["evidence"]["trials"][0]
        self.assertEqual(trial["panel_evidence"]["availability"], "unavailable")

    def test_reference_snapshot_is_also_whitelisted(self):
        row = {"design_id": "D02", "development": {"primary": .5, "loss": 1.1},
               "reference": {"config": DESIGNS["D00"],
                             "development": {"primary": .4, "loss": 1.2, "worst_client": .4, "clients": 1},
                             "unrelated_blob": "raw source data"}}
        result = json.dumps(card([BASELINE, row]))
        self.assertNotIn("worst_client", result)
        self.assertNotIn("unrelated_blob", result)

    def test_actual_panel_values_and_trajectory_preserved(self):
        baseline = deepcopy(BASELINE)
        baseline["per_panel_development"] = [{"panel_id": "target-A", "development": {"primary": .4, "loss": 1.2}}]
        baseline["development_trajectory"] = [
            {"round": 5, "train_loss": 2., "development": {"primary": .2, "loss": 1.4}},
            {"round": 10, "train_loss": 1., "development": {"primary": .4, "loss": 1.2}}]
        trial = card([baseline])["evidence"]["trials"][0]
        self.assertEqual(trial["panel_evidence"]["values"], baseline["per_panel_development"])
        self.assertEqual(len(trial["trajectory"]["points"]), 2)
        self.assertNotIn("per_panel_or_per_lab_effect_unavailable", trial["unresolved_evidence"])

    def test_endpoint_only_does_not_become_full_curve(self):
        baseline = deepcopy(BASELINE)
        baseline["training_diagnostics"] = {"first": {"round": 5, "development": {"primary": .1, "loss": 1.4}},
                                            "last": {"round": 100, "development": {"primary": .4, "loss": 1.2}}}
        trial = card([baseline])["evidence"]["trials"][0]
        self.assertEqual(trial["trajectory"]["availability"], "recorded_endpoints_only")
        self.assertIn("interior_learning_trajectory_unavailable", trial["unresolved_evidence"])

    def test_test_fields_rejected_recursively_even_if_unknown(self):
        for field in ("test", "test_score", "heldout", "held_out_metrics", "testRead"):
            baseline = deepcopy(BASELINE)
            baseline["irrelevant_metadata"] = [{field: .9}]
            for mode in ("direct", "legacy", "raw", "structured"):
                with self.assertRaisesRegex(ValueError, "Forbidden"):
                    card([baseline], mode)

    def test_bad_id_config_repeat_budget_and_unlabelled_panels_rejected(self):
        with self.assertRaisesRegex(ValueError, "contradicts"):
            card([BASELINE, {"design_id": "D01", "config": DESIGNS["D02"]}])
        with self.assertRaisesRegex(ValueError, "Repeated"):
            card([BASELINE, BASELINE])
        with self.assertRaisesRegex(ValueError, "total_slots"):
            card([BASELINE, {"invalid": "bad schema"}], total_slots=0)
        baseline = deepcopy(BASELINE)
        baseline["per_lab_development"] = [{"development": {"primary": .4, "loss": 1.2}}]
        with self.assertRaisesRegex(ValueError, "recorded panel_id"):
            card([baseline])

    def test_inputs_unchanged_and_unavailable_prediction_explicit(self):
        rows = [deepcopy(BASELINE)]
        before = deepcopy(rows)
        result = card(rows)
        self.assertEqual(rows, before)
        self.assertEqual(result["evidence"]["trials"][0]["prediction_result"]["status"], "unavailable")
        json.dumps(result, allow_nan=False)


if __name__ == "__main__":
    unittest.main()
