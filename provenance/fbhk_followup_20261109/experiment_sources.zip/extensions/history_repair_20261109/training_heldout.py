"""Registered held-out scoring, gated on three completed controller seals.

The register command reads membership/measurement-mask metadata only. Reading
test responses requires a separate root authorization bound to this code,
registration and all three controller selection seals.
"""
from __future__ import annotations

import argparse
import multiprocessing as mp
from pathlib import Path
import sys
import time

import h5py
import numpy as np
import pandas as pd
import torch
from torch.nn import functional as F

from training_data import OUT as TRAIN, ROOT, SPLITS, BULK, PANEL, WEIGHTS, read_json, save_json, sha, load_corrected, scdebart
from training_cache import build_model, choice_metrics

OUT = ROOT / "results/history_repair_20261109/training_heldout_genetic_v1"
SEEDS = (61, 62, 63)
ROSTER_SEED = 110924
BOOTSTRAP_SEED = 110925
BOOTSTRAPS = 10000


def rosters_from_metadata(rows, seed=ROSTER_SEED):
    rng = np.random.default_rng(seed)
    result = {}
    for context, frame in rows.groupby("scenario_id", sort=True):
        pool = frame.feature_id.to_numpy()
        if len(pool) < 5:
            raise ValueError("At least five eligible interventions required per context")
        choices, truth = [], []
        for actual in pool:
            for _ in range(5):
                options = np.r_[actual, rng.choice(pool[pool != actual], 4, replace=False)]
                rng.shuffle(options)
                choices.append(options.tolist())
                truth.append(int(actual))
        result[str(context)] = dict(choices=choices, truth=truth)
    return result


def register(out=OUT, train=TRAIN, search=None):
    """No perturbed/control expression is read by this command."""
    if search is None:
        raise ValueError("Explicit search-root required; never infer an obsolete controller run")
    protocol_path = out / "protocol.json"
    if protocol_path.exists():
        value = read_json(protocol_path)
        if value["source_sha256"] != sha(__file__):
            raise ValueError("Registered evaluator changed")
        return value
    if out.exists():
        raise FileExistsError("Incomplete registration exists; inspect instead of overwriting")
    out.mkdir(parents=True)
    rows = pd.read_csv(SPLITS / "test.csv")
    original = len(rows)
    assert set(rows.planned_role) == {"test"}
    genes = pd.read_csv(PANEL)
    vocabulary = np.load(train / "vocabulary_gene_ids.npy")
    symbol_pos = {str(s): i for i, s in enumerate(genes.gene_name) if vocabulary[i] >= 0}
    # Measurement masks are metadata, not expression values. This is exactly
    # the eligibility filter already fixed for the training/development cache.
    with h5py.File(BULK, "r") as bulk:
        masks = {int(i): bulk["gene_mask"][int(i)].astype(bool) for i in rows.gene_mask_index.unique()}
    valid = [r.perturbation in symbol_pos and masks[int(r.gene_mask_index)][symbol_pos[r.perturbation]]
             for r in rows.itertuples()]
    excluded = rows.loc[~np.asarray(valid), "condition_id"].tolist()
    rows = rows.loc[valid].copy().reset_index(drop=True)
    rows["feature_id"] = np.arange(len(rows))
    rows["perturbation_gene_id"] = [int(vocabulary[symbol_pos[s]]) for s in rows.perturbation]
    selected = np.load(train / "panel_positions.npy")
    rows["perturbation_panel_position"] = [int(np.where(selected == symbol_pos[s])[0][0])
                                           if symbol_pos[s] in selected else -1 for s in rows.perturbation]
    observed = pd.read_csv(train / "train_dev_memberships.csv")
    assert set(rows.identity_group).isdisjoint(observed.identity_group)
    assert set(rows.perturbation_gene_id).isdisjoint(observed.perturbation_gene_id)
    assert sorted(rows.scenario_id.unique()) == sorted(observed.scenario_id.unique())
    assert rows.groupby(["scenario_id", "identity_group"]).size().max() == 1
    for mask in masks.values():
        assert mask[selected].all()
    rows.to_csv(out / "memberships.csv", index=False)
    save_json(out / "rosters.json", rosters_from_metadata(rows))
    checkpoints = {}
    registration = read_json(train / "training_registration.json")
    for seed in SEEDS:
        checkpoints[str(seed)] = {}
        for design_id, config in registration["candidates"].items():
            fit_path = train / f"fits/seed{seed}/{design_id}/summary.json"
            fit = read_json(fit_path)
            checkpoint = Path(fit["checkpoint"])
            assert fit["config"] == config and fit["seed"] == seed
            assert sha(checkpoint) == fit["checkpoint_sha256"]
            checkpoints[str(seed)][design_id] = dict(checkpoint=str(checkpoint), checkpoint_sha256=sha(checkpoint),
                fit_sha256=sha(fit_path), config=config, best_round=fit["best_round"])
    value = dict(schema="history-genetic-heldout-v1", status="FROZEN_NO_TEST_EXPRESSION_READ",
        source_sha256=sha(__file__), created_unix=time.time(), train_root=str(train), search_root=str(search),
        membership_source=str(SPLITS / "test.csv"), membership_source_sha256=sha(SPLITS / "test.csv"),
        original_rows=original, retained_rows=len(rows), retained_genes=rows.identity_group.nunique(),
        excluded_condition_ids=excluded, contexts=sorted(rows.scenario_id.unique()), studies=["Replogle", "Nadig"],
        panel_sha256=sha(train / "panel_seal.json"), training_registration_sha256=sha(train / "training_registration.json"),
        shared_source_sha256={str(path): sha(path) for path in [Path(__file__).with_name("training_data.py"),
            Path(__file__).with_name("training_cache.py"), ROOT / "extensions/scdebart_maskfix_20260918/architecture.py",
            ROOT / "extensions/federated_bio_20260918/scdebart.py"]},
        membership_sha256=sha(out / "memberships.csv"), roster_sha256=sha(out / "rosters.json"),
        roster_seed=ROSTER_SEED, rosters_per_gene_context=5, options_per_roster=5,
        response="mean(log1pCP10K) perturbation minus matched context control; fixed training-only 512-gene panel",
        encoder="Same frozen mask-corrected scDEBART and control-plus-perturbation-token features as training",
        checkpoints=checkpoints, seeds=list(SEEDS),
        primary="Equal-context mean within-context gene-macro Top-1; same joint candidate-gene masking as development",
        secondary=["equal-context MRR", "equal-context CE", "global-gene macro Top-1", "global-gene macro MRR", "per-context diagnostics"],
        random_policy="Expected metric over development-selected candidate probabilities; not an ensemble of predictions",
        bootstrap=dict(replicates=BOOTSTRAPS, seed=BOOTSTRAP_SEED, interval="two-sided 95% percentile",
            cluster="global perturbation gene", pairing="same gene resample across all contexts, seeds and policies",
            estimand="equal-context mean, averaged over the three fixed training/controller seeds",
            scope="Conditional test-gene uncertainty for fixed trained/selected models; training-seed SD is reported separately"),
        authorization_required=True, test_expression_read=False,
        source_identity=dict(bulk=str(BULK), bytes=BULK.stat().st_size, mtime_ns=BULK.stat().st_mtime_ns))
    save_json(protocol_path, value)
    return value


def authorize(out, authorization_path):
    """Validate authority and frozen selections before any test expression I/O."""
    if authorization_path is None:
        raise PermissionError("Explicit root authorization is required")
    auth = read_json(authorization_path)
    if auth.get("authorized") is not True or auth.get("authorized_by") != "/root":
        raise PermissionError("Explicit /root authorization is required")
    protocol = read_json(out / "protocol.json")
    if auth.get("heldout_protocol_sha256") != sha(out / "protocol.json") or auth.get("heldout_code_sha256") != sha(__file__):
        raise PermissionError("Authorization does not bind this evaluator and protocol")
    if protocol["source_sha256"] != sha(__file__):
        raise ValueError("Held-out evaluator changed after registration")
    for path, value in protocol["shared_source_sha256"].items():
        if sha(path) != value:
            raise ValueError(f"Shared feature/scoring source changed: {path}")
    search = Path(protocol["search_root"])
    if auth.get("search_protocol_sha256") != sha(search / "protocol.json"):
        raise PermissionError("Search protocol not bound")
    if set(auth.get("selection_seals", {})) != {str(s) for s in SEEDS}:
        raise PermissionError("All three seed selection seals must be authorized")
    for seed in SEEDS:
        base = search / f"seed{seed}"
        seal_path = base / "selection_seal.json"
        if auth["selection_seals"][str(seed)] != sha(seal_path):
            raise PermissionError(f"Seed {seed} selection seal changed")
        seal = read_json(seal_path)
        if seal["heldout_evaluation_read"] is not False:
            raise ValueError("Selection did not precede held-out evaluation")
        assert seal["protocol_sha256"] == sha(search / "protocol.json")
        assert seal["selections_sha256"] == sha(base / "selections.json")
        assert seal["controls_sha256"] == sha(base / "controls.json")
        assert seal["grid_sha256"] == sha(Path(protocol["train_root"]) / f"seed{seed}/development_grid.json")
        for path, digest in seal["transcript_sha256"].items():
            assert sha(path) == digest
    assert sha(out / "memberships.csv") == protocol["membership_sha256"]
    assert sha(out / "rosters.json") == protocol["roster_sha256"]
    assert sha(Path(protocol["train_root"]) / "panel_seal.json") == protocol["panel_sha256"]
    return protocol


def heldout_feature_worker(out, train, device, index, workers):
    torch.set_num_threads(2)
    rows = pd.read_csv(out / "memberships.csv")
    selected = np.load(train / "panel_positions.npy")
    vocabulary = np.load(train / "vocabulary_gene_ids.npy")
    gids = np.load(train / "gene_ids.npy")
    controls = np.load(out / "controls.npz")
    hidden = np.load(out / "hidden.npy", mmap_mode="r+")
    model = load_corrected(WEIGHTS, device)
    start = time.monotonic()
    assigned = rows.iloc[index::workers]
    for row in assigned.itertuples():
        perturb = int(row.perturbation_gene_id)
        pos = int(np.flatnonzero(vocabulary == perturb)[0])
        positions = selected if perturb in gids else np.r_[selected, pos]
        positions = positions[np.argsort(vocabulary[positions])]
        features = scdebart.hidden(model, vocabulary[positions], controls[str(int(row.control_bulk_index))][positions], [perturb])
        indices = np.asarray([np.flatnonzero(positions == p)[0] for p in selected])
        hidden[int(row.feature_id)] = features[indices]
    hidden.flush()
    torch.cuda.synchronize(device)
    save_json(out / f"feature_worker{index}.json", dict(status="COMPLETE", rows=len(assigned),
              seconds=time.monotonic() - start, device=device))


def prepare_expressions(out, authorization_path, gpus):
    protocol = authorize(out, authorization_path)
    if (out / "features_complete.json").exists():
        return
    train = Path(protocol["train_root"])
    rows = pd.read_csv(out / "memberships.csv")
    selected = np.load(train / "panel_positions.npy")
    if (out / "expression_access_receipt.json").exists():
        raise FileExistsError("An incomplete held-out extraction exists; inspect explicitly")
    save_json(out / "expression_access_receipt.json", dict(status="AUTHORIZED_READING_STARTED",
              authorization_sha256=sha(authorization_path), protocol_sha256=sha(out / "protocol.json"), started_unix=time.time()))
    # This is the first point in the program that can read a held-out response.
    response = np.lib.format.open_memmap(out / "responses.npy", mode="w+", dtype=np.float32, shape=(len(rows), len(selected)))
    with h5py.File(BULK, "r") as bulk:
        controls = {str(int(i)): bulk["control_bulk"][int(i)] for i in rows.control_bulk_index.unique()}
        for row in rows.itertuples():
            response[int(row.feature_id)] = bulk["perturbed_bulk"][int(row.perturbed_bulk_index)][selected] - controls[str(int(row.control_bulk_index))][selected]
    response.flush()
    np.savez(out / "controls.npz", **controls)
    np.lib.format.open_memmap(out / "hidden.npy", mode="w+", dtype=np.float16, shape=(len(rows), len(selected), 768)).flush()
    ctx = mp.get_context("spawn")
    jobs = [ctx.Process(target=heldout_feature_worker, args=(out, train, f"cuda:{gpu}", i, len(gpus))) for i, gpu in enumerate(gpus)]
    for job in jobs:
        job.start()
    for job in jobs:
        job.join()
    if any(job.exitcode != 0 for job in jobs):
        raise RuntimeError("Held-out feature worker failed")
    hidden = np.load(out / "hidden.npy", mmap_mode="r")
    assert np.isfinite(response).all()
    for start in range(0, len(hidden), 64):
        block = np.array(hidden[start:start + 64])
        assert np.isfinite(block).all()
        assert np.all(np.max(np.abs(block), axis=(1, 2)) > 0)
    save_json(out / "features_complete.json", dict(status="COMPLETE", hidden_sha256=sha(out / "hidden.npy"),
        response_sha256=sha(out / "responses.npy"), authorization_sha256=sha(authorization_path),
        workers=[read_json(out / f"feature_worker{i}.json") for i in range(len(gpus))]))


@torch.inference_mode()
def score_model(model, hidden, responses, rows, rosters, device):
    model.eval()
    pred = torch.cat([model(hidden[start:start + 32].float()) for start in range(0, len(hidden), 32)])
    perturb_pos = torch.as_tensor(rows.perturbation_panel_position.to_numpy(), device=device)
    panels, per_gene = {}, []
    for context, roster in rosters.items():
        truth = torch.tensor(roster["truth"], device=device)
        choices = torch.tensor(roster["choices"], device=device)
        rank, ce = choice_metrics(pred, responses, truth, choices, perturb_pos)
        actual = np.asarray(roster["truth"])
        unique = np.unique(actual)
        for value in unique:
            indices = actual == value
            per_gene.append(dict(gene=str(rows.iloc[value].identity_group), context=context,
                top1=float(np.mean(rank[indices] == 1)), ce=float(np.mean(ce[indices])),
                mrr=float(np.mean(1 / rank[indices])), top3=float(np.mean(rank[indices] <= 3)),
                condition_id=str(rows.iloc[value].condition_id), n_rosters=int(indices.sum())))
        p, y = pred[unique], responses[unique]
        panels[context] = dict(primary=float(np.mean(rank == 1)), loss=float(ce.mean()), mrr=float(np.mean(1 / rank)),
            top3=float(np.mean(rank <= 3)), mse=float(F.mse_loss(p, y)), genes=len(unique), queries=len(rank),
            prediction_target_rms_ratio=float(p.square().mean().sqrt() / y.square().mean().sqrt().clamp_min(1e-12)))
    gene_frame = pd.DataFrame(per_gene)
    return dict(primary=float(np.mean([p["primary"] for p in panels.values()])),
        loss=float(np.mean([p["loss"] for p in panels.values()])), mrr=float(np.mean([p["mrr"] for p in panels.values()])),
        global_gene_macro=float(gene_frame.groupby("gene").top1.mean().mean()),
        global_gene_macro_mrr=float(gene_frame.groupby("gene").mrr.mean().mean()),
        per_context=panels, per_gene=per_gene, unique_genes=gene_frame.gene.nunique())


def scoring_worker(out, authorization_path, seed, device):
    torch.set_num_threads(2)
    torch.backends.cuda.matmul.allow_tf32 = False
    protocol = authorize(out, authorization_path)
    train = Path(protocol["train_root"])
    hidden = torch.as_tensor(np.array(np.load(out / "hidden.npy", mmap_mode="r")), device=device)
    response = torch.as_tensor(np.load(out / "responses.npy"), device=device)
    rows = pd.read_csv(out / "memberships.csv")
    rosters = read_json(out / "rosters.json")
    initial = torch.load(train / "initial_head.pt", map_location="cpu", weights_only=True)
    for design_id, specification in protocol["checkpoints"][str(seed)].items():
        path = out / f"scores/seed{seed}/{design_id}.json"
        if path.exists():
            old = read_json(path)
            assert old["checkpoint_sha256"] == specification["checkpoint_sha256"]
            assert old["protocol_sha256"] == sha(out / "protocol.json")
            assert old["authorization_sha256"] == sha(authorization_path)
            continue
        assert sha(specification["checkpoint"]) == specification["checkpoint_sha256"]
        model = build_model(initial, specification["config"], seed, device)
        model.load_state_dict(torch.load(specification["checkpoint"], map_location=device, weights_only=True), strict=True)
        start = time.monotonic()
        metrics = score_model(model, hidden, response, rows, rosters, device)
        save_json(path, dict(status="COMPLETE", seed=seed, design_id=design_id, heldout=metrics,
            checkpoint_sha256=specification["checkpoint_sha256"], best_round=specification["best_round"],
            protocol_sha256=sha(out / "protocol.json"), authorization_sha256=sha(authorization_path),
            seconds=time.monotonic() - start, selected_using="development only; frozen before test expression access"))


def paired_cluster_bootstrap(arrays, seed=BOOTSTRAP_SEED, replicates=BOOTSTRAPS):
    """arrays[policy] has [fixed training seed, context, global gene] axes.

    Missing gene/context pairs are NaN. Every replicate resamples global genes
    jointly for every policy/seed/context, then applies the original equal-
    context averaging. This never treats five rosters as five observations.
    """
    names = sorted(arrays)
    example = arrays[names[0]]
    if example.ndim != 3:
        raise ValueError("Expected seed/context/global-gene arrays")
    present = np.isfinite(example)
    for array in arrays.values():
        if array.shape != example.shape or not np.array_equal(np.isfinite(array), present):
            raise ValueError("Policies must have the same paired gene/context support")
    rng = np.random.default_rng(seed)
    gene_count = example.shape[-1]
    samples = {name: [] for name in names}
    for start in range(0, replicates, 250):
        count = min(250, replicates - start)
        weights = rng.multinomial(gene_count, np.full(gene_count, 1 / gene_count), size=count)
        denominator = np.einsum("bg,scg->bsc", weights, present.astype(np.float64))
        if np.any(denominator == 0):
            raise ValueError("Empty context in cluster bootstrap; preregister a handling rule")
        for name in names:
            numerator = np.einsum("bg,scg->bsc", weights, np.nan_to_num(arrays[name]))
            samples[name].append((numerator / denominator).mean(axis=(1, 2)))
    draws = {name: np.concatenate(values) for name, values in samples.items()}
    point = {name: float(np.nanmean(array, axis=-1).mean()) for name, array in arrays.items()}
    return point, draws


def policy_weights(search, seed):
    selections = read_json(search / f"seed{seed}/selections.json")
    controls = read_json(search / f"seed{seed}/controls.json")
    result = {"fixed_D00": {"D00": 1.}}
    result.update({name: {selection["design_id"]: 1.} for name, selection in selections.items()})
    for name, value in controls.items():
        if isinstance(value, dict) and "weights" in value:
            result[name] = value["weights"]
        elif isinstance(value, dict) and "design_id" in value:
            result[name] = {value["design_id"]: 1.}
    # A successful arm's valid-fit-matched random control is the ordinary
    # registered random control. Keep this comparison defined for every seed,
    # rather than silently dropping a correction that only some seeds need.
    for arm, selection in selections.items():
        name = f"random_valid_fit_count_{arm}"
        if name not in result:
            if selection["invalid_slots"]:
                raise ValueError("Missing required actual-valid-fit random control")
            result[name] = controls["random"]["weights"]
    for weights in result.values():
        assert abs(sum(weights.values()) - 1) < 1e-10
        assert all(v >= 0 for v in weights.values())
    return result


def report(out, authorization_path):
    protocol = authorize(out, authorization_path)
    search = Path(protocol["search_root"])
    rows = pd.read_csv(out / "memberships.csv")
    genes, contexts = sorted(rows.identity_group.unique()), sorted(rows.scenario_id.unique())
    gene_index = {g: i for i, g in enumerate(genes)}
    context_index = {c: i for i, c in enumerate(contexts)}
    mappings = {seed: policy_weights(search, seed) for seed in SEEDS}
    names = sorted(set.intersection(*(set(v) for v in mappings.values())))
    arrays = {name: np.full((len(SEEDS), len(contexts), len(genes)), np.nan) for name in names}
    summaries = {name: [] for name in names}
    score_hashes = {}
    for si, seed in enumerate(SEEDS):
        scores = {}
        for design_id in protocol["checkpoints"][str(seed)]:
            path = out / f"scores/seed{seed}/{design_id}.json"
            score_hashes[str(path)] = sha(path)
            scores[design_id] = read_json(path)["heldout"]
        for name in names:
            weights = mappings[seed][name]
            mixed = {metric: float(sum(w * scores[d][metric] for d, w in weights.items()))
                     for metric in ("primary", "loss", "mrr", "global_gene_macro", "global_gene_macro_mrr")}
            mixed["seed"] = seed
            mixed["selected_design_probabilities"] = weights
            mixed["conditional_policy_sd"] = float(np.sqrt(sum(w * (scores[d]["primary"] - mixed["primary"]) ** 2 for d, w in weights.items())))
            summaries[name].append(mixed)
            accumulator = {}
            for design_id, weight in weights.items():
                for value in scores[design_id]["per_gene"]:
                    key = (value["context"], value["gene"])
                    accumulator[key] = accumulator.get(key, 0.) + weight * value["top1"]
            for (context, gene), value in accumulator.items():
                arrays[name][si, context_index[context], gene_index[gene]] = value
            assert abs(np.nanmean(arrays[name][si], axis=-1).mean() - mixed["primary"]) < 1e-10
    points, draws = paired_cluster_bootstrap(arrays)
    policies = {}
    for name in names:
        values = summaries[name]
        policies[name] = dict(primary=points[name], gene_cluster_ci95=np.quantile(draws[name], [.025, .975]).tolist(),
            across_training_controller_seed_sd=float(np.std([v["primary"] for v in values], ddof=1)),
            mrr=float(np.mean([v["mrr"] for v in values])),
            global_gene_macro=float(np.mean([v["global_gene_macro"] for v in values])), per_seed=values)
    differences = {}
    for left in names:
        for right in names:
            if left <= right:
                continue
            differences[f"{left}_minus_{right}"] = dict(difference=points[left] - points[right],
                gene_cluster_ci95=np.quantile(draws[left] - draws[right], [.025, .975]).tolist())
    output = dict(status="COMPLETE", policies=policies, paired_differences=differences,
        bootstrap=protocol["bootstrap"], score_sha256=score_hashes,
        missing_across_seed_optional_policies=sorted(set.union(*(set(v) for v in mappings.values())) - set(names)),
        protocol_sha256=sha(out / "protocol.json"), authorization_sha256=sha(authorization_path),
        explanation="Random expected scores integrate development-selected candidate probabilities, not held-out selection. Three-seed SD and conditional gene-cluster confidence intervals quantify different uncertainties.")
    save_json(out / "policy_report.json", output)
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["register", "evaluate", "report"])
    parser.add_argument("--out", type=Path, default=OUT)
    parser.add_argument("--train", type=Path, default=TRAIN)
    parser.add_argument("--search", type=Path, help="Required when registering: the current, fully preregistered controller run")
    parser.add_argument("--authorization", type=Path)
    parser.add_argument("--gpus", default="5,6,7")
    args = parser.parse_args()
    if args.command == "register":
        result = register(args.out, args.train, args.search)
        print(result["status"], result["retained_rows"], result["retained_genes"])
        return
    authorize(args.out, args.authorization)
    if args.command == "evaluate":
        gpus = [int(v) for v in args.gpus.split(",")]
        if len(gpus) != 3:
            raise ValueError("Use three devices, one scoring worker per registered seed")
        prepare_expressions(args.out, args.authorization, gpus)
        ctx = mp.get_context("spawn")
        jobs = [ctx.Process(target=scoring_worker, args=(args.out, args.authorization, seed, f"cuda:{gpu}")) for seed, gpu in zip(SEEDS, gpus)]
        for job in jobs:
            job.start()
        for job in jobs:
            job.join()
        if any(job.exitcode != 0 for job in jobs):
            raise RuntimeError("Held-out scoring worker failed")
    result = report(args.out, args.authorization)
    print(result["status"], list(result["policies"]))


if __name__ == "__main__":
    main()
