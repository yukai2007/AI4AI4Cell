"""Development-only random-search and GP-EI controls for a registered menu.

D00 is a common baseline outside the candidate-request budget. Therefore a
16-design menu and budget=6 yield C(15, 6)=5005 random subsets. Exact random
integration is an offline evaluator, not information provided to a proposer.
GP-EI accesses results solely through get_record(chosen_id), one query at a time.
"""
from __future__ import annotations

from collections import defaultdict
from fractions import Fraction
from itertools import combinations
import json
import math
from numbers import Real
import random
import re


BASELINE = "D00"
GP_SETTINGS = dict(kernel="Matern", nu=2.5, length_scale=1.,
                   alpha=1e-6, xi=.01, normalize_y=True, optimizer=None,
                   warm_start_count=2, acquisition_exact_tie="lexical design ID")


def _validate_development_input(value, path="root"):
    """Reject test/held-out fields and nonfinite values, even in nested extras."""
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise ValueError(f"Non-string field at {path}")
            normalized = re.sub(r"([a-z])([A-Z])", r"\1_\2", key).lower()
            if re.search(r"(^|_)(test|heldout|held_out)(_|$)", normalized):
                raise ValueError(f"Forbidden test/held-out field at {path}.{key}")
            _validate_development_input(item, f"{path}.{key}")
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _validate_development_input(item, f"{path}[{index}]")
    elif isinstance(value, Real) and not isinstance(value, bool):
        if not math.isfinite(value):
            raise ValueError(f"Nonfinite numeric value at {path}")
    elif value is not None and not isinstance(value, (str, bool)):
        raise ValueError(f"Non-JSON evidence value at {path}")


def score_key(record):
    """Return (development.primary, -development.loss); never consult test data.

    New records use top-level development. Legacy best.development is accepted;
    if both exist, their primary/loss must agree. Failed records are not scores.
    """
    if not isinstance(record, dict):
        raise ValueError("Development record must be a dictionary")
    _validate_development_input(record)
    if record.get("status", "COMPLETE") not in {"COMPLETE", "OK", "SUCCESS"}:
        raise ValueError("Only completed finite candidate fits can be selected")
    development = record.get("development")
    legacy = record.get("best", {}).get("development") if isinstance(record.get("best"), dict) else None
    if legacy is not None and not isinstance(legacy, dict):
        raise ValueError("best.development must be a metric dictionary")
    if development is None:
        development = legacy
    if not isinstance(development, dict):
        raise ValueError("Missing development metrics")
    for name in ("primary", "loss"):
        value = development.get(name)
        if not isinstance(value, Real) or isinstance(value, bool) or not math.isfinite(value):
            raise ValueError(f"Finite numeric development.{name} required")
        if legacy is not None and legacy.get(name) != value:
            raise ValueError("Conflicting development and best.development metrics")
    return float(development["primary"]), -float(development["loss"])


def _validate_ids(values, budget, first):
    if not isinstance(values, dict) or BASELINE not in values:
        raise ValueError("Registered candidates must include baseline D00")
    if any(not isinstance(key, str) or not key for key in values):
        raise ValueError("Candidate IDs must be nonempty strings")
    if type(budget) is not int or budget < 0 or budget > len(values) - 1:
        raise ValueError("Candidate budget is outside the non-baseline menu")
    if first is not None:
        if first not in values or first == BASELINE:
            raise ValueError("first must be a non-baseline registered candidate")
        if budget < 1:
            raise ValueError("A fixed first candidate consumes one budget slot")


def exact_random_weights(records, budget=6, first=None):
    """Return (selected-ID probabilities, subset count) under uniform random search.

    Conditional on each unordered subset, every order is equally likely. An
    exact top tie is retained by D00 first, then a fixed first candidate, else by
    the earliest of equally good sampled candidates (uniform among those ties).
    Fraction arithmetic integrates order-sensitive ties without enumerating all
    permutations. ``budget`` excludes D00 and includes ``first`` when supplied.
    """
    _validate_ids(records, budget, first)
    scores = {key: score_key(record) for key, record in records.items()}
    prefix = [BASELINE] + ([] if first is None else [first])
    remaining = sorted(set(records) - set(prefix))
    draws = budget - int(first is not None)
    mass = defaultdict(Fraction)
    count = 0
    for subset in combinations(remaining, draws):
        count += 1
        top = max(scores[key] for key in prefix + list(subset))
        prefix_winners = [key for key in prefix if scores[key] == top]
        if prefix_winners:
            mass[prefix_winners[0]] += 1
        else:
            winners = [key for key in subset if scores[key] == top]
            for key in winners:
                mass[key] += Fraction(1, len(winners))
    if count != math.comb(len(remaining), draws) or sum(mass.values()) != count:
        raise AssertionError("Random-search integration lost probability mass")
    return {key: float(value / count) for key, value in sorted(mass.items())}, count


def random_prefix_curve(records, budget=6, first=None, *, max_budget=None):
    """Exact random search at prefixes 1..budget; SD is policy, not seed, variation."""
    if max_budget is not None:
        if budget != 6 and budget != max_budget:
            raise ValueError("Conflicting budget and max_budget")
        budget = max_budget
    _validate_ids(records, budget, first)
    scores = {key: score_key(record) for key, record in records.items()}
    curve = []
    for prefix in range(1, budget + 1):
        weights, subsets = exact_random_weights(records, prefix, first)
        primary = math.fsum(weights[key] * scores[key][0] for key in weights)
        loss = math.fsum(weights[key] * -scores[key][1] for key in weights)
        primary_var = math.fsum(weights[key] * (scores[key][0] - primary) ** 2 for key in weights)
        loss_var = math.fsum(weights[key] * (-scores[key][1] - loss) ** 2 for key in weights)
        curve.append(dict(budget=prefix, first=first, weights=weights, subsets=subsets,
                          expected_development=dict(primary=primary, loss=loss),
                          policy_sd=dict(primary=math.sqrt(primary_var), loss=math.sqrt(loss_var)),
                          uncertainty="exact search-policy variation conditional on fixed fits"))
    return curve


def menu_features(menu):
    """Return (lexical IDs, feature rows, encoding metadata), without any outcomes.

    log10(lr) uses registered menu min/max; other varying numeric fields use
    linear min/max. Varying categorical fields (e.g. head, objective, loss) use
    full one-hot encoding. Constants are omitted. No outcome-dependent scaling.
    """
    _validate_ids(menu, 0, None)
    _validate_development_input(menu)
    ids = sorted(menu)
    if any(not isinstance(menu[key], dict) for key in ids):
        raise ValueError("Each menu design must be a configuration dictionary")
    fields = set(menu[BASELINE])
    if "lr" not in fields or any(set(menu[key]) != fields for key in ids):
        raise ValueError("All configurations must share fields including lr")
    serialized = [json.dumps(menu[key], sort_keys=True, separators=(",", ":")) for key in ids]
    if len(set(serialized)) != len(serialized):
        raise ValueError("Duplicate registered configurations are not distinct candidates")
    rows = {key: [] for key in ids}
    encoding = []
    for field in sorted(fields):
        values = [menu[key][field] for key in ids]
        if any(not isinstance(value, (str, bool, Real)) and value is not None for value in values):
            raise ValueError("Configuration fields must be scalar categories or numbers")
        numeric = all(isinstance(value, Real) and not isinstance(value, bool) for value in values)
        if field == "lr":
            if not numeric or any(value <= 0 for value in values):
                raise ValueError("All learning rates must be finite and positive")
            transformed = [math.log10(value) for value in values]
        elif numeric:
            transformed = [float(value) for value in values]
        else:
            transformed = None
        if transformed is not None:
            lo, hi = min(transformed), max(transformed)
            if hi == lo:
                continue
            encoding.append(dict(field=field, kind="log10_minmax" if field == "lr" else "linear_minmax",
                                 minimum=lo, maximum=hi, width=1))
            for key, value in zip(ids, transformed):
                rows[key].append((value - lo) / (hi - lo))
        else:
            labels = sorted(set(json.dumps(value, sort_keys=True) for value in values))
            if len(labels) < 2:
                continue
            encoding.append(dict(field=field, kind="onehot", categories=[json.loads(x) for x in labels],
                                 width=len(labels)))
            for key, value in zip(ids, values):
                label = json.dumps(value, sort_keys=True)
                rows[key].extend(float(label == category) for category in labels)
    if not encoding:
        raise ValueError("GP requires at least one varying registered feature")
    return ids, [rows[key] for key in ids], encoding


def _expected_improvement(menu, observed, seed):
    import numpy as np
    from scipy.special import ndtr
    from sklearn.gaussian_process import GaussianProcessRegressor
    from sklearn.gaussian_process.kernels import Matern

    ids, feature_rows, encoding = menu_features(menu)
    features = dict(zip(ids, feature_rows))
    available = sorted(set(menu) - set(observed))
    observed_ids = list(observed)
    x = np.asarray([features[key] for key in observed_ids], dtype=np.float64)
    y = np.asarray([score_key(observed[key])[0] for key in observed_ids], dtype=np.float64)
    gp = GaussianProcessRegressor(
        kernel=Matern(length_scale=np.ones(x.shape[1]), length_scale_bounds="fixed", nu=2.5),
        alpha=1e-6, normalize_y=True, optimizer=None, random_state=seed)
    gp.fit(x, y)
    mean, std = gp.predict(np.asarray([features[key] for key in available]), return_std=True)
    if not np.isfinite(mean).all() or not np.isfinite(std).all() or np.any(std < 0):
        raise ValueError("GP returned nonfinite predictions or invalid uncertainty")
    improvement = mean - float(y.max()) - .01
    safe_std = np.maximum(std, 1e-12)
    z = improvement / safe_std
    ei = improvement * ndtr(z) + safe_std * np.exp(-.5 * z**2) / math.sqrt(2 * math.pi)
    ei[std < 1e-12] = np.maximum(improvement[std < 1e-12], 0)
    ei = np.maximum(ei, 0.)
    if not np.isfinite(ei).all():
        raise ValueError("GP returned nonfinite acquisition values")
    selected = available[int(np.argmax(ei))]
    return selected, dict(rule="GP expected improvement", observed_ids=observed_ids,
                          acquisition=dict(zip(available, map(float, ei))),
                          feature_encoding=encoding, settings=dict(GP_SETTINGS))


def select_gp(menu, get_record, seed, budget=6, first=None):
    """Return (trace, selected_id, queried_ids); IDs include the shared D00.

    Two seeded random warm starts count toward the non-baseline budget, followed
    by GP-EI. A fixed first candidate replaces warm-start #1, not an extra query.
    get_record is called exactly once per queried ID; unqueried records are never
    inspected. Incumbent selection uses primary, -loss, then earliest observation.
    Failed/nonfinite callbacks abort rather than fabricate scores or fill a slot.
    """
    _validate_ids(menu, budget, first)
    menu_features(menu)
    if type(seed) is not int or seed < 0 or seed >= 2**32:
        raise ValueError("GP seed must be a nonnegative 32-bit integer")
    if not callable(get_record):
        raise ValueError("get_record must be a callable queried-result interface")
    rng = random.Random(seed)
    available = sorted(set(menu) - {BASELINE})
    if first is None:
        warm = rng.sample(available, min(2, budget))
    else:
        warm = [first] + rng.sample([key for key in available if key != first], min(1, budget - 1))
    observed = {}

    def observe(key):
        record = get_record(key)
        score = score_key(record)
        if record.get("design_id", key) != key:
            raise ValueError("Requested design ID differs from returned evidence")
        if "config" in record and record["config"] != menu[key]:
            raise ValueError("Returned evidence configuration differs from registered menu")
        # Only needed metrics cross the GP boundary, not arbitrary callback data.
        observed[key] = dict(development=dict(primary=score[0], loss=-score[1]))

    observe(BASELINE)
    selected = BASELINE
    trace = []
    for slot in range(1, budget + 1):
        if slot <= len(warm):
            chosen = warm[slot - 1]
            acquisition = dict(rule="fixed shared first" if first is not None and slot == 1
                               else "seeded random warm start", observed_ids=list(observed))
        else:
            chosen, acquisition = _expected_improvement(menu, observed, seed)
        observe(chosen)
        if score_key(observed[chosen]) > score_key(observed[selected]):
            selected = chosen
        trace.append(dict(slot=slot, design_id=chosen, acquisition=acquisition,
                          development=dict(observed[chosen]["development"]), selected=selected,
                          incumbent_development=dict(observed[selected]["development"])))
    return trace, selected, list(observed)
