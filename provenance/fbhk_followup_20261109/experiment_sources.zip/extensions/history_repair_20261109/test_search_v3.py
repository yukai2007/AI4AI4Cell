from copy import deepcopy
import json
import unittest

from extensions.history_repair_20261109 import search_v3 as search


MENU = {
    "D00": {"lr": .0001, "head": "full", "objective": "mse"},
    "D01": {"lr": .00001, "head": "full", "objective": "mse"},
    "D02": {"lr": .0001, "head": "residual", "objective": "mse"},
    "D03": {"lr": .0001, "head": "full", "objective": "mse_contrastive"},
}


def record(identifier, score):
    return dict(config=MENU[identifier], development=dict(primary=score, loss=1.,
        per_context={"A": dict(primary=score, loss=1.)}, per_gene={"secret_gene": score}),
        best_round=5, test_expression_read=False, heldout={"forbidden": 999},
        trajectory=[dict(round=2, development=dict(primary=score-.01, loss=1.1))])


def proposal(card, identifier):
    return dict(design_id=identifier, reference_id=card["proposal_reference_id"],
        changed_fields=card["available_changed_fields"][identifier],
        hypothesis="Use the supplied measured comparison", experiment="Fit the specified configuration",
        expected_effect="Improve primary", prediction=dict(metric="primary", direction="increase", min_delta=.01))


class SearchTests(unittest.TestCase):
    def setUp(self):
        self.records = {k: record(k, .3 + i*.02) for i, k in enumerate(MENU)}
        self.baseline = search.observed_record(self.records["D00"], "D00", MENU)
        self.baseline["accepted"] = True

    def test_only_aggregate_development_is_projected(self):
        text = json.dumps(self.baseline)
        for forbidden in ("heldout", "forbidden", "test_expression", "secret_gene", "per_gene"):
            self.assertNotIn(forbidden, text)
        self.assertEqual(len(self.baseline["per_panel_development"]), 1)

    def test_cold_start_is_identical(self):
        msgs = [search.make_messages([self.baseline], arm, MENU, 1)[0] for arm in search.ARMS]
        self.assertEqual(msgs[0], msgs[1])
        self.assertEqual(msgs[1], msgs[2])
        self.assertNotIn('"primary": 0.3', json.dumps(msgs))

    def test_exact_changes_enforced(self):
        _, card = search.make_messages([self.baseline], "direct", MENU, 1)
        value = proposal(card, "D01")
        search.validate_proposal(value, card)
        value["changed_fields"] = ["head"]
        with self.assertRaisesRegex(ValueError, "changed_fields"):
            search.validate_proposal(value, card)

    def test_forecast_reference_enforced(self):
        _, card = search.make_messages([self.baseline], "direct", MENU, 1)
        value = proposal(card, "D01")
        value["reference_id"] = "D02"
        with self.assertRaisesRegex(ValueError, "reference_id"):
            search.validate_proposal(value, card)

    def test_direct_does_not_leak_results_or_change_baseline_reference(self):
        _, card = search.make_messages([self.baseline], "direct", MENU, 1)
        hist = search.next_history([self.baseline], dict(valid=True, parsed=proposal(card, "D01")),
                                   self.records, MENU, card)
        _, direct = search.make_messages(hist, "direct", MENU, 2)
        _, raw = search.make_messages(hist, "raw", MENU, 2)
        _, structured = search.make_messages(hist, "structured", MENU, 2)
        self.assertEqual(direct["proposal_reference_id"], "D00")
        self.assertEqual(raw["proposal_reference_id"], "D01")
        self.assertEqual(raw["reference_config"], structured["reference_config"])
        self.assertEqual(raw["available_designs"], direct["available_designs"])
        self.assertEqual(direct["evidence"], "No development outcome feedback.")

    def test_invalid_slot_consumed_without_fallback(self):
        _, card = search.make_messages([self.baseline], "direct", MENU, 1)
        hist = search.next_history([self.baseline], dict(valid=False, parsed=None), self.records, MENU, card)
        self.assertEqual(len(hist), 2)
        self.assertNotIn("design_id", hist[-1])
        _, after = search.make_messages(hist, "structured", MENU, 2)
        self.assertEqual(after["budget"]["remaining_candidate_requests"], 5)
        self.assertEqual(set(after["available_designs"]), {"D01", "D02", "D03"})

    def test_unqueried_records_cannot_enter_prompt(self):
        self.records["D03"]["development"]["primary"] = 987654.
        for arm in search.ARMS:
            messages, _ = search.make_messages([self.baseline], arm, MENU, 2)
            self.assertNotIn("987654", json.dumps(messages))

    def test_forecast_reference_is_preserved(self):
        _, card = search.make_messages([self.baseline], "direct", MENU, 1)
        hist = search.next_history([self.baseline], dict(valid=True, parsed=proposal(card, "D01")),
                                   self.records, MENU, card)
        self.assertEqual(hist[-1]["reference"]["design_id"], "D00")
        self.assertTrue(hist[-1]["accepted"])
        self.assertEqual(hist[-1]["proposal"]["changed_fields"], ["lr"])

    def test_finite_prediction(self):
        _, card = search.make_messages([self.baseline], "direct", MENU, 1)
        value = proposal(card, "D01")
        for bad in (float("nan"), float("inf"), -1., True):
            value["prediction"]["min_delta"] = bad
            with self.assertRaises(ValueError):
                search.validate_proposal(value, card)


if __name__ == "__main__":
    unittest.main()
