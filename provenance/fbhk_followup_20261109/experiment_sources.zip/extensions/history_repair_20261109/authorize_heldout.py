"""One-time validation and release of the registered, previously unread scorer."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "results/history_repair_20261109"


def sha(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def main():
    train = RESULTS / "training_genetic_v1"
    search = RESULTS / "search_genetic_v3"
    heldout = RESULTS / "training_heldout_genetic_v1"
    target = heldout / "authorization.json"
    if target.exists() or (heldout / "expression_access_receipt.json").exists():
        raise FileExistsError("Initial authorization only; inspect an existing evaluation instead")
    if any((heldout / name).exists() for name in ("responses.npy", "hidden.npy", "features_complete.json")):
        raise ValueError("Unexpected expression material before initial authorization")
    train_protocol = read(train / "training_registration.json")
    search_protocol = read(search / "protocol.json")
    protocol = read(heldout / "protocol.json")
    for path, digest in search_protocol["source_sha256"].items():
        if sha(path) != digest:
            raise ValueError(f"Search source changed: {path}")
    for path, digest in protocol["shared_source_sha256"].items():
        if sha(path) != digest:
            raise ValueError(f"Training/evaluation source changed: {path}")
    if sha(train / "training_registration.json") != protocol["training_registration_sha256"]:
        raise ValueError("Training protocol changed")
    checks = {}
    for name, digest in train_protocol["fixed_file_sha256"].items():
        actual = sha(train / name)
        if actual != digest:
            raise ValueError(f"Frozen training artifact changed: {name}")
        checks[name] = actual
    seal = read(train / "panel_seal.json")
    panel = np.load(train / "panel_positions.npy")
    vocabulary = np.load(train / "vocabulary_gene_ids.npy")
    gids = np.load(train / "gene_ids.npy")
    if not np.array_equal(panel, seal["selected_positions"]) or not np.array_equal(gids, vocabulary[panel]):
        raise ValueError("Feature panel / vocabulary alignment changed")
    for name in ("panel_positions.npy", "vocabulary_gene_ids.npy", "gene_ids.npy", "initial_head.pt"):
        checks[name] = sha(train / name)
    if checks["initial_head.pt"] != train_protocol["initial_head_sha256"]:
        raise ValueError("Pretrained prediction head changed")
    if sha(train / "hidden.npy") != read(train / "features_complete.json")["hidden_sha256"]:
        raise ValueError("Frozen training features changed")
    seals = {}
    for seed in (61, 62, 63):
        base = search / f"seed{seed}"
        value = read(base / "selection_seal.json")
        if value["heldout_evaluation_read"] is not False:
            raise ValueError("Selections must precede held-out access")
        expected = {
            search / "protocol.json": value["protocol_sha256"],
            train / f"seed{seed}/development_grid.json": value["grid_sha256"],
            base / "selections.json": value["selections_sha256"],
            base / "controls.json": value["controls_sha256"],
        }
        expected.update({Path(p): d for p, d in value["transcript_sha256"].items()})
        for path, digest in expected.items():
            if sha(path) != digest:
                raise ValueError(f"Selection or transcript changed: {path}")
        for checkpoint in protocol["checkpoints"][str(seed)].values():
            if sha(checkpoint["checkpoint"]) != checkpoint["checkpoint_sha256"]:
                raise ValueError("Changed checkpoint")
        seals[str(seed)] = sha(base / "selection_seal.json")
    evaluator = Path(__file__).with_name("training_heldout.py")
    if sha(evaluator) != protocol["source_sha256"]:
        raise ValueError("Evaluator changed after metadata registration")
    for name, field in (("memberships.csv", "membership_sha256"), ("rosters.json", "roster_sha256")):
        if sha(heldout / name) != protocol[field]:
            raise ValueError("Held-out roster/membership changed")
    value = dict(authorized=True, authorized_by="/root", authorized_utc=datetime.now(timezone.utc).isoformat(),
        heldout_protocol_sha256=sha(heldout / "protocol.json"), heldout_code_sha256=sha(evaluator),
        search_protocol_sha256=sha(search / "protocol.json"), selection_seals=seals,
        training_artifact_checks=checks, pre_access_checks="PASS", heldout_expressions_read_before_authorization=False,
        interpretation="One fixed held-out evaluation after all three Qwen controller trajectories and random/GP choices are sealed")
    target.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(dict(status="AUTHORIZED", path=str(target), sha256=sha(target))))


if __name__ == "__main__":
    main()
