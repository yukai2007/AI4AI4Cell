"""No GPU/model calls; normalization never edits scientific fields."""
import json
from pathlib import Path
import tempfile
import unittest

from extensions.history_repair_20261109 import backend as original
from extensions.history_repair_20261109 import backend_v3 as b
from extensions.history_repair_20261109.test_backend import FakeTransport, MESSAGES


class DecoderTests(unittest.TestCase):
    def test_legal_json_unchanged(self):
        text = r'{"id":"D02","number":0.00003,"text":"\n\t\"\\\/\b\f\r\u03b1"}'
        result = b.decode_json_response(text)
        self.assertEqual(result["parsed"], json.loads(text))
        self.assertEqual(result["normalized_text"], text)
        self.assertEqual(result["transformations"], [])

    def test_complete_fences(self):
        for prefix in ("```json\n", "```\n", "```json\r\n"):
            result = b.decode_json_response(" \n" + prefix + '{"id":"D01"}\n```\n ')
            self.assertEqual(result["parsed"], {"id": "D01"})
            self.assertEqual(result["transformations"], [{"operation": "strip_complete_external_fence"}])

    def test_surrounding_prose_incomplete_multiple_fences_rejected(self):
        for text in ('Here: ```json\n{}\n```', '```json\n{}\n``` after', '```json\n{}',
                     '```json\n{}\n```\n```json\n{}\n```', '```python\n{}\n```', '{} {}'):
            with self.subTest(text=text), self.assertRaises(b.DecodeFailure):
                b.decode_json_response(text)

    def test_latex_invalid_escape_preserves_literal_and_valid_escapes(self):
        text = r'{"hypothesis":"At \(1 \times 10^{-5}\), try \q.","design_id":"D01","min_delta":0.01}'
        result = b.decode_json_response(text)
        self.assertEqual(result["parsed"]["hypothesis"], "At \\(1 \times 10^{-5}\\), try \\q.")
        self.assertEqual(result["parsed"]["design_id"], "D01")
        self.assertEqual(result["parsed"]["min_delta"], .01)
        self.assertEqual(result["transformations"][0]["count"], 3)

    def test_backslash_outside_string_and_bad_punctuation_not_repaired(self):
        for text in (r'{"x":\1}', '{"x":1,}', '{"x":1 "y":2}', '{"x":"unfinished\\'):
            with self.subTest(text=text), self.assertRaises(b.DecodeFailure):
                b.decode_json_response(text)

    def test_invalid_unicode_and_surrogates_rejected(self):
        for text in (r'{"x":"\u123"}', r'{"x":"\uZZZZ"}', r'{"x":"\ud800"}'):
            with self.subTest(text=text), self.assertRaises(b.DecodeFailure):
                b.decode_json_response(text)
        self.assertEqual(b.decode_json_response(r'{"x":"\ud83d\ude00"}')["parsed"], {"x": "😀"})

    def test_duplicate_keys_and_nonfinite_constants_rejected(self):
        for text in ('{"id":"D01","id":"D02"}', '{"x":{"a":1,"a":2}}',
                     '{"x":NaN}', '{"x":Infinity}', '{"x":-Infinity}', '{"x":1e999}', '[]'):
            with self.subTest(text=text), self.assertRaises(b.DecodeFailure):
                b.decode_json_response(text)

    def test_scientific_fields_not_repaired(self):
        value = {"design_id": "wrong", "reference_id": "wrong", "changed_fields": ["not_a_key"],
                 "prediction": {"metric": "nonsense", "direction": "wrong", "min_delta": -9.}}
        self.assertEqual(b.decode_json_response('```json\n' + json.dumps(value) + '\n```')["parsed"], value)


class BackendV3Tests(unittest.TestCase):
    def make(self, folder, responses, **kwargs):
        fake = FakeTransport(responses)
        return b.LocalQwenBackend(folder, transport_factory=lambda **_: fake, **kwargs), fake

    def test_inherits_original_generate_and_constructor(self):
        self.assertIs(b.LocalQwenBackend.generate, original.LocalQwenBackend.generate)
        self.assertIs(b.LocalQwenBackend.__init__, original.LocalQwenBackend.__init__)

    def test_legal_and_fenced_success_one_attempt_preserves_receipts(self):
        for response in ('{"status":"ready"}', '```json\n{"status":"ready"}\n```'):
            with self.subTest(response=response), tempfile.TemporaryDirectory() as folder:
                backend, fake = self.make(folder, [response])
                result = backend.generate_json(MESSAGES, seed=42)
                self.assertTrue(result["valid"])
                self.assertEqual(fake.seeds, [42])
                self.assertEqual(result["attempts"][0]["raw_response"], response)
                receipt = json.loads((Path(folder)/'call_00000.json').read_text())
                self.assertEqual(receipt, result["attempts"][0])
                self.assertEqual(receipt["input_tokens"], 20)
                self.assertEqual(receipt["json_normalization"]["normalized_text"], '{"status":"ready"}')
                self.assertEqual(json.loads((Path(folder)/'request_00000.json').read_text()), result)

    def test_two_attempts_on_scientific_validation_failure(self):
        def validator(value):
            if value.get("design_id") != "D01":
                raise ValueError("Unknown ID")
            value["extra"] = "must not affect parsed"
        with tempfile.TemporaryDirectory() as folder:
            backend, fake = self.make(folder, ['```json\n{"design_id":"bad"}\n```', '{"design_id":"D01"}'])
            result = backend.generate_json(MESSAGES, seed=3, validator=validator)
            self.assertTrue(result["valid"])
            self.assertEqual(fake.seeds, [3, 10003])
            self.assertEqual(result["parsed"], {"design_id": "D01"})
            self.assertIn("Unknown ID", result["attempts"][0]["schema_error"])

    def test_exhaustion_no_fallback(self):
        with tempfile.TemporaryDirectory() as folder:
            backend, fake = self.make(folder, ['{"x":1,}', '{"x":1,}'])
            result = backend.generate_json(MESSAGES, seed=4)
            self.assertFalse(result["valid"])
            self.assertIsNone(result["parsed"])
            self.assertEqual(fake.seeds, [4, 10004])
            self.assertEqual(len(result["normalizations"]), 2)

    def test_transport_failure_and_hardcap_unchanged(self):
        with tempfile.TemporaryDirectory() as folder:
            backend, _ = self.make(folder, [original.TransportFailure("failed", {"input_tokens":28001})])
            with self.assertRaises(original.BackendFailure):
                backend.generate_json(MESSAGES, seed=5)
        with tempfile.TemporaryDirectory() as folder:
            backend, fake = self.make(folder, ['{}'], max_calls=1)
            backend.generate_json(MESSAGES, seed=1)
            with self.assertRaisesRegex(RuntimeError, "Hard model-call cap"):
                backend.generate_json(MESSAGES, seed=1)
            self.assertEqual(fake.seeds, [1])


if __name__ == '__main__':
    unittest.main()
