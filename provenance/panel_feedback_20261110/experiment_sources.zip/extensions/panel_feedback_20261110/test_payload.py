"""Transport invariants that protect selection and matched evidence."""
import ast
from copy import deepcopy
from pathlib import Path
import unittest

from extensions.panel_feedback_20261110.payload import (
    build_card, feedback_row, panel_payload, summarize_panels)

MENU = {"D00": {"lr": .001}, "D01": {"lr": .01}, "D02": {"lr": .0001}}


def vector():
    return [dict(panel_id=f"target:{i}", development=dict(primary=i/10, loss=2-i/10)) for i in range(10)]


class PayloadTests(unittest.TestCase):
    def test_nested_mean_keeps_real_worst_and_panel_labels(self):
        item = panel_payload(vector())
        result = summarize_panels([item])
        self.assertEqual(result["primary"], .45)
        self.assertEqual(result["worst_panel"], 0)
        self.assertGreater(result["panel_primary_sd"], 0)
        self.assertEqual(result["evaluation_workers"], 1)
        self.assertEqual(result["development_panels"], 10)
        self.assertNotIn("worst_client", result)
        self.assertEqual(result["per_panel_development"], vector())

    def test_unknown_vector_never_inferred_from_mean(self):
        with self.assertRaisesRegex(ValueError, "Missing panel vector"):
            summarize_panels([dict(primary=.45, loss=1.55, worst_client=.45, clients=1)])

    def test_wrong_aggregate_and_multiple_workers_rejected(self):
        item = panel_payload(vector())
        item["primary"] += .1
        with self.assertRaisesRegex(ValueError, "contradicts"):
            summarize_panels([item])
        with self.assertRaisesRegex(ValueError, "one target evaluator"):
            summarize_panels([item, item])

    def test_duplicate_labels_nonfinite_and_extra_fields_rejected(self):
        duplicate = vector()
        duplicate[1]["panel_id"] = duplicate[0]["panel_id"]
        bad = vector()
        bad[0]["development"]["loss"] = float("nan")
        leaked = vector()
        leaked[0]["test_score"] = .9
        for values in (duplicate, bad, leaked):
            with self.assertRaises(ValueError):
                panel_payload(values)

    def test_feedback_retains_every_recorded_panel_point_and_inputs(self):
        dev = summarize_panels([panel_payload(vector())])
        point = dict(round=5, train_loss=.2, development=dev)
        record = dict(config=MENU["D00"], best=point, history=[point])
        before = deepcopy(record)
        row = feedback_row(record, "D00")
        self.assertEqual(record, before)
        self.assertEqual(row["per_panel_development"], vector())
        card = build_card([row], "raw", designs=MENU)
        trial = card["evidence"]["trials"][0]
        self.assertEqual(trial["trajectory"]["points"][0]["per_panel_development"], vector())
        self.assertEqual(trial["development_diagnostics"]["target_panel_summary"]["worst_panel"], 0)

    def test_raw_structured_facts_identical_and_direct_has_no_scores(self):
        dev = summarize_panels([panel_payload(vector())])
        point = dict(round=5, train_loss=.2, development=dev)
        row = feedback_row(dict(config=MENU["D00"], best=point, history=[point]), "D00")
        raw = build_card([row], "raw", designs=MENU)
        structured = build_card([row], "structured", designs=MENU)
        derived = {"accepted", "actual_changes", "development_delta", "prediction_result", "unresolved_evidence"}
        self.assertEqual(raw["evidence"]["trials"][0], {
            k:v for k,v in structured["evidence"]["trials"][0].items() if k not in derived})
        direct = build_card([row], "direct", designs=MENU)
        self.assertIsInstance(direct["evidence"], str)
        self.assertNotIn("worst_panel", str(direct))

    def test_missing_intermediate_panel_values_remain_unavailable(self):
        dev = panel_payload(vector())
        early = dict(round=5, development=dict(primary=.3, loss=2))
        best = dict(round=10, development=dev)
        row = feedback_row(dict(config=MENU["D00"], best=best, history=[early, best]), "D00")
        points = build_card([row], "structured", designs=MENU)["evidence"]["trials"][0]["trajectory"]["points"]
        self.assertNotIn("per_panel_development", points[0])
        self.assertEqual(points[1]["per_panel_development"], vector())

    def test_test_fields_rejected_before_projection(self):
        row = dict(design_id="D00", config=MENU["D00"], development=dict(primary=.4, loss=1),
                   unknown={"heldout_score": .8})
        with self.assertRaisesRegex(ValueError, "Forbidden"):
            build_card([row], "structured", designs=MENU)

    def test_frozen_fit_loops_match_except_reducer_and_cpu_provenance(self):
        root = Path(__file__).resolve().parents[2]
        new = ast.parse(Path(__file__).with_name("fitters.py").read_text())
        for original, name in (("extensions/unified_bio_20260918/core_v3.py", "fit_cell"),
                               ("extensions/supplemental_20260923/proteomics/trainer.py", "fit_protein")):
            old = ast.parse((root / original).read_text())
            cls = next(n for n in old.body if isinstance(n, ast.ClassDef) and n.name == "Federation")
            expected = deepcopy(next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "fit"))
            actual = deepcopy(next(n for n in new.body if isinstance(n, ast.FunctionDef) and n.name == name))
            class Normalize(ast.NodeTransformer):
                def visit_Name(self, node):
                    if node.id == "summarize_panels":
                        node.id = "summarize"
                    return node
                def visit_Call(self, node):
                    text = ast.unparse(node)
                    if text in ('Path(__file__).with_name(\'cpu_worker.py\')',
                                'Path(__file__).with_name("cpu_worker.py")') or (
                            isinstance(node.func, ast.Name) and node.func.id == "Path" and node.args and
                            isinstance(node.args[0], ast.Constant) and str(node.args[0].value).endswith("/proteomics/cpu_worker.py")):
                        return ast.Name(id="FROZEN_CPU_WORKER", ctx=ast.Load())
                    return self.generic_visit(node)
            expected.name = actual.name = "fit"
            self.assertEqual(ast.dump(Normalize().visit(expected), include_attributes=False),
                             ast.dump(Normalize().visit(actual), include_attributes=False))


if __name__ == "__main__":
    unittest.main()
