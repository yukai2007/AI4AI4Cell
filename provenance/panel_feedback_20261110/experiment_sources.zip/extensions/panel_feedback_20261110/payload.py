"""Versioned target-panel transport and prompt projection; no held-out access."""
from copy import deepcopy
import math
import numpy as np

from extensions.history_repair_20261109.evidence_cards import build_evidence_card

SCOPE = dict(training_labs=4, development_panels=10,
             evaluation_scope="target_development_panels",
             panels_are_not_training_labs=True,
             selection="equal target-panel primary mean, then lower loss; exact ties retain incumbent")


def panel_payload(values):
    """Preserve the original numpy mean, and retain explicit observed labels."""
    if not values:
        raise ValueError("No recorded panels")
    labels = [r["panel_id"] for r in values]
    if any(not isinstance(label, str) or not label for label in labels) or len(set(labels)) != len(labels):
        raise ValueError("Panel labels must be unique nonempty strings")
    for row in values:
        if set(row) != {"panel_id", "development"}:
            raise ValueError("Only labelled development metrics belong in the panel transport")
        dev = row["development"]
        if set(dev) != {"primary", "loss"} or any(
                isinstance(dev[k], bool) or not isinstance(dev[k], (int, float)) or not math.isfinite(dev[k])
                for k in ("primary", "loss")):
            raise ValueError("Finite primary/loss required")
    scores = [r["development"]["primary"] for r in values]
    return dict(primary=float(np.mean(scores)),
                loss=float(np.mean([r["development"]["loss"] for r in values])),
                evaluation_scope="target_development_panels",
                development_panels=len(values), worst_panel=float(min(scores)),
                panel_primary_sd=float(np.std(scores, ddof=0)),
                panel_primary_range=float(max(scores) - min(scores)),
                panel_sd_interpretation="descriptive population SD across recorded panels, not a confidence interval",
                per_panel_development=deepcopy(values))


def summarize_panels(items):
    """Outer single-target worker reducer: never reinterpret a mean as a panel."""
    if len(items) != 1:
        raise ValueError("This source-defined protocol has exactly one target evaluator")
    item = items[0]
    if "per_panel_development" not in item:
        raise ValueError("Missing panel vector; cannot infer a minimum from a mean")
    result = panel_payload(item["per_panel_development"])
    if result["primary"] != item["primary"] or result["loss"] != item["loss"]:
        raise ValueError("Panel vector contradicts its aggregate")
    return dict(result, evaluation_workers=1)


def feedback_row(record, identifier):
    """Project only a queried fit's development records into evidence cards."""
    best = record["best"]
    result = dict(design_id=identifier, config=deepcopy(record["config"]),
                  development=deepcopy(best["development"]), best_round=best["round"],
                  status="COMPLETE", development_trajectory=[])
    if "per_panel_development" in best["development"]:
        result["per_panel_development"] = deepcopy(best["development"]["per_panel_development"])
    for point in record["history"]:
        if "development" in point:
            result["development_trajectory"].append({key: deepcopy(point[key]) for key in
                                                    ("round", "train_loss", "development") if key in point})
    return result


def build_card(history, mode, *, designs, total_slots=6):
    """Reuse the frozen fact parser, adding the same panel facts to raw/structured."""
    card = build_evidence_card(history, mode, designs=designs, evaluation_scope=SCOPE,
                               total_slots=total_slots)
    if mode not in ("raw", "structured"):
        return card
    for row, trial in zip(history, card["evidence"]["trials"]):
        values = row.get("per_panel_development")
        if values:
            summary = panel_payload(values)
            trial["development_diagnostics"]["target_panel_summary"] = {
                key: value for key, value in summary.items()
                if key not in ("primary", "loss", "per_panel_development")}
        points = {point["round"]: point for point in row.get("development_trajectory", [])}
        for point in trial["trajectory"]["points"]:
            recorded = points.get(point["round"], {}).get("development", {})
            if "per_panel_development" in recorded:
                point["per_panel_development"] = deepcopy(recorded["per_panel_development"])
    return card
