"""Registered, development-only payload audit and paired CPU training canaries."""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
from itertools import combinations
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from extensions.supplement_history_20261007.task_runner import (
    CLIENTS, SEEDS, TASKS, dump, freeze_json, load_task, read, sha)
from extensions.heterolab_feedback_20261019.runner import checked_cache, source_hashes
from extensions.budget1day_20260923.contract import DESIGNS
from extensions.panel_feedback_20261110.payload import (
    build_card, feedback_row, panel_payload, summarize_panels)
from extensions.panel_feedback_20261110.runtime import adapter_class, federation

OUT = ROOT / "results/panel_feedback_20261110/dev_audit_v1"
DERIVED = {"accepted", "actual_changes", "development_delta", "prediction_result", "unresolved_evidence"}


def implementation_hashes():
    paths = sorted(Path(__file__).parent.glob("*.py"))
    result = source_hashes()
    result.update({str(path): sha(path) for path in paths})
    result[str(ROOT / "extensions/history_repair_20261109/evidence_cards.py")] = sha(
        ROOT / "extensions/history_repair_20261109/evidence_cards.py")
    return result


def prepare(out):
    receipts = {task: {str(seed): checked_cache(task, seed)[1] for seed in SEEDS} for task in TASKS}
    protocol = dict(schema="biocoloop-panel-feedback-audit-v1", tasks=list(TASKS), seeds=list(SEEDS),
        menu=DESIGNS, cache_receipts=receipts, source_sha256=implementation_hashes(),
        primary_acceptance=dict(aggregate_max_abs_error=1e-12, canary_exact_weight_equality=True,
            exact_selected_round_equality=True, labelled_panels_per_checkpoint=10,
            raw_structured_identical_observed_facts=True, old_sources_unchanged=True),
        canary=dict(seed=61, designs=["D00", "D07"], rounds=10, evaluation_every=5,
                    arms=["frozen", "panel_transport"], tasks=list(TASKS), planned_fresh_fits=8),
        stability=dict(proposal_panels=[0,2,4,6,8], confirmation_panels=[1,3,5,7,9],
            secondary="all 252 ordered five-panel proposal subsets with complementary confirmation panels",
            selection="primary mean then lower loss; menu order breaks exact ties",
            comparisons="D00 reference versus proposal-selected design; all-panel winner versus proposal winner",
            limit="Existing checkpoints were selected using all ten panels. Complementary-panel scores are descriptive, not independent confirmation; biological split is unchanged."),
        physical_new_main_study_training_fits=0, new_llm_calls=0, heldout_inference=False,
        scope="Engineering repair, complete 72-checkpoint development reconstruction, and eight short paired fits; no new history-effect estimate",
        future_mechanism_plan=dict(status="DESIGN_ONLY_NOT_EXECUTED", tasks=list(TASKS), seeds=list(SEEDS),
            arms=["fixed", "direct", "raw", "structured", "random", "gp_ei"],
            same_facts_for_raw_structured=True, design_library=DESIGNS, slots=6, rounds_per_fit=100,
            search_round_cap=700, maximum_attempts_per_slot=2, invalid_slots_remain_charged=True,
            require_new_registration_before_execution=True,
            checkpoint_rule="retain unchanged all-ten-panel primary/loss rule for the payload representation contrast",
            stability_followup="separate checkpoint-selection study must save every development checkpoint and choose rounds/candidates on proposal panels only before confirmation",
            generalization="new grouped biological split required for confirmatory generalization; old exposed test is retrospective only"))
    freeze_json(out / "protocol.json", protocol)
    registration = out / "registration.json"
    if registration.exists():
        if read(registration)["protocol_sha256"] != sha(out / "protocol.json"):
            raise ValueError("Registration changed")
    else:
        freeze_json(registration, dict(protocol_sha256=sha(out / "protocol.json"),
            frozen_utc=datetime.now(timezone.utc).isoformat(), before_new_development_inference=True))
    return protocol


def checked_protocol(out):
    protocol = read(out / "protocol.json")
    if sha(out / "protocol.json") != read(out / "registration.json")["protocol_sha256"]:
        raise ValueError("Protocol differs from registration")
    if protocol["source_sha256"] != implementation_hashes():
        raise ValueError("Frozen implementation changed; use a new audit version")
    return protocol


def selection_diagnostic(rows):
    labels = [f"target:{index}" for index in range(10)]
    def metrics(identifier, subset):
        values = {r["panel_id"]: r["development"] for r in rows[identifier]["per_panel_development"]}
        return panel_payload([dict(panel_id=label, development=values[label]) for label in subset])
    def pick(subset):
        return max(DESIGNS, key=lambda identifier: (
            metrics(identifier, subset)["primary"], -metrics(identifier, subset)["loss"]))
    full = pick(labels)
    def contrast(subset):
        complement = [label for label in labels if label not in subset]
        selected = pick(subset)
        proposal = metrics(selected, subset)["primary"] - metrics("D00", subset)["primary"]
        confirm = metrics(selected, complement)["primary"] - metrics("D00", complement)["primary"]
        return dict(proposal_panels=subset, selected=selected, all_panel_selected=full,
            proposal_delta_pp=100*proposal, confirmation_delta_pp=100*confirm,
            positive_proposal_negative_confirmation=proposal>1e-12 and confirm < -1e-12)
    primary = contrast(labels[::2])
    exhaustive = [contrast(list(subset)) for subset in combinations(labels, 5)]
    counts = {identifier: sum(row["selected"] == identifier for row in exhaustive) for identifier in DESIGNS}
    return dict(all_panel_selected=full, fixed_even_odd=primary,
        exhaustive=dict(partitions=len(exhaustive), winner_counts=counts,
            all_panel_winner_agreement=sum(row["selected"] == full for row in exhaustive),
            positive_proposal_negative_confirmation=sum(row["positive_proposal_negative_confirmation"] for row in exhaustive),
            negative_confirmation=sum(row["confirmation_delta_pp"] < -1e-10 for row in exhaustive),
            per_partition=exhaustive),
        interpretation="descriptive reuse of all-panel-selected checkpoints; not independent model selection or new biological splits")


def audit_task(out, task):
    started = time.monotonic()
    protocol = checked_protocol(out)
    source = load_task(task)
    path = source.OUT / "data" / ("cross_scenario60_k4" if task == "cell" else "")
    adapter = adapter_class(task, source)(path, 0, "cpu")
    seeds, errors, gaps, equality_checks = {}, [], [], 0
    for seed in SEEDS:
        records, receipts = checked_cache(task, seed)
        if receipts != protocol["cache_receipts"][task][str(seed)]:
            raise ValueError("Candidate binding changed")
        projected = {}
        for identifier, record in records.items():
            source.torch.manual_seed(seed)
            model = adapter.model(record["config"]).eval()
            state = source.torch.load(record["checkpoint"], map_location="cpu", weights_only=False)
            source.restore(model, state)
            with source.torch.inference_mode():
                measured = summarize_panels([adapter.evaluate(model)])
            for key in ("primary", "loss"):
                errors.append(abs(measured[key] - record["best"]["development"][key]))
            if max(errors) > protocol["primary_acceptance"]["aggregate_max_abs_error"]:
                raise ValueError("Repaired transport changes the primary/loss score")
            if [r["panel_id"] for r in measured["per_panel_development"]] != [f"target:{i}" for i in range(10)]:
                raise ValueError("Panel labels differ from original manifest")
            gaps.append(measured["primary"] - measured["worst_panel"])
            new = deepcopy(record)
            new["best"]["development"] = measured
            # Only the saved best checkpoint is reconstructed. No vector is
            # invented for unsaved intermediate rounds.
            row = feedback_row(new, identifier)
            projected[identifier] = row
            history = [row] if identifier == "D00" else [projected["D00"], row]
            raw = build_card(history, "raw", designs=DESIGNS)
            structured = build_card(history, "structured", designs=DESIGNS)
            for left, right in zip(raw["evidence"]["trials"], structured["evidence"]["trials"]):
                if left != {k: v for k,v in right.items() if k not in DERIVED}:
                    raise ValueError("Raw and structured observed facts differ")
            equality_checks += 1
        seeds[str(seed)] = dict(records=projected, selection=selection_diagnostic(projected))
        print(task, seed, "12 checkpoints verified", flush=True)
    result = dict(status="COMPLETE", task=task, protocol_sha256=sha(out / "protocol.json"),
        checkpoint_count=36, labelled_panel_scores=360, raw_structured_checks=equality_checks,
        aggregate_max_abs_error=max(errors), nonzero_mean_worst_gaps=sum(gap > 1e-12 for gap in gaps),
        mean_minus_worst_pp=[100*gap for gap in gaps], seeds=seeds,
        wall_seconds=time.monotonic()-started, new_training_fits=0, new_llm_calls=0,
        heldout_inference=False, cuda_initialized=source.torch.cuda.is_initialized())
    freeze_json(out / task / "development_audit.json", result)
    print(task, "COMPLETE", result["aggregate_max_abs_error"], flush=True)


def canary_task(out, task):
    checked_protocol(out)
    source = load_task(task)
    import numpy as np
    receipts = []
    for identifier in ("D00", "D07"):
        results, weights = {}, {}
        for arm in ("frozen", "panel_transport"):
            folder = out / task / "canary" / identifier / arm
            if folder.exists():
                raise ValueError("Preserve existing canary; verify receipt or use a new run version")
            if arm == "frozen":
                trainer = (source.ScenarioFederation(source.OUT / "data/cross_scenario60_k4", CLIENTS[task])
                           if task == "cell" else source.Federation())
            else:
                trainer = federation(task, source)
            try:
                results[arm] = trainer.fit(DESIGNS[identifier], CLIENTS[task], folder, seed=61, rounds=10)
            finally:
                trainer.close()
            weights[arm] = source.torch.load(folder / "best.pt", map_location="cpu", weights_only=False)
        for left, right in zip(results["frozen"]["history"], results["panel_transport"]["history"]):
            if left["round"] != right["round"] or left["train_loss"] != right["train_loss"]:
                raise ValueError("Training trajectory changed")
            if "development" in left:
                if any(left["development"][k] != right["development"][k] for k in ("primary", "loss")):
                    raise ValueError("Checkpoint scores changed")
                if len(right["development"]["per_panel_development"]) != 10:
                    raise ValueError("Outer fit lost panel vector")
        if results["frozen"]["best"]["round"] != results["panel_transport"]["best"]["round"]:
            raise ValueError("Selected checkpoint changed")
        if set(weights["frozen"]) != set(weights["panel_transport"]) or any(
                not np.array_equal(value, weights["panel_transport"][key]) for key,value in weights["frozen"].items()):
            raise ValueError("Selected model weights changed")
        for filename in ("best.pt", "last.pt"):
            a = source.torch.load(out / task / "canary" / identifier / "frozen" / filename,
                                  map_location="cpu", weights_only=False)
            b = source.torch.load(out / task / "canary" / identifier / "panel_transport" / filename,
                                  map_location="cpu", weights_only=False)
            if filename == "last.pt":
                for field in ("state", "velocity"):
                    if any(not np.array_equal(value, b[field][key]) for key,value in a[field].items()):
                        raise ValueError("Last training state changed")
        row = feedback_row(results["panel_transport"], identifier)
        receipts.append(dict(design_id=identifier, best_round=results["frozen"]["best"]["round"],
            exact_selected_weights=True, exact_last_state_and_velocity=True, exact_training_curve=True,
            exact_development_primary_loss=True,
            development_panel_points=len(row["development_trajectory"]),
            fits={arm: dict(fit_sha256=sha(out / task / "canary" / identifier / arm / "fit.json"),
                checkpoint_sha256=sha(out / task / "canary" / identifier / arm / "best.pt")) for arm in results}))
        print(task, identifier, "paired training PASS", flush=True)
    freeze_json(out / task / "canary_receipt.json", dict(status="COMPLETE", pairs=receipts,
        fresh_fits=4, rounds_per_fit=10, protocol_sha256=sha(out / "protocol.json"),
        heldout_inference=False, new_llm_calls=0, cuda_initialized=source.torch.cuda.is_initialized()))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("prepare", "audit", "canary"))
    parser.add_argument("--task", choices=TASKS)
    parser.add_argument("--out", type=Path, default=OUT)
    args = parser.parse_args()
    if args.command == "prepare":
        prepare(args.out)
        print("FROZEN", sha(args.out / "protocol.json"))
    elif not args.task:
        parser.error("--task required")
    else:
        (audit_task if args.command == "audit" else canary_task)(args.out, args.task)


if __name__ == "__main__":
    main()
