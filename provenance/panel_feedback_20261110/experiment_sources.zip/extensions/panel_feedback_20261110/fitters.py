"""Frozen fit loops copied with only the development reducer versioned.

AST tests compare these bodies to the originals; optimizer, aggregation,
evaluation cadence and primary/loss selection are unchanged.
"""
import copy
import hashlib
import json
from pathlib import Path
import sys
import time
import numpy as np
import torch
from extensions.supplement_history_20261007.task_runner import dump, sha
from extensions.panel_feedback_20261110.payload import summarize_panels
U = Path(__file__).resolve().parents[1] / 'unified_bio_20260918'
sys.path.insert(0, str(U))
from core import validate, select_key
from core_v3 import aggregate


def aggregate_studies(*args):
    # Imported only in the isolated proteomics process.
    from trainer import aggregate_studies as frozen_aggregate
    return frozen_aggregate(*args)

def fit_cell(self, config, clients, out, seed=42, rounds=100):
    config = validate(config)
    out = Path(out)
    out.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    initialized = self.rpc(clients, [dict(op='init', config=config, seed=seed)] * len(clients))
    shared = initialized[0]['initial']
    parameter_keys = initialized[0]['parameter_keys']
    for item in initialized[1:]:
        if item['parameter_keys'] != parameter_keys or any((not np.array_equal(item['initial'][k], v) for (k, v) in shared.items())):
            raise ValueError('Clients must start with identical model parameters')
    (velocity, history, best, communication) = ({}, [], None, 0)
    for rnd in range(1, rounds + 1):
        updates = self.rpc(clients, [dict(op='epoch', state=shared, seed=seed + rnd * 100 + c, batch_size=64) for c in clients])
        (shared, velocity) = aggregate(shared, [r['state'] for r in updates], [r['n'] for r in updates], velocity, config['server_momentum'], parameter_keys)
        communication += 2 * len(clients) * sum((v.nbytes for v in shared.values()))
        row = dict(round=rnd, train_loss=sum((r['loss'] * r['n'] for r in updates)) / sum((r['n'] for r in updates)))
        if rnd % 5 == 0 or rnd == rounds:
            evidence = summarize_panels(self.rpc(clients, [dict(op='dev', state=shared)] * len(clients)))
            row['development'] = evidence
            if best is None or select_key(evidence) > select_key(best['development']):
                best = copy.deepcopy(row)
                torch.save(shared, out / 'best.pt')
            torch.save(dict(state=shared, velocity=velocity, round=rnd), out / 'last.pt')
            (out / 'progress.json').write_text(json.dumps(row, indent=2) + '\n')
        history.append(row)
    record = dict(config=config, clients=clients, seed=seed, rounds=rounds, best=best, history=history, training_seconds=time.monotonic() - started, model_update_bytes=communication, core_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), parameter_keys=parameter_keys, test_read=False)
    (out / 'fit.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
    return record

def fit_protein(self, config, clients, out, seed=61, rounds=100):
    config = validate(config)
    out = Path(out)
    out.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    initialized = self.rpc(clients, [dict(op='init', config=config, seed=seed)] * len(clients))
    shared = initialized[0]['initial']
    keys = initialized[0]['parameter_keys']
    if any((any((not np.array_equal(r['initial'][k], v) for (k, v) in shared.items())) for r in initialized[1:])):
        raise ValueError('Unequal task-specific initialization')
    history = []
    velocity = {}
    best = None
    communication = 0
    target_clients = [c for c in clients if c < 10]
    auxiliary_clients = [c for c in clients if c >= 10]
    for rnd in range(1, rounds + 1):
        updates = self.rpc(clients, [dict(op='epoch', state=shared, seed=seed + rnd * 100 + c, batch_size=64) for c in clients])
        (shared, velocity) = aggregate_studies(shared, updates, clients, velocity, config['server_momentum'], keys)
        communication += 2 * len(clients) * sum((v.nbytes for v in shared.values()))
        row = dict(round=rnd, train_loss=sum((r['loss'] * r['n'] for r in updates)) / sum((r['n'] for r in updates)))
        if rnd % 5 == 0 or rnd == rounds:
            target = summarize_panels(self.rpc(target_clients, [dict(op='dev', state=shared)] * len(target_clients)))
            row['development'] = target
            if auxiliary_clients:
                row['auxiliary_development'] = self.rpc(auxiliary_clients, [dict(op='dev', state=shared)] * len(auxiliary_clients))
            if best is None or select_key(target) > select_key(best['development']):
                best = copy.deepcopy(row)
                torch.save(shared, out / 'best.pt')
            torch.save(dict(state=shared, velocity=velocity, round=rnd), out / 'last.pt')
            dump(out / 'progress.json', row)
        history.append(row)
    record = dict(config=config, clients=clients, seed=seed, rounds=rounds, best=best, history=history, training_seconds=time.monotonic() - started, model_update_bytes=communication, core_sha256=sha(U / 'core_v3.py'), trainer_sha256=sha(__file__), test_read=False, device=self.device, cpu_worker_sha256=sha(Path('/liziqing/yukai/AI4AI4Cell/extensions/supplemental_20260923/proteomics/cpu_worker.py')), selection='target-only equal-client development AP then BCE', extension='source-private head ownership; core_v3 optimizer and per-group aggregate; CPU worker changes device setup and thread count only')
    dump(out / 'fit.json', record)
    return record

