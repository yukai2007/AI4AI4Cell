"""Task-isolated CPU adapters; all frozen source files remain unchanged."""
import multiprocessing as mp
from pathlib import Path

from extensions.supplement_history_20261007.task_runner import load_task, CLIENTS
from extensions.panel_feedback_20261110.payload import panel_payload


def adapter_class(task, source):
    if task == "cell":
        class PanelAdapter(source.ScenarioAdapter):
            def __init__(self, path, client, device):
                super().__init__(path, client, device)
                self.panel_ids = source.read(Path(path) / "manifest.json")["target_development_panels"]

            def evaluate(self, model):
                if self.dev_panels is None:
                    raise ValueError("Only target evaluator owns development panels")
                values = []
                for label, query in zip(self.panel_ids, self.dev_panels):
                    metrics = source.cell_summary([source.cell_evaluate(
                        model, self.dev_hidden, query, self.dev_mask, "cpu")])
                    values.append(dict(panel_id=f"target:{label}", development=dict(
                        primary=metrics["macro_accuracy"], loss=metrics["cross_entropy"])))
                if len(values) != len(self.panel_ids):
                    raise ValueError("Development panel labels lost")
                return panel_payload(values)
        return PanelAdapter
    if task != "protein":
        raise ValueError("Unknown task")

    class PanelAdapter(source.MergedTargetAdapter):
        def __init__(self, path, client, device):
            super().__init__(path, client, device)
            self.panel_ids = source.read(Path(path) / "manifest.json")["original_target_dev_panels"]
            if len(self.panels) != len(self.panel_ids):
                raise ValueError("Development panel labels lost")

        def evaluate(self, model):
            values = []
            for label, panel in zip(self.panel_ids, self.panels):
                metrics = panel.evaluate(model)
                values.append(dict(panel_id=f"target:{label}", development={
                    key: metrics[key] for key in ("primary", "loss")}))
            return panel_payload(values)
    return PanelAdapter


def worker_entry(conn, path, client, task):
    source = load_task(task)
    cls = adapter_class(task, source)
    def loader(data, worker, device):
        return cls(data, worker, device) if worker == 0 else (
            source.ScenarioAdapter(data, worker, device) if task == "cell" else source.Adapter(data, worker, device))
    source.adapters.load_adapter = loader
    source.cpu_local_worker(conn, path, client, "cpu")


def federation(task, source):
    """Only worker factory and development reducer differ from frozen fitters."""
    from extensions.panel_feedback_20261110.fitters import fit_cell, fit_protein
    parent = source.ScenarioFederation if task == "cell" else source.Federation
    class PanelFederation(parent):
        fit = fit_cell if task == "cell" else fit_protein

        def __init__(self):
            self.path = source.OUT / "data" / ("cross_scenario60_k4" if task == "cell" else "")
            self.device, self.workers = "cpu", {}
            ctx = mp.get_context("spawn")
            for client in CLIENTS[task]:
                receiver, sender = ctx.Pipe()
                process = ctx.Process(target=worker_entry, args=(sender, str(self.path), client, task))
                process.start()
                sender.close()
                self.workers[client] = receiver, process
    return PanelFederation()
