"""Text-only service inference for a separately registered proposer comparison."""
import argparse
from copy import deepcopy
from datetime import datetime,timezone
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from extensions.recipe_expansion_20261110_v2.common import OUT as CACHE,checked,dump,read,sha
from extensions.feedback_rebuttal_20261015.transport import generate
from extensions.history_repair_20261109.backend_v3 import decode_json_response
STUDY=ROOT/"results/recipe_expansion_20261110/luna_v1"


def hashes():
    paths=list(Path(__file__).parent.glob("*.py"))
    paths += [ROOT/"extensions/feedback_rebuttal_20261015/transport.py"]
    return {str(path):sha(path) for path in paths}


def register():
    protocol=checked(CACHE)
    path=STUDY/"protocol.json"
    if path.exists():
        return verify()
    if (CACHE/"evaluation/authorization.json").exists():
        raise ValueError("Freeze the proposer comparison before test authorization")
    value=dict(schema="expanded-recipes-luna-proposer-v1",registered_utc=datetime.now(timezone.utc).isoformat(),
        cache_root=str(CACHE),cache_protocol_sha256=sha(CACHE/"protocol.json"),source_sha256=hashes(),
        tasks=protocol["tasks"],seeds=protocol["seeds"],menu=protocol["candidates"],
        reason="Qwen development trajectories remain concentrated on conservative low-ID/low-rate candidates; compare the already used stronger text service before any new test result",
        model="gpt-5.6-luna",reasoning_effort="low",generation_seed_supported=False,
        output_token_cap_enforced=False,output_token_instruction=512,
        arms=["direct","raw","structured"],slots=6,attempts_per_slot=2,max_calls_per_task_seed=32,
        same_messages_schema_decoder_and_selection_as_qwen=True,shared_first_proposal=True,
        physical_new_training_fits=0,reused_complete_candidate_fits=216,
        old_tests_previously_exposed=True,new_test_evaluation_before_registration=False,
        report_all_qwen_and_luna_results=True,backend_role="Only next-message text completion; no tools, file access, browsing or delegation")
    dump(path,value,frozen=True)
    return protocol


def verify():
    protocol=checked(CACHE)
    value=read(STUDY/"protocol.json")
    if value["cache_protocol_sha256"]!=sha(CACHE/"protocol.json") or value["source_sha256"]!=hashes():
        raise ValueError("Frozen Luna comparison changed")
    return protocol


class Backend:
    def __init__(self,folder):
        self.output_dir=Path(folder)
        self.output_dir.mkdir(parents=True,exist_ok=False)
        self.calls,self.requests=0,0
        dump(self.output_dir/"backend.json",dict(model="gpt-5.6-luna",reasoning_effort="low",
            generation_seed_supported=False,output_token_cap_enforced=False,text_only=True),frozen=True)

    def generate_json(self,messages,*,seed,context,validator,schema_description,max_repairs=1):
        if max_repairs!=1:
            raise ValueError("Exactly two bounded attempts allowed")
        request_id=self.requests
        self.requests+=1
        record=dict(request_id=request_id,valid=False,parsed=None,attempts=[],context=deepcopy(context),
                    generation_seed_supported=False,requested_seed=seed)
        working=deepcopy(messages)
        for attempt in range(2):
            if self.calls>=32:
                raise RuntimeError("Hard charged-call cap reached")
            call_id=self.calls
            self.calls+=1
            target=self.output_dir/f"transport_{call_id:05d}"
            try:
                receipt=generate(working,target)
                normalized=decode_json_response(receipt["raw_response"])
                parsed=normalized["parsed"]
                validator(deepcopy(parsed))
                receipt["json_normalization"]={key:normalized[key] for key in ("normalized_text","transformations")}
                record.update(valid=True,parsed=parsed)
            except (ValueError,KeyError,TypeError,RuntimeError) as error:
                receipt=read(target/"receipt.json") if (target/"receipt.json").exists() else dict(raw_response="",usage=[])
                receipt["schema_or_transport_error"]=str(error)
            usage=receipt.get("usage",[])
            receipt.update(call_id=call_id,request_id=request_id,context=deepcopy(context),messages=deepcopy(working),
                status="OK" if record["valid"] else "INVALID_OR_FAILED",purpose="proposal" if attempt==0 else "schema_repair",
                input_tokens=sum(row.get("input_tokens",0) for row in usage),
                output_tokens=sum(row.get("output_tokens",0) for row in usage),
                generation_seconds=receipt.get("seconds",0),token_scope="includes service CLI context overhead")
            path=self.output_dir/f"call_{call_id:05d}.json"
            dump(path,receipt,frozen=True)
            record["attempts"].append(receipt)
            if record["valid"]:
                break
            if attempt==0:
                working += [dict(role="assistant",content=receipt.get("raw_response","")),
                    dict(role="user",content="Schema check failed: "+receipt.get("schema_or_transport_error","")+". "+schema_description)]
        dump(self.output_dir/f"request_{request_id:05d}.json",record,frozen=True)
        return record


def verify_seals():
    protocol=verify()
    values={}
    for task in protocol["tasks"]:
        for seed in protocol["seeds"]:
            folder=STUDY/task/f"seed{seed}"
            seal=read(folder/"selection_seal.json")
            if seal["protocol_sha256"]!=sha(STUDY/"protocol.json") or seal["heldout_evaluation_read"] is not False:
                raise ValueError("Luna selection seal invalid")
            if seal["grid_sha256"]!=sha(CACHE/task/f"seed{seed}/development_grid.json"):
                raise ValueError("Luna grid changed")
            for path,digest in seal["transcript_sha256"].items():
                if sha(path)!=digest:
                    raise ValueError("Luna transcript changed")
            values[f"{task}/{seed}"]=sha(folder/"selection_seal.json")
    return values


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=("register","run","verify"))
    parser.add_argument("--seed",type=int)
    args=parser.parse_args()
    if args.command=="register":
        register();print("LUNA_REGISTERED",sha(STUDY/"protocol.json"))
    elif args.command=="verify":
        print(verify_seals())
    else:
        protocol=verify()
        if args.seed not in protocol["seeds"]:
            raise ValueError("Unregistered seed")
        from extensions.recipe_expansion_luna_20261110.trajectory import run_one
        for task in protocol["tasks"]:
            backend=Backend(STUDY/"backend"/task/f"seed{args.seed}")
            run_one(task,args.seed,backend)


if __name__=="__main__":
    main()
