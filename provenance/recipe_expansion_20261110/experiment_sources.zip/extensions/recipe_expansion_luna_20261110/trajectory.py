"""Same frozen search rules, cached fits, messages and parser; different text service."""
from copy import deepcopy
from pathlib import Path
from extensions.recipe_expansion_luna_20261110.runner import CACHE, STUDY, verify
from extensions.recipe_expansion_20261110_v2.common import dump, read, sha
from extensions.recipe_expansion_20261110_v2.search import (
    ARMS, messages, next_history, observed_record, validate_grid, validate_proposal,
    exact_weights, select_gp, key, SCHEMA)

def run_one(task, seed, backend):
    protocol = verify()
    (records, path) = validate_grid(CACHE, task, seed, protocol)
    folder = STUDY / task / f'seed{seed}'
    if folder.exists():
        raise ValueError('Preserve saved trajectory; do not silently rerun')
    folder.mkdir(parents=True)
    menu = protocol['candidates']
    baseline = observed_record(records['D00'], 'D00', menu)
    histories = {arm: [deepcopy(baseline)] for arm in ARMS}
    request_start = backend.requests
    call_start = backend.calls
    (initial_messages, card) = messages(histories['direct'], 'direct', menu, task, 1)
    shared = backend.generate_json(initial_messages, seed=seed * 100000 + 1, context=dict(task=task, training_seed=seed, slot=1, arm='shared'), validator=lambda value: validate_proposal(value, card), schema_description=SCHEMA, max_repairs=1)
    dump(folder / 'shared_first.json', shared, frozen=True)
    for arm in ARMS:
        histories[arm] = next_history(histories[arm], shared, records, menu, card)
    for slot in range(2, 7):
        for arm in ARMS:
            (msg, card) = messages(histories[arm], arm, menu, task, slot)
            request = backend.generate_json(msg, seed=seed * 100000 + slot, context=dict(task=task, training_seed=seed, slot=slot, arm=arm), validator=lambda value: validate_proposal(value, card), schema_description=SCHEMA, max_repairs=1)
            histories[arm] = next_history(histories[arm], request, records, menu, card)
            dump(folder / arm / f'slot{slot}.json', dict(request=request, history=histories[arm]), frozen=True)
            print(task, seed, arm, slot, request['valid'], (request.get('parsed') or {}).get('design_id'), flush=True)
    normalized = {identifier: observed_record(row, identifier, menu) for (identifier, row) in records.items()}
    selections = {}
    for (arm, history) in histories.items():
        valid = [row for row in history if row.get('development')]
        selected = max(valid, key=key)
        selections[arm] = dict(design_id=selected['design_id'], development=selected['development'], candidate_ids=[row['design_id'] for row in valid], invalid_slots=len(history) - len(valid))
    (weights, count) = exact_weights(normalized)
    controls = dict(random=dict(weights=weights, subsets=count), fixed_D00=dict(design_id='D00'))
    first = (shared.get('parsed') or {}).get('design_id')
    (weights, count) = exact_weights(normalized, 6 if first else 5, first)
    controls['random_shared_first'] = dict(weights=weights, subsets=count)
    for (arm, selection) in selections.items():
        (weights, count) = exact_weights(normalized, len(selection['candidate_ids']) - 1)
        controls['random_realized_' + arm] = dict(weights=weights, subsets=count)
    (trace, selected, ids) = select_gp(menu, lambda identifier: deepcopy(normalized[identifier]), seed, budget=6)
    controls['gp_ei'] = dict(design_id=selected, candidate_ids=ids, trace=trace)
    dump(folder / 'selections.json', selections, frozen=True)
    dump(folder / 'controls.json', controls, frozen=True)
    dump(folder / 'histories.json', histories, frozen=True)
    transcripts = sorted(folder.rglob('*.json'))
    transcripts += [backend.output_dir / f'call_{index:05d}.json' for index in range(call_start, backend.calls)]
    transcripts += [backend.output_dir / f'request_{index:05d}.json' for index in range(request_start, backend.requests)]
    dump(folder / 'selection_seal.json', dict(protocol_sha256=sha(STUDY / 'protocol.json'), grid_sha256=sha(path), selections_sha256=sha(folder / 'selections.json'), controls_sha256=sha(folder / 'controls.json'), transcript_sha256={str(p): sha(p) for p in transcripts}, heldout_evaluation_read=False, physical_calls=backend.calls - call_start, task=task, seed=seed), frozen=True)
    print(task, seed, 'SEALED', {arm: value['design_id'] for (arm, value) in selections.items()}, flush=True)
