"""Paired real controller trajectories and exact random/GP controls."""
import argparse
from collections import defaultdict
from copy import deepcopy
from fractions import Fraction
import math
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from extensions.recipe_expansion_20261110_v2.common import OUT, checked, dump, read, sha
from extensions.history_repair_20261109.evidence_cards import build_evidence_card
from extensions.history_repair_20261109.search_v3 import (
    observed_record as frozen_observed, validate_proposal, next_history as frozen_advance, key, SCHEMA)
from extensions.history_repair_20261109.controls import select_gp, score_key
from extensions.history_repair_20261109.backend_v3 import LocalQwenBackend

ARMS=("direct","raw","structured")
SYSTEM=(
    "Choose experiments to maximize the final retained development primary within six candidate requests. "
    "Every design uses the same seed42 task-trained initialization, ten original training labs, local full epochs, "
    "20 complete rounds, batch size and initialization. Original backbone construction and feature extraction "
    "are shared costs. In DTI the encoder stays fixed and 'full' refits the original classifier. In protein, "
    "'full' refits the complete original observed-response Conv1d/MLP predictor from the 12,390 inputs. "
    "residual32/128 freezes the original predictor and fits a LayerNorm/MLP correction of that width, "
    "initialized to zero output, using per-confounder features for DTI and original response/fingerprint "
    "inputs for protein. DTI retains the original confounder-prior probability mixture. "
    "bce_rank is BCE plus 0.1 within-batch positive-negative softplus ranking loss; bce is ordinary BCE. "
    "constant and cosine are learning-rate schedules, with cosine ending at 0.1 of the initial rate. "
    "All training fits run fully; no early stopping changes budgets. The selection checkpoint is chosen by "
    "development primary then lower BCE. DTI primary is pooled AUROC and protein primary is pooled AP; "
    "panel diagnostics can disagree with pooled scores. Use the exact menu and recorded evidence only. "
    "Aim to improve the final selected predictor, not merely predict a decline correctly. "
    "Return exactly design_id, reference_id, changed_fields, hypothesis, experiment, expected_effect, prediction. "
    "reference_id must be proposal_reference_id. changed_fields lists the exact changed configuration keys. "
    "The three explanation fields are concise nonempty strings. prediction has metric (primary or loss), "
    "direction (increase or decrease), min_delta (nonnegative absolute units). 0.01 is one percentage point. "
    "Return JSON only, under 512 tokens."
)


def observed_record(record,identifier,menu):
    result=frozen_observed(record,identifier,menu)
    points={point["round"]:point for point in record.get("trajectory",[]) if "development" in point}
    for point in result["development_trajectory"]:
        contexts=points[point["round"]]["development"].get("per_context")
        if contexts is not None:
            point["development"]["per_context"]=deepcopy(contexts)
    return result


def next_history(history,request,records,menu,card):
    result=frozen_advance(history,request,records,menu,card)
    if request["valid"]:
        identifier=request["parsed"]["design_id"]
        result[-1]["development_trajectory"]=observed_record(records[identifier],identifier,menu)["development_trajectory"]
    return result


def exact_weights(records,budget=6,first=None):
    """Exact order-averaged random selection, using score groups not subset enumeration."""
    scores={identifier:score_key(row) for identifier,row in records.items()}
    prefix=["D00"]+([] if first is None else [first])
    if first is not None and (first=="D00" or first not in scores):
        raise ValueError("Invalid common first")
    remaining=set(scores)-set(prefix)
    draws=budget-int(first is not None)
    if draws<0 or draws>len(remaining):
        raise ValueError("Invalid random budget")
    denominator=math.comb(len(remaining),draws)
    retained=max(prefix,key=lambda identifier:scores[identifier])
    threshold=scores[retained]
    groups=defaultdict(list)
    for identifier in remaining:
        groups[scores[identifier]].append(identifier)
    def choose(n,k):
        return math.comb(n,k) if 0<=k<=n else 0
    weights={retained:Fraction(choose(sum(scores[i]<=threshold for i in remaining),draws),denominator)}
    for score,identifiers in groups.items():
        if score<=threshold:
            continue
        lower=sum(scores[i]<score for i in remaining)
        mass=Fraction(choose(lower+len(identifiers),draws)-choose(lower,draws),denominator*len(identifiers))
        for identifier in identifiers:
            weights[identifier]=mass
    if sum(weights.values())!=1:
        raise ValueError("Exact random probability mass lost")
    return {identifier:float(value) for identifier,value in sorted(weights.items()) if value},denominator


def messages(history,arm,menu,task,slot):
    card=build_evidence_card(history,"direct" if slot==1 else arm,designs=menu,total_slots=6,
        evaluation_scope=dict(task=task,training_labs=10,development="pooled original rows; per-panel diagnostics",
                              upstream_encoder="shared fixed-default seed42; previously development-selected"))
    reference=next(identifier for identifier,config in menu.items() if config==card["reference_config"])
    card["proposal_reference_id"]=reference
    card["available_changed_fields"]={identifier:sorted(k for k in config if config[k]!=card["reference_config"][k])
                                      for identifier,config in card["available_designs"].items()}
    import json
    return [dict(role="system",content=SYSTEM),dict(role="user",content=json.dumps(card,allow_nan=False))],card


def validate_grid(out,task,seed,protocol):
    path=out/task/f"seed{seed}/development_grid.json"
    grid=read(path)
    if set(grid)!=set(protocol["candidates"]):
        raise ValueError("Incomplete menu")
    steps,examples=set(),set()
    for identifier,row in grid.items():
        fit_path=out/task/f"fits/seed{seed}"/identifier/"summary.json"
        if row!=read(fit_path) or row["config"]!=protocol["candidates"][identifier] or row["seed"]!=seed:
            raise ValueError("Grid differs from complete fit")
        if row["rounds"]!=20 or row["protocol_sha256"]!=sha(out/"protocol.json") or row["test_read"] is not False:
            raise ValueError("Fit protocol differs")
        if sha(row["checkpoint"])!=row["checkpoint_sha256"]:
            raise ValueError("Checkpoint changed")
        eligible=[point for point in row["trajectory"] if "development" in point]
        selected=max(eligible,key=lambda point:(point["development"]["primary"],-point["development"]["loss"]))
        if selected["round"]!=row["best_round"] or selected["development"]!=row["development"]:
            raise ValueError("Checkpoint selection differs from registered development rule")
        steps.add(row["actual_optimizer_steps"])
        examples.add(row["actual_examples_seen"])
    if len(steps)!=1 or len(examples)!=1:
        raise ValueError("Unequal candidate step/exposure budgets")
    return grid,path


def run_one(out,task,seed,backend):
    protocol=checked(out)
    records,path=validate_grid(out,task,seed,protocol)
    folder=out/"search"/task/f"seed{seed}"
    if folder.exists():
        raise ValueError("Preserve saved trajectory; do not silently rerun")
    folder.mkdir(parents=True)
    menu=protocol["candidates"]
    baseline=observed_record(records["D00"],"D00",menu)
    histories={arm:[deepcopy(baseline)] for arm in ARMS}
    request_start=backend.requests
    call_start=backend.calls
    initial_messages,card=messages(histories["direct"],"direct",menu,task,1)
    shared=backend.generate_json(initial_messages,seed=seed*100000+1,
        context=dict(task=task,training_seed=seed,slot=1,arm="shared"),
        validator=lambda value:validate_proposal(value,card),schema_description=SCHEMA,max_repairs=1)
    dump(folder/"shared_first.json",shared,frozen=True)
    for arm in ARMS:
        histories[arm]=next_history(histories[arm],shared,records,menu,card)
    for slot in range(2,7):
        for arm in ARMS:
            msg,card=messages(histories[arm],arm,menu,task,slot)
            request=backend.generate_json(msg,seed=seed*100000+slot,
                context=dict(task=task,training_seed=seed,slot=slot,arm=arm),
                validator=lambda value:validate_proposal(value,card),schema_description=SCHEMA,max_repairs=1)
            histories[arm]=next_history(histories[arm],request,records,menu,card)
            dump(folder/arm/f"slot{slot}.json",dict(request=request,history=histories[arm]),frozen=True)
            print(task,seed,arm,slot,request["valid"],(request.get("parsed") or {}).get("design_id"),flush=True)
    normalized={identifier:observed_record(row,identifier,menu) for identifier,row in records.items()}
    selections={}
    for arm,history in histories.items():
        valid=[row for row in history if row.get("development")]
        selected=max(valid,key=key)
        selections[arm]=dict(design_id=selected["design_id"],development=selected["development"],
            candidate_ids=[row["design_id"] for row in valid],invalid_slots=len(history)-len(valid))
    weights,count=exact_weights(normalized)
    controls=dict(random=dict(weights=weights,subsets=count),fixed_D00=dict(design_id="D00"))
    first=(shared.get("parsed") or {}).get("design_id")
    weights,count=exact_weights(normalized,6 if first else 5,first)
    controls["random_shared_first"]=dict(weights=weights,subsets=count)
    for arm,selection in selections.items():
        weights,count=exact_weights(normalized,len(selection["candidate_ids"])-1)
        controls["random_realized_"+arm]=dict(weights=weights,subsets=count)
    trace,selected,ids=select_gp(menu,lambda identifier:deepcopy(normalized[identifier]),seed,budget=6)
    controls["gp_ei"]=dict(design_id=selected,candidate_ids=ids,trace=trace)
    dump(folder/"selections.json",selections,frozen=True)
    dump(folder/"controls.json",controls,frozen=True)
    dump(folder/"histories.json",histories,frozen=True)
    transcripts=sorted(folder.rglob("*.json"))
    transcripts += [backend.output_dir/f"call_{index:05d}.json" for index in range(call_start,backend.calls)]
    transcripts += [backend.output_dir/f"request_{index:05d}.json" for index in range(request_start,backend.requests)]
    dump(folder/"selection_seal.json",dict(protocol_sha256=sha(out/"protocol.json"),
        grid_sha256=sha(path),selections_sha256=sha(folder/"selections.json"),controls_sha256=sha(folder/"controls.json"),
        transcript_sha256={str(p):sha(p) for p in transcripts},heldout_evaluation_read=False,
        physical_calls=backend.calls-call_start,task=task,seed=seed),frozen=True)
    print(task,seed,"SEALED",{arm:value["design_id"] for arm,value in selections.items()},flush=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--out",type=Path,default=OUT)
    parser.add_argument("--device",default="cuda:4")
    args=parser.parse_args()
    protocol=checked(args.out)
    backend=LocalQwenBackend(args.out/"search/backend",device=args.device,max_calls=192)
    for task in protocol["tasks"]:
        for seed in protocol["seeds"]:
            run_one(args.out,task,seed,backend)


if __name__=="__main__":
    main()
