"""Retrospective evaluation after all task/seed searches are durably sealed."""
import argparse
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from extensions.recipe_expansion_20261110_v2.common import OUT, checked, dump, read, sha


def verify_seals(out):
    protocol=checked(out)
    seals={}
    for task in protocol["tasks"]:
        for seed in protocol["seeds"]:
            folder=out/"search"/task/f"seed{seed}"
            seal=read(folder/"selection_seal.json")
            if seal["protocol_sha256"]!=sha(out/"protocol.json") or seal["heldout_evaluation_read"] is not False:
                raise ValueError("Invalid search seal")
            if seal["selections_sha256"]!=sha(folder/"selections.json") or seal["controls_sha256"]!=sha(folder/"controls.json"):
                raise ValueError("Sealed decisions changed")
            if seal["grid_sha256"]!=sha(out/task/f"seed{seed}/development_grid.json"):
                raise ValueError("Sealed grid changed")
            for filename,digest in seal["transcript_sha256"].items():
                if sha(filename)!=digest:
                    raise ValueError("Sealed transcript changed")
            seals[f"{task}/{seed}"]=sha(folder/"selection_seal.json")
    return protocol,seals


def authorize(out):
    protocol,seals=verify_seals(out)
    value=dict(authorized=True,authorized_by="/root",protocol_sha256=sha(out/"protocol.json"),
        evaluator_sha256=sha(__file__),selection_seals=seals,
        scope="single final retrospective evaluation; exposed original test; no feedback to controller",
        user_authorization="2026-11-10: expand recipes and compare all biological task classes to equal-access/equal-budget random search")
    dump(out/"evaluation/authorization.json",value,frozen=True)
    return value


def check_authorization(out):
    protocol,seals=verify_seals(out)
    auth=read(out/"evaluation/authorization.json")
    if not auth["authorized"] or auth["authorized_by"]!="/root" or auth["selection_seals"]!=seals or \
            auth["protocol_sha256"]!=sha(out/"protocol.json") or auth["evaluator_sha256"]!=sha(__file__):
        raise PermissionError("Explicit matching root authorization and all six seals required")
    return protocol


def prepare_test(out,task,device):
    protocol=check_authorization(out)
    folder=out/"evaluation"/task
    if (folder/"features_receipt.json").exists():
        receipt=read(folder/"features_receipt.json")
        if receipt["feature_sha256"]!=sha(folder/"test.npz"):
            raise ValueError("Test feature artifact changed")
        return
    if folder.exists():
        raise ValueError("Partial evaluation preserved; do not silently replace")
    folder.mkdir(parents=True)
    from extensions.recipe_expansion_20261110_v2.prepare import load_backbone,encode_dti,encode_protein
    adapter,model,initial=load_backbone(task,protocol,device)
    import numpy as np
    if task=="dti":
        import pandas as pd
        from heldout_native_tapb import input_features,LEGACY,DATA_PATH,PINS
        relative=DATA_PATH/"bindingdb/random/test.csv"
        path=LEGACY/"third_party/DrugEvolve"/relative
        if sha(path)!=PINS["sha256"][str(relative)]:
            raise ValueError("Original DTI test roster changed")
        frame=pd.read_csv(path)
        frames={"random":frame}
        public_features,receipt=input_features(frames,device)
        x,probability=encode_dti(adapter,model,frame,public_features,device)
        y=frame.Y.to_numpy().astype(np.float32)
        group=np.arange(len(y))
    else:
        from heldout_ptpc_neural import features
        path=ROOT/"data/proteomics/ptpc_release_20260911/final/final.npz"
        manifest=read(path.parent/"manifest.json")
        if sha(path)!=manifest["files"]["final.npz"]["sha256"]:
            raise ValueError("Original protein test roster changed")
        with np.load(path,allow_pickle=False) as archive:
            raw=dict(archive)
        x,probability=encode_protein(model,features(raw),device)
        y=raw["y"].astype(np.float32)
        group=raw["compound_key"]
    np.savez_compressed(folder/"test.npz",x=x,y=y,group=group)
    dump(folder/"features_receipt.json",dict(task=task,feature_sha256=sha(folder/"test.npz"),
        source_path=str(path),source_sha256=sha(path),rows=len(y),authorized_sha256=sha(out/"evaluation/authorization.json"),
        backbone_sha256=protocol["base_bindings"][task]["checkpoint_sha256"],previously_exposed_test=True),frozen=True)
    print(task,"TEST_FEATURES_READY",len(y),flush=True)


def score(out,task,device):
    protocol=check_authorization(out)
    import numpy as np
    import torch
    from extensions.recipe_expansion_20261110_v2.models import Classifier
    from extensions.recipe_expansion_20261110_v2.train import metrics
    folder=out/"evaluation"/task
    query=dict(np.load(folder/"test.npz",allow_pickle=False))
    initial=torch.load(out/task/"features/initial_head.pt",map_location="cpu",weights_only=True)
    x=torch.as_tensor(query["x"],device=device)
    scores={}
    started=time.monotonic()
    # Evaluate the complete registered candidate menu once; never choose a
    # recipe/seed/stopping point from these scores.
    for seed in protocol["seeds"]:
        seed_scores={}
        for identifier,config in protocol["candidates"].items():
            fit=read(out/task/f"fits/seed{seed}"/identifier/"summary.json")
            if sha(fit["checkpoint"])!=fit["checkpoint_sha256"]:
                raise ValueError("Candidate checkpoint changed")
            model=Classifier(task,initial,config,seed).to(device).eval()
            model.load_state_dict(torch.load(fit["checkpoint"],map_location=device,weights_only=True),strict=True)
            with torch.inference_mode():
                probability=torch.cat([model(block).sigmoid() for block in x.split(1024)]).cpu().numpy()
            np.save(folder/f"seed{seed}_{identifier}_probability.npy",probability)
            seed_scores[identifier]=dict(metrics=metrics(query["y"],probability,task),
                checkpoint_sha256=fit["checkpoint_sha256"],prediction_sha256=sha(folder/f"seed{seed}_{identifier}_probability.npy"))
        scores[str(seed)]=seed_scores
        print(task,seed,"36 candidates scored",flush=True)
    result=dict(status="COMPLETE",task=task,scores=scores,seconds=time.monotonic()-started,
        protocol_sha256=sha(out/"protocol.json"),authorization_sha256=sha(out/"evaluation/authorization.json"),
        no_test_selection=True,previously_exposed=True)
    dump(folder/"scores.json",result,frozen=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=("authorize","prepare","score"))
    parser.add_argument("--out",type=Path,default=OUT)
    parser.add_argument("--task",choices=("dti","protein"))
    parser.add_argument("--device",default="cuda:6")
    args=parser.parse_args()
    if args.command=="authorize":
        authorize(args.out)
    elif args.task:
        (prepare_test if args.command=="prepare" else score)(args.out,args.task,args.device)
    else:
        parser.error("--task required")


if __name__=="__main__":
    main()
