"""Task classifier heads on fixed observed representations."""
from copy import deepcopy
import torch
from torch import nn
from torch.nn import functional as F


class Classifier(nn.Module):
    def __init__(self, task, initial, config, seed):
        super().__init__()
        torch.manual_seed(seed)
        self.task = task
        if task == "dti":
            width, outputs = initial["weight"].shape[1], 2
            self.base = nn.Linear(width, 2)
            self.base.load_state_dict({key: initial[key] for key in ("weight", "bias")})
            self.register_buffer("prior", initial["prior"].clone())
        else:
            from extensions.unified_bio_20260918.ptpc_neural_adapter import Predictor
            width, outputs = 2*initial["n_proteins"]+initial["n_drug_features"], 1
            self.base = Predictor(initial["n_proteins"],initial["n_drug_features"],False)
            self.base.load_state_dict(initial["state"],strict=True)
        self.correction = None
        if config["head"] != "full":
            self.base.requires_grad_(False)
            hidden = int(config["head"].removeprefix("residual"))
            self.correction = nn.Sequential(nn.LayerNorm(width), nn.Linear(width, hidden), nn.GELU(), nn.Linear(hidden, outputs))
            nn.init.zeros_(self.correction[-1].weight)
            nn.init.zeros_(self.correction[-1].bias)

    def forward(self, x):
        logits = self.base(x)
        if self.task == "protein":
            logits = logits.unsqueeze(-1)
        if self.correction is not None:
            logits = logits + self.correction(x)
        if self.task == "dti":
            probabilities = (logits.softmax(-1) * self.prior[None, :, None]).sum(1)
            return probabilities[:, 1].clamp_min(1e-7).log() - probabilities[:, 0].clamp_min(1e-7).log()
        return logits.squeeze(-1)


def objective(logits, labels, name):
    loss = F.binary_cross_entropy_with_logits(logits, labels)
    if name == "bce_rank":
        positive, negative = logits[labels == 1], logits[labels == 0]
        if len(positive) and len(negative):
            loss = loss + .1 * F.softplus(negative[:,None] - positive[None,:]).mean()
    elif name != "bce":
        raise ValueError("Unregistered objective")
    return loss


def state(model):
    return {key: value.detach().clone() for key,value in model.state_dict().items()}
