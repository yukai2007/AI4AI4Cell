"""Scientific invariants for the expanded recipe experiment."""
from copy import deepcopy
import math
import unittest

import numpy as np
import torch
from extensions.recipe_expansion_20261110_v2.common import menu
from extensions.recipe_expansion_20261110_v2.models import Classifier, objective
from extensions.recipe_expansion_20261110_v2.search import exact_weights, messages, observed_record
from extensions.history_repair_20261109.controls import exact_random_weights
from extensions.history_repair_20261109.evidence_cards import build_evidence_card
from extensions.recipe_expansion_20261110_v2.train import metrics


class RecipeTests(unittest.TestCase):
    def test_architectures_preserve_same_initial_classifier(self):
        torch.manual_seed(1)
        dti=dict(weight=torch.randn(2,4),bias=torch.randn(2),prior=torch.ones(3)/3)
        from extensions.unified_bio_20260918.ptpc_neural_adapter import Predictor
        protein=dict(state=Predictor(2,2,False).state_dict(),n_proteins=2,n_drug_features=2)
        for task,initial,x in (("dti",dti,torch.randn(8,3,4)),("protein",protein,torch.randn(8,6))):
            outputs=[]
            for head in ("full","residual32","residual128"):
                outputs.append(Classifier(task,initial,dict(head=head),71)(x))
            self.assertTrue(torch.equal(outputs[0],outputs[1]))
            self.assertTrue(torch.equal(outputs[0],outputs[2]))

    def test_residual_gradient_does_not_update_frozen_base(self):
        initial=dict(weight=torch.randn(2,4),bias=torch.randn(2),prior=torch.ones(3)/3)
        model=Classifier("dti",initial,dict(head="residual32"),71)
        objective(model(torch.randn(8,3,4)),torch.arange(8).remainder(2).float(),"bce_rank").backward()
        self.assertTrue(all(p.grad is None for p in model.base.parameters()))
        self.assertGreater(model.correction[-1].weight.grad.abs().sum(),0)

    def test_rank_objective_handles_single_local_class(self):
        for labels in (torch.zeros(4),torch.ones(4)):
            logits=torch.randn(4,requires_grad=True)
            self.assertEqual(float(objective(logits,labels,"bce_rank")),float(objective(logits,labels,"bce")))
            objective(logits,labels,"bce_rank").backward()
            self.assertTrue(torch.isfinite(logits.grad).all())

    def test_analytic_random_matches_exhaustive_with_ties_and_shared_first(self):
        records={f"D{i:02d}":dict(development=dict(primary=(i%3)/10,loss=1+(i%2)/10)) for i in range(8)}
        for budget in range(7):
            for first in (None,"D01","D03"):
                if first and budget==0:
                    continue
                actual,count=exact_weights(records,budget,first)
                expected,n=exact_random_weights(records,budget,first)
                self.assertEqual(count,n)
                self.assertEqual(actual,expected)

    def test_large_menu_random_is_exact_without_monte_carlo(self):
        records={identifier:dict(development=dict(primary=i/100,loss=1)) for i,identifier in enumerate(menu())}
        weights,count=exact_weights(records)
        self.assertEqual(count,math.comb(35,6))
        self.assertAlmostEqual(sum(weights.values()),1)
        self.assertAlmostEqual(weights["D35"],6/35)

    def test_direct_and_cold_start_do_not_receive_scores(self):
        library=menu()
        history=[dict(design_id="D00",config=library["D00"],development=dict(primary=.9387654321,loss=.87654321))]
        cold=[messages(history,arm,library,"dti",1) for arm in ("direct","raw","structured")]
        self.assertEqual(cold[0],cold[1])
        self.assertEqual(cold[1],cold[2])
        self.assertNotIn(".9387654321",str(cold[0]))

    def test_full_recorded_context_trajectory_shared_by_history_modes(self):
        library=menu()
        dev=dict(primary=.6,loss=.8,per_context={"target:0":dict(primary=.4,loss=1.)})
        record=dict(config=library["D00"],development=dev,best_round=2,
                    trajectory=[dict(round=2,development=dev,train_loss=.9)])
        row=observed_record(record,"D00",library)
        raw=build_evidence_card([row],"raw",designs=library,evaluation_scope="pooled")
        structured=build_evidence_card([row],"structured",designs=library,evaluation_scope="pooled")
        derived={"accepted","actual_changes","development_delta","prediction_result","unresolved_evidence"}
        self.assertEqual(raw["evidence"]["trials"][0],{k:v for k,v in structured["evidence"]["trials"][0].items() if k not in derived})
        point=raw["evidence"]["trials"][0]["trajectory"]["points"][0]
        self.assertIn("target:0",point["development_diagnostics"]["per_context"])

    def test_one_class_panel_never_becomes_perfect_AP(self):
        result=metrics(np.ones(4),np.array([.1,.2,.3,.4]),"protein")
        self.assertIsNone(result["primary"])
        self.assertEqual(result["status"],"ONE_CLASS_UNAVAILABLE")


if __name__=="__main__":
    unittest.main()
