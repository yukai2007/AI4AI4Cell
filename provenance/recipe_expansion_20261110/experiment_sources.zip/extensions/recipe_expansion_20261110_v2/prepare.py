"""Prepare train/dev representations; test roles are a separate sealed command."""
import argparse
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from extensions.recipe_expansion_20261110_v2.common import OUT, DATA, checked, dump, read, sha


def load_backbone(task, protocol, device):
    u = ROOT / "extensions/unified_bio_20260918"
    sys.path.insert(0, str(u))
    if task == "dti":
        import run_native_tapb  # native interpreter bootstrap before torch
        from tapb_native_adapter import TAPBAdapter
        adapter = TAPBAdapter(DATA[task], 0, device)
    else:
        from ptpc_neural_adapter import PTPCNeuralAdapter
        adapter = PTPCNeuralAdapter(DATA[task], 0, device)
    import torch
    from core import DEFAULT, restore
    torch.set_num_threads(2)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.manual_seed(42)
    model = adapter.model(DEFAULT).to(device).eval()
    restore(model, torch.load(protocol["base_bindings"][task]["checkpoint"], map_location="cpu", weights_only=False))
    if task == "dti":
        initial = {key: value.detach().cpu() for key,value in model.classifier.state_dict().items()}
        initial["prior"] = model.p_ci.detach().cpu()
    else:
        initial = dict(state={key:value.detach().cpu() for key,value in model.state_dict().items()},
                       n_proteins=adapter.n_proteins,n_drug_features=adapter.n_drug_features)
    return adapter, model, initial


def encode_dti(adapter, model, frame, feature_cache, device, progress=None):
    import numpy as np
    import torch
    captured, probabilities = [], []
    def capture(module, args):
        captured.append(args[0].detach().cpu().numpy().copy())
    handle = model.classifier.register_forward_pre_hook(capture)
    dataset = adapter.modules["data"].DTIDataset(frame.index.values, frame, feature_cache)
    try:
        with torch.inference_mode():
            for begin in range(0, len(frame), 64):
                examples = []
                for index in range(begin, min(begin+64, len(frame))):
                    example = dict(dataset[index])
                    example["Protein"] = example["Protein"].to(device)
                    examples.append(example)
                output = adapter.forward(model, adapter.dev_collate(examples), False)
                probabilities.extend(output["logits"].reshape(-1, 2)[:, 1].detach().cpu().tolist())
                if progress and begin % 640 == 0:
                    dump(progress, dict(rows=min(begin+64,len(frame)), total=len(frame), role="train_or_development"))
                    print("DTI features", min(begin+64,len(frame)), "/", len(frame), flush=True)
    finally:
        handle.remove()
    return np.concatenate(captured).astype(np.float32), np.asarray(probabilities)


def encode_protein(model, x, device):
    import numpy as np
    import torch
    probabilities = []
    with torch.inference_mode():
        for begin in range(0,len(x),128):
            logits = model(torch.as_tensor(x[begin:begin+128], dtype=torch.float32, device=device))
            probabilities.extend(logits.sigmoid().detach().cpu().tolist())
    return np.asarray(x,dtype=np.float32), np.asarray(probabilities)


def prepare(out, task, device):
    protocol = checked(out)
    manifest = read(DATA[task] / "manifest.json")
    for name,digest in manifest.get("data_sha256",manifest.get("shard_sha256",{})).items():
        if sha(DATA[task]/name)!=digest:
            raise ValueError("Original prepared input changed: "+name)
    target = out / task / "features"
    if (target / "receipt.json").exists():
        receipt = read(target / "receipt.json")
        for path,digest in receipt["artifacts"].items():
            if sha(path) != digest:
                raise ValueError("Feature artifact changed")
        return receipt
    if target.exists():
        raise ValueError("Partial feature extraction preserved; inspect before a new output version")
    target.mkdir(parents=True)
    if task=="dti":
        # Reuse unchanged representation bytes, never duplicate the expensive
        # backbone pass or pretend this is a second feature extraction.
        import shutil
        parent=ROOT/"results/recipe_expansion_20261110/v1/dti/features"
        receipt=read(parent/"receipt.json")
        if receipt["common_encoder"]["checkpoint_sha256"]!=protocol["base_bindings"][task]["checkpoint_sha256"]:
            raise ValueError("DTI reuse has a different common encoder")
        artifacts={}
        for filename in ("train.npz","dev.npz","initial_head.pt"):
            if sha(parent/filename)!=receipt["artifacts"][str(parent/filename)]:
                raise ValueError("Parent DTI features changed")
            shutil.copy2(parent/filename,target/filename)
            artifacts[str(target/filename)]=sha(target/filename)
        value=dict(receipt,protocol_sha256=sha(out/"protocol.json"),artifacts=artifacts,
                   seconds=0.,reused_parent_receipt=str(parent/"receipt.json"),
                   reused_parent_receipt_sha256=sha(parent/"receipt.json"),
                   shared_original_extraction_seconds=receipt["seconds"])
        dump(target/"receipt.json",value,frozen=True)
        print("DTI unchanged feature cache reused",flush=True)
        return value
    started = time.monotonic()
    adapter, model, initial = load_backbone(task, protocol, device)
    import numpy as np
    import torch
    import pandas as pd
    from extensions.recipe_expansion_20261110_v2.models import Classifier
    paths, counts, parity = {}, {}, {}
    torch.save(initial, target / "initial_head.pt")
    reference = Classifier(task, initial, protocol["candidates"]["D00"], 71).to(device).eval()
    for role in ("train", "dev"):
        if task == "dti":
            shards = [pd.read_csv(DATA[task] / f"clients/{client}/{role}.csv") for client in range(10)]
            frame = pd.concat(shards, ignore_index=True)
            x, probabilities = encode_dti(adapter, model, frame, adapter.datasets["dev"].pr_features,
                                          device, target / "progress.json")
            y = frame.Y.to_numpy().astype(np.float32)
            clients = np.concatenate([np.full(len(shard),i) for i,shard in enumerate(shards)])
        else:
            shards = []
            for client in range(10):
                with np.load(DATA[task] / f"clients/{client}/{role}.npz", allow_pickle=False) as archive:
                    shards.append(dict(archive))
            x, probabilities = encode_protein(model, np.concatenate([shard["x"] for shard in shards]), device)
            y = np.concatenate([shard["y"] for shard in shards]).astype(np.float32)
            clients = np.concatenate([np.full(len(shard["y"]),i) for i,shard in enumerate(shards)])
        with torch.inference_mode():
            predicted = np.concatenate([reference(torch.as_tensor(x[begin:begin+256], device=device)).sigmoid().cpu().numpy()
                                         for begin in range(0,len(x),256)])
        error = float(np.max(np.abs(predicted-probabilities)))
        if error > 2e-6:
            raise ValueError("Frozen-classifier representation does not reproduce its original output: " + str(error))
        np.savez_compressed(target / f"{role}.npz", x=x, y=y, client=clients)
        counts[role] = dict(rows=len(y), positives=int(y.sum()), shape=list(x.shape),
                            clients=[int((clients==i).sum()) for i in range(10)])
        parity[role] = error
        paths[str(target / f"{role}.npz")] = sha(target / f"{role}.npz")
    paths[str(target / "initial_head.pt")] = sha(target / "initial_head.pt")
    receipt = dict(status="COMPLETE", task=task, protocol_sha256=sha(out/"protocol.json"),
                   artifacts=paths, counts=counts, classifier_probability_max_abs_error=parity,
                   seconds=time.monotonic()-started, device=device, heldout_read=False,
                   common_encoder=protocol["base_bindings"][task])
    dump(target / "receipt.json", receipt, frozen=True)
    print(task, "FEATURES_READY", counts, parity, flush=True)
    return receipt


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=OUT)
    parser.add_argument("--task", choices=("dti","protein"), required=True)
    parser.add_argument("--device", default="cuda:6")
    args=parser.parse_args()
    prepare(args.out,args.task,args.device)


if __name__ == "__main__":
    main()
