"""The same charged two-attempt schema adapter, on the completed-turn transport."""
from copy import deepcopy
from pathlib import Path
from extensions.recipe_expansion_20261110_v2.common import dump, read
from extensions.history_repair_20261109.backend_v3 import decode_json_response
from extensions.recipe_search_compact_20261110.text_transport import generate

class LunaBackend:

    def __init__(self, folder):
        self.output_dir = Path(folder)
        self.output_dir.mkdir(parents=True, exist_ok=False)
        (self.calls, self.requests) = (0, 0)
        dump(self.output_dir / 'backend.json', dict(model='gpt-5.6-luna', reasoning_effort='low', generation_seed_supported=False, output_token_cap_enforced=False, text_only=True), frozen=True)

    def generate_json(self, messages, *, seed, context, validator, schema_description, max_repairs=1):
        if max_repairs != 1:
            raise ValueError('Exactly two bounded attempts allowed')
        request_id = self.requests
        self.requests += 1
        record = dict(request_id=request_id, valid=False, parsed=None, attempts=[], context=deepcopy(context), generation_seed_supported=False, requested_seed=seed)
        working = deepcopy(messages)
        for attempt in range(2):
            if self.calls >= 32:
                raise RuntimeError('Hard charged-call cap reached')
            call_id = self.calls
            self.calls += 1
            target = self.output_dir / f'transport_{call_id:05d}'
            try:
                receipt = generate(working, target)
                normalized = decode_json_response(receipt['raw_response'])
                parsed = normalized['parsed']
                validator(deepcopy(parsed))
                receipt['json_normalization'] = {key: normalized[key] for key in ('normalized_text', 'transformations')}
                record.update(valid=True, parsed=parsed)
            except (ValueError, KeyError, TypeError, RuntimeError) as error:
                receipt = read(target / 'receipt.json') if (target / 'receipt.json').exists() else dict(raw_response='', usage=[])
                receipt['schema_or_transport_error'] = str(error)
            usage = receipt.get('usage', [])
            receipt.update(call_id=call_id, request_id=request_id, context=deepcopy(context), messages=deepcopy(working), status='OK' if record['valid'] else 'INVALID_OR_FAILED', purpose='proposal' if attempt == 0 else 'schema_repair', input_tokens=sum((row.get('input_tokens', 0) for row in usage)), output_tokens=sum((row.get('output_tokens', 0) for row in usage)), generation_seconds=receipt.get('seconds', 0), token_scope='includes service CLI context overhead')
            path = self.output_dir / f'call_{call_id:05d}.json'
            dump(path, receipt, frozen=True)
            record['attempts'].append(receipt)
            if record['valid']:
                break
            if attempt == 0:
                working += [dict(role='assistant', content=receipt.get('raw_response', '')), dict(role='user', content='Schema check failed: ' + receipt.get('schema_or_transport_error', '') + '. ' + schema_description)]
        dump(self.output_dir / f'request_{request_id:05d}.json', record, frozen=True)
        return record
