"""Read a completed text turn directly; do not wait for CLI background shutdown."""
import json
import os
from pathlib import Path
import selectors
import shutil
import signal
import subprocess
import tempfile
import time

MODEL="gpt-5.6-luna"


def generate(messages,target):
    target=Path(target)
    target.mkdir(parents=True,exist_ok=False)
    (target/"messages.json").write_text(json.dumps(messages,ensure_ascii=False,indent=2))
    prompt=("Act only as a text-completion backend for the serialized conversation. Produce its next assistant reply. "
            "Do not use tools, browse, inspect files, delegate or execute commands. Return only the requested concise JSON.\n"
            +json.dumps(messages,ensure_ascii=False))
    command=[shutil.which("codex"),"exec","--ephemeral","--json","--sandbox","read-only",
             "--skip-git-repo-check","--ignore-user-config","--ignore-rules","--disable","apps",
             "-c","mcp_servers={}","-m",MODEL,"-c",'model_reasoning_effort="low"']
    started=time.monotonic()
    events=[]
    turn_complete=False
    terminated_after_completed_turn=False
    with tempfile.TemporaryDirectory(prefix="biocoloop-text-only-") as cwd:
        with (target/"events.jsonl").open("w") as output,(target/"stderr.log").open("w") as error:
            process=subprocess.Popen(command+["-C",cwd,"-"],stdin=subprocess.PIPE,stdout=subprocess.PIPE,
                stderr=error,start_new_session=True)
            process.stdin.write(prompt.encode())
            process.stdin.close()
            selector=selectors.DefaultSelector()
            selector.register(process.stdout,selectors.EVENT_READ)
            pending=b""
            while time.monotonic()-started<180:
                ready=selector.select(timeout=1)
                if not ready:
                    if process.poll() is not None:
                        break
                    continue
                chunk=os.read(process.stdout.fileno(),65536)
                if not chunk:
                    break
                pending+=chunk
                while b"\n" in pending:
                    line,pending=pending.split(b"\n",1)
                    output.write(line.decode()+"\n")
                    output.flush()
                    if line.strip():
                        event=json.loads(line)
                        events.append(event)
                        if event.get("type")=="turn.completed":
                            turn_complete=True
                            break
                if turn_complete:
                    break
            selector.close()
            if process.poll() is None:
                terminated_after_completed_turn=turn_complete
                os.killpg(process.pid,signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL)
                process.wait(timeout=5)
            process.stdout.close()
    items=[event["item"] for event in events if event.get("type")=="item.completed"]
    tool_events=[item for item in items if item.get("type") not in ("agent_message","reasoning")]
    usage=[event.get("usage",{}) for event in events if event.get("type")=="turn.completed"]
    response="\n".join(item.get("text","") for item in items if item.get("type")=="agent_message")
    receipt=dict(model=MODEL,reasoning_effort="low",seconds=time.monotonic()-started,
        returncode=process.returncode,turn_completed=turn_complete,
        terminated_after_completed_turn=terminated_after_completed_turn,
        raw_response=response,usage=usage,tool_events=tool_events,messages=messages,command=command,
        generation_seed_supported=False,output_token_cap_enforced=False,
        config_reference="https://learn.chatgpt.com/docs/config-file/config-reference#featuresapps")
    (target/"receipt.json").write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+"\n")
    if not turn_complete or tool_events or not usage or not response.strip():
        raise RuntimeError("No valid completed text-only turn; charged receipt preserved")
    return receipt
