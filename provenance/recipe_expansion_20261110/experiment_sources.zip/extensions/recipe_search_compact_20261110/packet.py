"""Reversible panel-table encoding; retain every recorded metric and trajectory."""
from copy import deepcopy
import hashlib
import json


def pack(card):
    axes=[]
    def index(label):
        if label not in axes:
            axes.append(label)
        return axes.index(label)
    def encode(node):
        if isinstance(node,list):
            if node and all(isinstance(row,dict) and set(row)=={"panel_id","development"} and
                            set(row["development"])=={"primary","loss"} for row in node):
                return {"panel_rows":[[index(row["panel_id"]),row["development"]["primary"],row["development"]["loss"]]
                                      for row in node]}
            return [encode(value) for value in node]
        if not isinstance(node,dict):
            return node
        result={}
        for key,value in node.items():
            if key=="per_context" and value and isinstance(value,dict) and all(
                    isinstance(row,dict) and set(row)=={"development","diagnostics"} and
                    set(row["development"])=={"primary","loss"} for row in value.values()):
                rows=[[index(label),row["development"]["primary"],row["development"]["loss"],
                       encode(row["diagnostics"]) if row["diagnostics"] else 0] for label,row in value.items()]
                result[key]={"context_rows":rows}
            else:
                result[key]=encode(value)
        return result
    value=encode(deepcopy(card))
    # IDs have no ordinal meaning. A common outcome-independent presentation
    # order avoids placing every low-learning-rate recipe first.
    for name in ("available_designs","available_changes_from_default","available_changed_fields"):
        if isinstance(value.get(name),dict):
            value[name]={key:value[name][key] for key in sorted(value[name],
                key=lambda identifier:hashlib.sha256(identifier.encode()).hexdigest())}
    return dict(format="complete-panel-tables-v1",panel_axis=axes,
        panel_row_columns=["panel_axis_index","primary","loss"],
        context_row_columns=["panel_axis_index","primary","loss","other_diagnostics; 0 means empty"],card=value)


def unpack(packet):
    if packet["format"]!="complete-panel-tables-v1":
        raise ValueError("Unknown packet")
    axes=packet["panel_axis"]
    def decode(node):
        if isinstance(node,list):
            return [decode(value) for value in node]
        if not isinstance(node,dict):
            return node
        if set(node)=={"panel_rows"}:
            return [dict(panel_id=axes[row[0]],development=dict(primary=row[1],loss=row[2])) for row in node["panel_rows"]]
        if set(node)=={"context_rows"}:
            return {axes[row[0]]:dict(development=dict(primary=row[1],loss=row[2]),
                    diagnostics={} if row[3]==0 else decode(row[3])) for row in node["context_rows"]}
        return {key:decode(value) for key,value in node.items()}
    return decode(packet["card"])


def messages_for(history,arm,menu,task,slot):
    from extensions.recipe_expansion_20261110_v2.search import messages
    result,card=messages(history,arm,menu,task,slot)
    packet=pack(card)
    if unpack(packet)!=card:
        raise ValueError("Panel packing changed recorded facts")
    result[0]["content"] += (
        " The user message uses reversible panel tables. panel_axis maps numeric panel indices to labels; "
        "panel_rows columns are index, primary, loss. context_rows add other diagnostics (0 means empty). "
        "All recorded points remain present. The proposal card is packet.card. Candidate IDs are arbitrary "
        "labels, not an ordering of quality or similarity. Compare actual recipe values and outcomes; "
        "test a different architecture/rate region when measured trials do not improve the incumbent.")
    result[1]["content"]=json.dumps(packet,ensure_ascii=False,separators=(",",":"),allow_nan=False)
    return result,card
