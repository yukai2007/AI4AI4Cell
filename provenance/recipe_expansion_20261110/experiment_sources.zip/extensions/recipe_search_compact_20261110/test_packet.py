import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch

from extensions.recipe_search_compact_20261110.packet import pack,unpack,messages_for
from extensions.recipe_search_compact_20261110.controls import select_gp_zero
from extensions.recipe_expansion_20261110_v2.common import menu
from extensions.recipe_expansion_20261110_v2.search import observed_record
from extensions.history_repair_20261109.evidence_cards import build_evidence_card
from extensions.recipe_search_compact_20261110.text_transport import generate


class PacketTests(unittest.TestCase):
    def fixture(self):
        library=menu()
        dev=dict(primary=.6,loss=.8,per_context={f"target:{i}":dict(primary=i/10,loss=1+i/10) for i in range(10)})
        record=dict(config=library["D00"],development=dev,best_round=20,
            trajectory=[dict(round=r,development=dev,train_loss=.7) for r in [2,5,10,20]])
        return library,[observed_record(record,"D00",library)]

    def test_every_panel_and_point_restored_exactly(self):
        library,history=self.fixture()
        card=build_evidence_card(history,"structured",designs=library,evaluation_scope="pooled")
        packet=pack(card)
        self.assertEqual(unpack(packet),card)
        self.assertLess(len(json.dumps(packet)),len(json.dumps(card)))
        self.assertEqual(len(packet["panel_axis"]),10)

    def test_fact_equality_between_raw_and_structured_after_round_trip(self):
        library,history=self.fixture()
        raw=unpack(pack(build_evidence_card(history,"raw",designs=library,evaluation_scope="pooled")))
        structured=unpack(pack(build_evidence_card(history,"structured",designs=library,evaluation_scope="pooled")))
        derived={"accepted","actual_changes","development_delta","prediction_result","unresolved_evidence"}
        self.assertEqual(raw["evidence"]["trials"][0],{k:v for k,v in structured["evidence"]["trials"][0].items() if k not in derived})

    def test_cold_start_and_direct_do_not_leak_metrics(self):
        library,history=self.fixture()
        values=[messages_for(history,arm,library,"dti",1) for arm in ("direct","raw","structured")]
        self.assertEqual(values[0],values[1]);self.assertEqual(values[1],values[2])
        packet=json.loads(values[0][0][1]["content"])
        self.assertIsInstance(packet["card"]["evidence"],str)
        self.assertNotIn("per_context",str(packet))

    def test_extra_diagnostics_not_lost(self):
        source=dict(per_context={"a":dict(development=dict(primary=.4,loss=.8),diagnostics=dict(mse=.2))})
        self.assertEqual(unpack(pack(source)),source)

    def test_zero_offset_gp_respects_six_query_budget(self):
        library=menu();seen=[]
        def get(identifier):
            self.assertNotIn(identifier,seen);seen.append(identifier)
            return dict(config=library[identifier],development=dict(primary=.9+int(identifier[1:])*1e-6,loss=1))
        trace,selected,ids=select_gp_zero(library,get,71,budget=6)
        self.assertEqual(len(trace),6);self.assertEqual(len(seen),7);self.assertEqual(seen,ids)

    def test_completed_turn_returned_without_waiting_for_cli_shutdown(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            executable=root/"codex"
            events=[dict(type="item.completed",item=dict(type="agent_message",text='{"ok":true}')),
                    dict(type="turn.completed",usage=dict(input_tokens=3,output_tokens=4))]
            executable.write_text("#!/usr/bin/python3\nimport sys,time\nsys.stdin.read()\n"+
                                  "print("+repr("\n".join(json.dumps(x) for x in events))+",flush=True)\ntime.sleep(60)\n")
            executable.chmod(0o755)
            start=time.monotonic()
            with patch("extensions.recipe_search_compact_20261110.text_transport.shutil.which",return_value=str(executable)):
                result=generate([dict(role="user",content="fixture")],root/"call")
            self.assertLess(time.monotonic()-start,5)
            self.assertTrue(result["turn_completed"])
            self.assertTrue(result["terminated_after_completed_turn"])
            self.assertEqual(result["usage"][0]["output_tokens"],4)
            self.assertEqual(json.loads(result["raw_response"]),dict(ok=True))


if __name__=="__main__":
    unittest.main()
