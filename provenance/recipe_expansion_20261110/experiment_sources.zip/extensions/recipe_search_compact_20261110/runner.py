"""New scientific controller run after a lossless engineering repair; no new fits."""
import argparse
from datetime import datetime,timezone
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from extensions.recipe_expansion_20261110_v2.common import OUT as CACHE,checked,dump,read,sha
SEARCH=ROOT/"results/recipe_expansion_20261110/search_compact_v1"


def sources():
    paths=list(Path(__file__).parent.glob("*.py"))
    return {str(path):sha(path) for path in paths}


def register():
    protocol=checked(CACHE)
    if (SEARCH/"protocol.json").exists():
        return verify()
    if (CACHE/"evaluation/authorization.json").exists():
        raise ValueError("Register before final test authorization")
    value=dict(schema="expanded-recipes-complete-table-search-v1",registered_utc=datetime.now(timezone.utc).isoformat(),
        cache_protocol_sha256=sha(CACHE/"protocol.json"),source_sha256=sources(),tasks=protocol["tasks"],
        seeds=protocol["seeds"],menu=protocol["candidates"],models=["qwen","luna"],
        model_identifiers=dict(qwen="Qwen2.5-7B-Instruct",luna="gpt-5.6-luna"),
        primary="Luna structured minus exact random, all three registered seeds; Qwen and every control also retained",
        reason="The earlier Qwen run exceeded 28000 input tokens in a late full-panel trajectory; the original Luna CLI waited for plugin startup/shutdown. Both remain engineering records, not scientific replications",
        packet="Losslessly encode repeated panel dictionaries as labelled numeric tables; unpack(packet)==original card is checked for every request; no metric rounding or dropped history",
        common_instruction="Compare recipe values, not numeric ID order; explore another region after non-improving trials",
        slots=6,arms=["direct","raw","structured"],shared_first=True,max_attempts_per_slot=2,
        qwen=dict(max_input_tokens=28000,max_new_tokens=512,seed_supported=True,max_calls_all_six=192),
        luna=dict(reasoning_effort="low",generation_seed_supported=False,output_token_cap_enforced=False,
            text_only=True,completed_turn_with_usage_required=True,disable_apps=True),
        controls=["fixed_D00","exact_random","gp_ei_xi_.01","gp_ei_xi_zero","random_shared_first","random_realized_fit_count"],
        extra_gp="Zero-offset EI is an additional strong conventional-search control at the same six-request budget; original xi=.01 GP retained",
        physical_new_training_fits=0,reused_candidate_fits=216,
        old_tests_previously_exposed=True,test_access_before_registration=False,
        final_evaluation_gate="All twelve task/seed/model seals before one retrospective held-out evaluation",
        full_fact_history_equality=True)
    dump(SEARCH/"protocol.json",value,frozen=True)
    return protocol


def verify():
    protocol=checked(CACHE)
    value=read(SEARCH/"protocol.json")
    if value["source_sha256"]!=sources() or value["cache_protocol_sha256"]!=sha(CACHE/"protocol.json"):
        raise ValueError("Frozen search implementation differs")
    return protocol


def verify_seals():
    protocol=verify()
    seals={}
    for model in ("qwen","luna"):
        for task in protocol["tasks"]:
            for seed in protocol["seeds"]:
                folder=SEARCH/model/task/f"seed{seed}"
                seal=read(folder/"selection_seal.json")
                if seal["protocol_sha256"]!=sha(SEARCH/"protocol.json") or seal["heldout_evaluation_read"] is not False:
                    raise ValueError("Invalid completed-table search seal")
                if seal["grid_sha256"]!=sha(CACHE/task/f"seed{seed}/development_grid.json"):
                    raise ValueError("Sealed candidate grid changed")
                for path,digest in seal["transcript_sha256"].items():
                    if sha(path)!=digest:
                        raise ValueError("Search transcript changed")
                seals[f"{model}/{task}/{seed}"]=sha(folder/"selection_seal.json")
    return seals


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=("register","run","verify"))
    parser.add_argument("--model",choices=("qwen","luna"))
    parser.add_argument("--seed",type=int)
    args=parser.parse_args()
    if args.command=="register":
        register();print("COMPACT_SEARCH_REGISTERED",sha(SEARCH/"protocol.json"))
    elif args.command=="verify":
        print(verify_seals())
    else:
        protocol=verify()
        from extensions.recipe_search_compact_20261110.trajectory import run_one
        if args.model=="qwen":
            from extensions.history_repair_20261109.backend_v3 import LocalQwenBackend
            from extensions.heterolab_feedback_20261019.runner import verify_model_binding
            verify_model_binding(read(CACHE/"search/model_binding.json"))
            backend=LocalQwenBackend(SEARCH/"qwen/backend",device="cuda:4",max_calls=192)
            for task in protocol["tasks"]:
                for seed in protocol["seeds"]:
                    run_one(SEARCH,"qwen",task,seed,backend)
        elif args.model=="luna" and args.seed in protocol["seeds"]:
            from extensions.recipe_search_compact_20261110.luna_backend import LunaBackend
            for task in protocol["tasks"]:
                backend=LunaBackend(SEARCH/"luna/backend"/task/f"seed{args.seed}")
                run_one(SEARCH,"luna",task,args.seed,backend)
        else:
            parser.error("--model required; Luna also requires --seed")


if __name__=="__main__":
    main()
