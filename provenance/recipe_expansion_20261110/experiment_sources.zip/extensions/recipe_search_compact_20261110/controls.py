"""Additional GP-EI control with zero exploration offset on small score scales."""
import math
import random
from extensions.history_repair_20261109.controls import (
    _validate_ids, menu_features, score_key, BASELINE, GP_SETTINGS as PARENT_SETTINGS)
GP_SETTINGS=dict(PARENT_SETTINGS,xi=0.)

def _expected_improvement_zero(menu, observed, seed):
    import numpy as np
    from scipy.special import ndtr
    from sklearn.gaussian_process import GaussianProcessRegressor
    from sklearn.gaussian_process.kernels import Matern
    (ids, feature_rows, encoding) = menu_features(menu)
    features = dict(zip(ids, feature_rows))
    available = sorted(set(menu) - set(observed))
    observed_ids = list(observed)
    x = np.asarray([features[key] for key in observed_ids], dtype=np.float64)
    y = np.asarray([score_key(observed[key])[0] for key in observed_ids], dtype=np.float64)
    gp = GaussianProcessRegressor(kernel=Matern(length_scale=np.ones(x.shape[1]), length_scale_bounds='fixed', nu=2.5), alpha=1e-06, normalize_y=True, optimizer=None, random_state=seed)
    gp.fit(x, y)
    (mean, std) = gp.predict(np.asarray([features[key] for key in available]), return_std=True)
    if not np.isfinite(mean).all() or not np.isfinite(std).all() or np.any(std < 0):
        raise ValueError('GP returned nonfinite predictions or invalid uncertainty')
    improvement = mean - float(y.max()) - 0.0
    safe_std = np.maximum(std, 1e-12)
    z = improvement / safe_std
    ei = improvement * ndtr(z) + safe_std * np.exp(-0.5 * z ** 2) / math.sqrt(2 * math.pi)
    ei[std < 1e-12] = np.maximum(improvement[std < 1e-12], 0)
    ei = np.maximum(ei, 0.0)
    if not np.isfinite(ei).all():
        raise ValueError('GP returned nonfinite acquisition values')
    selected = available[int(np.argmax(ei))]
    return (selected, dict(rule='GP expected improvement', observed_ids=observed_ids, acquisition=dict(zip(available, map(float, ei))), feature_encoding=encoding, settings=dict(GP_SETTINGS)))

def select_gp_zero(menu, get_record, seed, budget=6, first=None):
    """Return (trace, selected_id, queried_ids); IDs include the shared D00.

    Two seeded random warm starts count toward the non-baseline budget, followed
    by GP-EI. A fixed first candidate replaces warm-start #1, not an extra query.
    get_record is called exactly once per queried ID; unqueried records are never
    inspected. Incumbent selection uses primary, -loss, then earliest observation.
    Failed/nonfinite callbacks abort rather than fabricate scores or fill a slot.
    """
    _validate_ids(menu, budget, first)
    menu_features(menu)
    if type(seed) is not int or seed < 0 or seed >= 2 ** 32:
        raise ValueError('GP seed must be a nonnegative 32-bit integer')
    if not callable(get_record):
        raise ValueError('get_record must be a callable queried-result interface')
    rng = random.Random(seed)
    available = sorted(set(menu) - {BASELINE})
    if first is None:
        warm = rng.sample(available, min(2, budget))
    else:
        warm = [first] + rng.sample([key for key in available if key != first], min(1, budget - 1))
    observed = {}

    def observe(key):
        record = get_record(key)
        score = score_key(record)
        if record.get('design_id', key) != key:
            raise ValueError('Requested design ID differs from returned evidence')
        if 'config' in record and record['config'] != menu[key]:
            raise ValueError('Returned evidence configuration differs from registered menu')
        observed[key] = dict(development=dict(primary=score[0], loss=-score[1]))
    observe(BASELINE)
    selected = BASELINE
    trace = []
    for slot in range(1, budget + 1):
        if slot <= len(warm):
            chosen = warm[slot - 1]
            acquisition = dict(rule='fixed shared first' if first is not None and slot == 1 else 'seeded random warm start', observed_ids=list(observed))
        else:
            (chosen, acquisition) = _expected_improvement_zero(menu, observed, seed)
        observe(chosen)
        if score_key(observed[chosen]) > score_key(observed[selected]):
            selected = chosen
        trace.append(dict(slot=slot, design_id=chosen, acquisition=acquisition, development=dict(observed[chosen]['development']), selected=selected, incumbent_development=dict(observed[selected]['development'])))
    return (trace, selected, list(observed))

