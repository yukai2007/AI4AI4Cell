"""Registered recipe expansion on two unmet tasks; previous studies are frozen."""
from datetime import datetime, timezone
import hashlib
from itertools import product
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "results/recipe_expansion_20261110/v1"
TASKS = ("dti", "protein")
SEEDS = (71, 72, 73)
ROUNDS = 20
SLOTS = 6
EVALUATIONS = (2, 5, 10, 20)
BATCHES = {"dti": 256, "protein": 64}
BASE_SELECTIONS = {
    "dti": ROOT / "results/luna_main_20260925/core_three_seed_v2/native_tapb/seed42/development/selected_development.json",
    "protein": ROOT / "results/luna_main_20260925/core_three_seed_v1/ptpc_neural/seed42/development/selected_development.json",
}
DATA = {"dti": ROOT / "results/unified_bio_20260918/native_tapb/data",
        "protein": ROOT / "results/unified_bio_20260918/ptpc_neural/data"}


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def dump(path, value, *, frozen=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
    if frozen:
        try:
            with path.open("x") as stream:
                stream.write(raw)
        except FileExistsError:
            if read(path) != value:
                raise ValueError("Frozen artifact differs: " + str(path))
    else:
        temp = path.with_name(path.name + f".tmp-{os.getpid()}")
        temp.write_text(raw)
        os.replace(temp, path)


def menu():
    base = dict(lr=1e-4, head="full", objective="bce", schedule="constant")
    values = [base]
    for lr, head, objective, schedule in product(
            (1e-5, 1e-4, 1e-3), ("full", "residual32", "residual128"),
            ("bce", "bce_rank"), ("constant", "cosine")):
        config = dict(lr=lr, head=head, objective=objective, schedule=schedule)
        if config != base:
            values.append(config)
    assert len(values) == 36
    return {f"D{i:02d}": config for i, config in enumerate(values)}


def sources():
    paths = list(Path(__file__).parent.glob("*.py"))
    paths += [ROOT / "extensions/history_repair_20261109" / name for name in
              ("backend.py", "backend_v3.py", "controls.py", "evidence_cards.py", "search_v3.py")]
    paths += [ROOT / "extensions/unified_bio_20260918" / name for name in
              ("tapb_native_adapter.py", "ptpc_neural_adapter.py", "core.py", "heldout_native_tapb.py",
               "heldout_ptpc_neural.py", "prepare_ptpc_neural.py")]
    paths += [ROOT / "extensions/proteomics/ptpc_model.py", ROOT / "extensions/proteomics/scoring.py"]
    return {str(path): sha(path) for path in sorted(paths)}


def register(out=OUT):
    path = out / "protocol.json"
    if path.exists():
        return checked(out)
    bases = {}
    for task in TASKS:
        record = read(BASE_SELECTIONS[task])["federated_fixed"]
        if record["config"]["residual"] or record["seed"] != 42:
            raise ValueError("Use the common original default backbone, not a test-selected winner")
        bases[task] = dict(selection_path=str(BASE_SELECTIONS[task]), selection_sha256=sha(BASE_SELECTIONS[task]),
            checkpoint=record["checkpoint"], checkpoint_sha256=sha(record["checkpoint"]),
            original_fit_sha256=sha(Path(record["checkpoint"]).parent / "fit.json"),
            data_manifest_sha256=sha(DATA[task] / "manifest.json"),
            historical_training_rounds=100, historical_training_seconds=record["training_seconds"],
            clients=record["clients"], original_selected_round=record["best"]["round"])
    protocol = dict(schema="expanded-frozen-representation-recipes-v1", registered_utc=datetime.now(timezone.utc).isoformat(),
        tasks=list(TASKS), seeds=list(SEEDS), candidates=menu(), base_bindings=bases, source_sha256=sources(),
        purpose="Improve DTI and proteomic model development relative to equal-access, equal-budget random search; cell already has positive matched point estimates",
        design_scope="New exploratory warm-start study, not replacement scores for the original end-to-end TAPB/ProteinTalks comparison",
        access="Every method shares all ten original training labs, prepared representations, development rows and candidate menu",
        representation="Freeze the seed42 fixed-default task-trained backbone for all policies and all new head-training seeds; this upstream fit previously used the original development population",
        costs="Shared historical backbone fitting and new feature extraction reported separately from each search; head-training seeds are conditional on one common backbone, not independent end-to-end seeds",
        rounds=ROUNDS, batch_size=BATCHES, local_epochs_per_round=1, evaluation_rounds=list(EVALUATIONS),
        optimizer="AdamW reset per local round; weight_decay=.001, clip_grad_norm=1; example-weighted parameter averaging; momentum=0",
        head="full: refit the original classifier; residual32/128: freeze it, add LayerNorm/Linear/GELU/zero-output Linear correction",
        objective="BCE; or BCE plus .1 mean softplus(negative logit - positive logit) within each local batch; absent local class means rank term zero",
        schedule="constant or cosine across 20 rounds with .1 base-LR floor; same complete fit budget",
        primary=dict(dti="pooled original development AUROC", protein="pooled original development AP"),
        selection="maximize primary then lower pooled BCE; exact ties keep earlier checkpoint/candidate; never use test scores",
        panel_diagnostics="all ten labelled development panels retained; one-class AP/AUROC explicitly unavailable",
        proposals=dict(arms=["direct", "raw", "structured"], slots=SLOTS, common_first=True,
            attempts_per_slot=2, invalid_consumes_slot=True, model="Qwen2.5-7B-Instruct",
            temperature=.7, top_p=.9, max_new_tokens=512, max_input_tokens=28000),
        controls=["fixed_D00", "exact_random_without_replacement", "GP_EI", "random_shared_first", "random_realized_fit_count"],
        logical_search_round_cap=(SLOTS+1)*ROUNDS, optional_positive_acceptance="structured mean score greater than random on each task; all results retained regardless of sign",
        old_tests_previously_exposed=True, test_role="Single final retrospective evaluation after all six task/seed selections are sealed; not a new blind or grouped-split confirmation",
        no_test_feedback_to_proposer=True, no_rerun_selected_seeds=True,
        planned_new_fits=len(TASKS)*len(SEEDS)*len(menu()))
    dump(path, protocol, frozen=True)
    return protocol


def checked(out=OUT):
    protocol = read(out / "protocol.json")
    if protocol["source_sha256"] != sources():
        raise ValueError("Registered implementation changed; preserve the run and use a new version")
    for task, binding in protocol["base_bindings"].items():
        if sha(binding["checkpoint"]) != binding["checkpoint_sha256"] or sha(DATA[task] / "manifest.json") != binding["data_manifest_sha256"]:
            raise ValueError("Common encoder or data manifest changed")
    return protocol
