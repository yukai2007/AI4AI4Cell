"""Fresh, complete, equal-budget federated head fits; development access only."""
import argparse
from copy import deepcopy
import math
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import numpy as np
import torch
from torch.nn import functional as F
from sklearn.metrics import average_precision_score, roc_auc_score

from extensions.recipe_expansion_20261110.common import OUT, checked, dump, read, sha
from extensions.recipe_expansion_20261110.models import Classifier, objective, state


def metrics(y, probability, task):
    probability = np.asarray(probability, np.float64)
    y = np.asarray(y, np.float64)
    if not np.isfinite(probability).all() or not np.isin(y,[0,1]).all():
        raise ValueError("Invalid binary score")
    clipped=np.clip(probability,1e-7,1-1e-7)
    bce=float(-np.mean(y*np.log(clipped)+(1-y)*np.log1p(-clipped)))
    if len(np.unique(y)) != 2:
        return dict(primary=None, loss=bce, status="ONE_CLASS_UNAVAILABLE", rows=len(y), positives=int(y.sum()))
    return dict(primary=float(roc_auc_score(y,probability) if task=="dti" else average_precision_score(y,probability)),
                loss=bce, rows=len(y), positives=int(y.sum()))


class Trainer:
    def __init__(self,out,task,device):
        self.out,self.task,self.device=Path(out),task,device
        self.protocol=checked(out)
        path=out/task/"features"
        self.receipt=read(path/"receipt.json")
        for filename,digest in self.receipt["artifacts"].items():
            if sha(filename)!=digest:
                raise ValueError("Prepared feature cache changed")
        self.train,self.dev=[dict(np.load(path/f"{role}.npz",allow_pickle=False)) for role in ("train","dev")]
        self.x=torch.as_tensor(self.train["x"],device=device)
        self.y=torch.as_tensor(self.train["y"],device=device)
        self.dx=torch.as_tensor(self.dev["x"],device=device)
        self.initial=torch.load(path/"initial_head.pt",map_location="cpu",weights_only=True)
        self.clients={client:np.flatnonzero(self.train["client"]==client) for client in range(10)}
        self.batch=self.protocol["batch_size"][task]

    @torch.inference_mode()
    def evaluate(self,model):
        model.eval()
        prediction=torch.cat([model(x).sigmoid() for x in self.dx.split(1024)]).cpu().numpy()
        result=metrics(self.dev["y"],prediction,self.task)
        panels={}
        for client in range(10):
            ids=self.dev["client"]==client
            panels[f"target:{client}"]=metrics(self.dev["y"][ids],prediction[ids],self.task)
        result["per_context"]={key:{k:value[k] for k in ("primary","loss")} for key,value in panels.items()
                               if value["primary"] is not None}
        result["panels"]=panels
        result["aggregation"]="pooled development rows; panels are diagnostics"
        return result

    def fit(self,identifier,seed):
        folder=self.out/self.task/f"fits/seed{seed}"/identifier
        if (folder/"summary.json").exists():
            record=read(folder/"summary.json")
            if record["protocol_sha256"]!=sha(self.out/"protocol.json") or sha(record["checkpoint"])!=record["checkpoint_sha256"]:
                raise ValueError("Completed fit binding differs")
            return record
        if folder.exists():
            raise ValueError("Partial fit preserved: "+str(folder))
        folder.mkdir(parents=True)
        config=self.protocol["candidates"][identifier]
        model=Classifier(self.task,self.initial,config,seed).to(self.device)
        parameters=[p for p in model.parameters() if p.requires_grad]
        shared=state(model)
        baseline=self.evaluate(model)
        best,best_round,best_key=None,None,None
        trajectory=[]
        total_steps,total_examples=0,0
        started=time.monotonic()
        for rnd in range(1,self.protocol["rounds"]+1):
            accumulated={key:torch.zeros_like(value,dtype=torch.float64) for key,value in shared.items()}
            weighted_loss=0.
            lr=config["lr"]
            if config["schedule"]=="cosine":
                lr*=.1+.9*(1+math.cos(math.pi*(rnd-1)/(self.protocol["rounds"]-1)))/2
            for client,ids in self.clients.items():
                model.load_state_dict(shared,strict=True)
                model.train()
                optimizer=torch.optim.AdamW(parameters,lr=lr,weight_decay=.001)
                order=np.random.default_rng(seed+rnd*100+client).permutation(ids)
                for begin in range(0,len(order),self.batch):
                    batch=order[begin:begin+self.batch]
                    loss=objective(model(self.x[batch]),self.y[batch],config["objective"])
                    if not torch.isfinite(loss):
                        raise FloatingPointError("Nonfinite registered fit; preserve its progress and charge the attempted design")
                    optimizer.zero_grad(set_to_none=True)
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(parameters,1.)
                    optimizer.step()
                    weighted_loss+=float(loss.detach())*len(batch)
                    total_steps+=1
                    total_examples+=len(batch)
                weight=len(ids)/len(self.train["y"])
                for key,value in model.state_dict().items():
                    accumulated[key].add_(value,alpha=weight)
            shared={key:value.to(shared[key].dtype) for key,value in accumulated.items()}
            model.load_state_dict(shared,strict=True)
            row=dict(round=rnd,lr=lr,train_loss=weighted_loss/len(self.train["y"]))
            if rnd in self.protocol["evaluation_rounds"]:
                row["development"]=self.evaluate(model)
                key=(row["development"]["primary"],-row["development"]["loss"])
                if best_key is None or key>best_key:
                    best_key,best,best_round=key,deepcopy(row["development"]),rnd
                    torch.save({k:v.cpu() for k,v in shared.items()},folder/"best.pt")
            trajectory.append(row)
            dump(folder/"progress.json",dict(round=rnd,seconds=time.monotonic()-started,
                best_development=best,actual_optimizer_steps=total_steps))
        expected_steps=self.protocol["rounds"]*sum(math.ceil(len(ids)/self.batch) for ids in self.clients.values())
        if total_steps!=expected_steps or total_examples!=self.protocol["rounds"]*len(self.train["y"]):
            raise ValueError("Fit did not complete its identical step/exposure budget")
        record=dict(status="COMPLETE",task=self.task,design_id=identifier,config=config,seed=seed,
            development=best,best_round=best_round,trajectory=trajectory,initial_development=baseline,
            checkpoint=str(folder/"best.pt"),checkpoint_sha256=sha(folder/"best.pt"),
            rounds=self.protocol["rounds"],actual_optimizer_steps=total_steps,actual_examples_seen=total_examples,
            trainable_parameters=sum(p.numel() for p in parameters),seconds=time.monotonic()-started,
            feature_receipt_sha256=sha(self.out/self.task/"features/receipt.json"),protocol_sha256=sha(self.out/"protocol.json"),
            feature_extraction_cost_shared=True,test_read=False,device=self.device)
        dump(folder/"summary.json",record,frozen=True)
        print(self.task,seed,identifier,f"dev={best['primary']:.6f}",f"seconds={record['seconds']:.1f}",flush=True)
        return record


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--out",type=Path,default=OUT)
    parser.add_argument("--task",choices=("dti","protein"),required=True)
    parser.add_argument("--device",default="cuda:6")
    parser.add_argument("--seeds",nargs="+",type=int,default=[71,72,73])
    parser.add_argument("--designs",nargs="+")
    args=parser.parse_args()
    torch.set_num_threads(2)
    torch.backends.cuda.matmul.allow_tf32=False
    trainer=Trainer(args.out,args.task,args.device)
    if not set(args.seeds)<=set(trainer.protocol["seeds"]):
        raise ValueError("Unregistered seed")
    identifiers=args.designs or list(trainer.protocol["candidates"])
    if not set(identifiers)<=set(trainer.protocol["candidates"]):
        raise ValueError("Unregistered design")
    for seed in args.seeds:
        for identifier in identifiers:
            trainer.fit(identifier,seed)
        if set(identifiers)==set(trainer.protocol["candidates"]):
            records={identifier:read(args.out/args.task/f"fits/seed{seed}"/identifier/"summary.json")
                     for identifier in identifiers}
            dump(args.out/args.task/f"seed{seed}/development_grid.json",records,frozen=True)


if __name__=="__main__":
    main()
