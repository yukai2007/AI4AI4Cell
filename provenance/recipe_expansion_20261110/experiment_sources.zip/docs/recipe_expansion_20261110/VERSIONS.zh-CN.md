# 本次配方扩展的版本和成本边界

日期：2026-11-10（Asia/Shanghai）。用户授权增加配方自由度，并明确比较同访问、同预算随机搜索。

## v1：开发期容量pilot，保留原样

目录：`results/recipe_expansion_20261110/v1`；源码：`extensions/recipe_expansion_20261110`。

- 先冻结36配方、seeds71–73与相同完整训练预算。
- 提取原seed42固定D00的DTI per-confounder表征和蛋白组64维融合表征；新分类器复现原输出的最大绝对误差为DTI 1.79e−7、蛋白开发集0。
- 完成蛋白108个预测头fit、DTI D00/D16的两个完整20轮计算canary，共110次新fit。
- 蛋白组开发AP范围约42.14–42.30%，表明只在旧64维表征上增加分类头自由度仍较受限。
- **没有LLM科学提案调用，没有本轮新测试推理。** 该版本停留在开发期容量诊断；不把原计划216次全部记作完成，也不产生history优越性结论。

## v2：从原始蛋白输入扩展，正式对照

目录：`results/recipe_expansion_20261110/v2`；源码：`extensions/recipe_expansion_20261110_v2`。

调整发生在任何本轮LLM提案或测试评分之前，仅依据v1的开发侧容量诊断。v1未删除、未重写。

- DTI继续使用相同固定D00编码器及8×32维per-confounder表征，直接核验并复用v1特征，避免重复完整TAPB前向。其原特征构造成本仍记录为共同成本。
- 蛋白组使用原始已规范化的12,390维输入（6h/24h实测蛋白响应及Morgan指纹）。full配方更新完整原Conv1d/MLP预测头；residual32/128冻结原预测头并从完整输入学习零输出初始化的残差分支。
- 其余36配方因子、三seed、20轮、四个开发checkpoint、6提案槽、Direct/Raw/Structured及Random/GP对照保持一致。新的协议哈希为 `de7e1d4e18a910dbb19ec04b3fe475228db469a4bfc082df5581014bd08bf66a`。
- 计划216个完整fit，全部保留。最终完成数按summary/grid计数，不能用计划数替代完成数。v1的110次fit是另加的开发期成本。
- 新seed是head训练/研究seed，条件于一个共同的旧seed42起点；不叫三次独立端到端backbone重复。
- Raw/Structured均保留所有已查询候选的逐panel开发轨迹，Direct无结果分数；首提案真实共享。最多2次生成/槽，失败占槽。
- Qwen权重、配置和tokenizer共12项文件在真实调用前逐项核验，绑定到 `v2/search/model_binding.json`。

## 最终评分和分析

`paper/tools/report_recipe_expansion.py` 在测试授权前另行冻结配对2000次bootstrap方案；DTI使用测试行，蛋白使用compound cluster。区间条件于这些固定拟合/所选预测器，不代表新训练/控制器运行的不确定性。

所有2任务×3seed搜索seal完整、日志/源码/输入哈希通过且/root授权后，才统一生成本轮历史测试分数。既有测试早已暴露，称为回顾性新配方研究；不能称新盲测或新的生物grouped split。

本轮完整主对照是Structured−Random；Fixed、Direct、Raw、GP、共同首槽和有效fit数匹配的随机敏感性都报告。不能在测试后选择表现更好的arm、seed或版本来冒充预先指定的history胜出。

## 搜索工程修复：与训练版本分开

v2的216/216次新训练已经完成，无需因下面的控制器修复重训。

- `v2/search` 中原Qwen搜索：DTI seed71/72封存完成，seed73的Structured后期槽完整输入达到31,472 token，超过已声明的28,000上限，程序拒绝截断并中断。保留为工程轨迹，不把两个完成seed作为选择性科学结果；蛋白搜索未启动。
- `luna_v1`：原CLI transport在模型/Apps启动及退出管理上反复超时，已停止该轮自己的进程和子进程，保留调用记录。没有本轮测试访问。
- 文本通道最小探针确实得到`turn.completed`、真实回复及usage；修复后的通道禁用非必要Apps，并在读到完整turn后结束该调用的后台进程。记录实际进程退出码和cleanup标记，绝不把退出码改写为成功或伪造completion。
- `search_compact_v1`：新的Qwen/Luna配对科学搜索。所有模式共同使用可逆panel表编码；每个请求都检查`unpack(packet)==original_card`。原触限输入可降为约23,469 token，数值不舍入、panel标签和四个开发评估点均保留，无历史截断。每个已请求候选在round2/5/10/20的panel primary/loss及这些评估点的train loss都保留；不声称向提案器发送全部20轮非评估点的训练损失。
- 同时增加`ξ=0`的GP-EI强控制，应对小分数变化尺度；原`ξ=.01` GP保留。两个GP仍各6个候选槽。Primary预先指定为Luna Structured−Random，Qwen及全部控制完整报告。
- 新搜索协议哈希：`f7ce4d69b0a2e06231f24258675fac2ddfc532810d26863a54861522ef8642c7`；合并分析注册哈希：`b32846ab0fa3245519787cc0150cec9378d6ee574b2cb9d640fe4d424893efc4`。均在本轮测试授权前生成。
- 最终测试入口改为单独版本`extensions/recipe_expansion_eval_20261110/evaluate.py`，要求两模型×两任务×三seed的全部12个seal，不伪造或补写旧工程搜索缺失的seal。

未完成的工程轨迹、修复后科学搜索、模型训练缓存和最终评分分别保留。工程重试不是新的独立生物学重复，额外调用成本另计。
