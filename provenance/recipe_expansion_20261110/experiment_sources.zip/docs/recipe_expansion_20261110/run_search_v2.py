"""Infrastructure driver: wait for each complete grid, then call frozen search."""
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from extensions.recipe_expansion_20261110_v2.common import OUT,checked,read,dump,sha
from extensions.recipe_expansion_20261110_v2.search import run_one,LocalQwenBackend
from extensions.heterolab_feedback_20261019.runner import verify_model_binding

protocol=checked(OUT)
verify_model_binding(read(OUT/"search/model_binding.json"))
dump(OUT/"search/execution_driver.json",dict(driver_path=str(Path(__file__).resolve()),
    driver_sha256=sha(__file__),protocol_sha256=sha(OUT/"protocol.json"),
    model_binding_sha256=sha(OUT/"search/model_binding.json"),
    order=[dict(task=task,seed=seed) for task in protocol["tasks"] for seed in protocol["seeds"]],
    semantics="Only infrastructure waits; scientific choices use the unchanged source-bound run_one"),frozen=True)
backend=LocalQwenBackend(OUT/"search/backend",device="cuda:4",max_calls=192)
for task in protocol["tasks"]:
    for seed in protocol["seeds"]:
        path=OUT/task/f"seed{seed}/development_grid.json"
        while not path.exists():
            print("WAITING_FOR_COMPLETE_GRID",task,seed,flush=True)
            time.sleep(10)
        run_one(OUT,task,seed,backend)
dump(OUT/"search/execution_receipt.json",dict(status="COMPLETE",physical_calls=backend.calls,
    requests=backend.requests,protocol_sha256=sha(OUT/"protocol.json"),driver_sha256=sha(__file__)),frozen=True)
print("ALL_SIX_SEARCHES_SEALED",backend.calls,flush=True)
