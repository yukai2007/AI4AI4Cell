#!/usr/bin/env bash
# One direction: LLM-free controls, 6 Qwen runs (one GPU each), 6 Luna runs (3 at a time), then seal.
set -euo pipefail
DIRECTION=$1
cd /liziqing/yukai/AI4AI4Cell
PY=/opt/conda/envs/LDA/bin/python
OUTDIR=results/split_panel_confirmation_20261110/v1
LOG=$OUTDIR/logs/search_$DIRECTION
mkdir -p "$LOG"
M="-m extensions.split_panel_confirmation_20261110.search"
$PY -m extensions.split_panel_confirmation_20261110.protocol 2 --out "$OUTDIR"
jobs=()
for task in cell protein; do for seed in 61 62 63; do jobs+=("$task $seed"); done; done
for job in "${jobs[@]}"; do set -- $job
  $PY $M controls --direction $DIRECTION --task $1 --seed $2 --out $OUTDIR > $LOG/controls_$1_$2.log 2>&1
done
i=0
for job in "${jobs[@]}"; do set -- $job
  $PY $M llm --direction $DIRECTION --task $1 --seed $2 --proposer qwen --device cuda:$i --out $OUTDIR > $LOG/qwen_$1_$2.log 2>&1 &
  i=$((i+1))
done
printf '%s\n' "${jobs[@]}" | xargs -P 3 -L 1 bash -c '$0 '"$M"' llm --direction '"$DIRECTION"' --task $1 --seed $2 --proposer luna --out '"$OUTDIR"' > '"$LOG"'/luna_$1_$2.log 2>&1 || echo LUNA_FAILED $1 $2' "$PY"
wait
$PY $M seal --direction $DIRECTION --out $OUTDIR
echo DONE $DIRECTION
