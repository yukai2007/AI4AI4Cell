"""Split-panel confirmation (SPC): shared constants and guarded panel access.

The original ten target-development panels are split into two fixed halves.
In direction AB every checkpoint round and every candidate is chosen on half A
only; half B is opened only after that direction is sealed. Direction BA is
the mirror image. Training never depends on either half.
"""
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from extensions.supplement_history_20261007.task_runner import (  # noqa: E402
    CLIENTS, SEEDS, TASKS, dump, freeze_json, read, sha)
from extensions.budget1day_20260923.contract import DESIGNS  # noqa: E402

HERE = Path(__file__).resolve().parent
OUT = ROOT / 'results/split_panel_confirmation_20261110/v1'
OLD = ROOT / 'results/supplement_history_20261007'
ROUNDS = 100
EVAL_ROUNDS = list(range(5, ROUNDS + 1, 5))
HALVES = dict(A=[f'target:{i}' for i in (0, 2, 4, 6, 8)],
              B=[f'target:{i}' for i in (1, 3, 5, 7, 9)])
# direction -> (selection half, confirmation half)
DIRECTIONS = dict(AB=('A', 'B'), BA=('B', 'A'))
PROPOSERS = ('qwen', 'luna')
LLM_ARMS = ('direct', 'raw', 'structured')
BUDGET = 6


def now():
    return datetime.now(timezone.utc).isoformat()


def fit_dir(out, task, seed, design):
    return Path(out) / 'train' / task / f'seed{seed}' / design


def round_checkpoint(out, task, seed, design, rnd):
    return fit_dir(out, task, seed, design) / 'rounds' / f'r{rnd:03d}.pt'


def direction_dir(out, direction):
    return Path(out) / 'directions' / direction


def sealed(out, direction):
    return (direction_dir(out, direction) / 'seal.json').exists()


def panel_file(out, task, seed, design, half, *, direction, purpose):
    """Return a panel-half file only when the direction protocol allows it.

    Selection may read only its own half. The confirmation half may be read
    only after the direction's seal exists. Every access is logged.
    """
    if direction not in DIRECTIONS or half not in HALVES:
        raise ValueError('Unknown direction/half')
    select_half, confirm_half = DIRECTIONS[direction]
    if purpose == 'selection':
        if half != select_half:
            raise PermissionError(f'{direction} selection may not read panel half {half}')
        if sealed(out, direction):
            raise PermissionError(f'{direction} is sealed; selection is closed')
    elif purpose == 'confirmation':
        if half != confirm_half or not sealed(out, direction):
            raise PermissionError(f'Confirmation half {half} is closed until {direction} is sealed')
    else:
        raise ValueError('Unknown purpose')
    path = fit_dir(out, task, seed, design) / f'panels_{half}.json'
    log = direction_dir(out, direction) / 'access_log.jsonl'
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open('a') as stream:
        stream.write(json.dumps(dict(utc=now(), purpose=purpose, half=half, task=task, seed=seed,
                                     design=design, sha256=sha(path))) + '\n')
    return read(path)


def half_summary(points, labels):
    """Equal-panel mean primary/loss over exactly the labelled half."""
    import numpy as np
    values = {r['panel_id']: r['development'] for r in points}
    if sorted(values) != sorted(labels):
        raise ValueError('Panel half labels differ')
    return dict(primary=float(np.mean([values[k]['primary'] for k in labels])),
                loss=float(np.mean([values[k]['loss'] for k in labels])))


def select_round(curve):
    """Highest half-mean primary, then lower loss, then the earlier round."""
    return max(curve, key=lambda r: (r['development']['primary'], -r['development']['loss'], -r['round']))
