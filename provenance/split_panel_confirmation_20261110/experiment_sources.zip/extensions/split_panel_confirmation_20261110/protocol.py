"""Registered SPC protocol. Stage 1 freezes training/selection/scoring before any
fresh fit; stage 2 freezes search sources before any LLM rollout."""
import argparse
import json
from pathlib import Path

from extensions.split_panel_confirmation_20261110.common import (
    BUDGET, CLIENTS, DESIGNS, DIRECTIONS, EVAL_ROUNDS, HALVES, HERE, LLM_ARMS, OUT, PROPOSERS,
    ROUNDS, SEEDS, TASKS, freeze_json, now, read, sha)

STAGE1 = dict(
    schema='biocoloop-split-panel-confirmation-v1',
    question=('Does history feedback choose better candidates than direct, random and GP-EI search when '
              'checkpoint rounds and candidates are chosen on one half of the development panels and '
              'judged on the other half, before any held-out read?'),
    tasks=list(TASKS), clients=CLIENTS, seeds=list(SEEDS), menu=DESIGNS, rounds=ROUNDS,
    eval_rounds=EVAL_ROUNDS, halves=HALVES, directions={k: dict(select=v[0], confirm=v[1]) for k, v in DIRECTIONS.items()},
    primary_direction='AB', order='AB select/search/seal, then BA select/search/seal, then confirmation and held-out scoring',
    training=('72 fresh fits (2 tasks x 3 seeds x 12 designs), frozen panel_feedback loop, checkpoint saved at '
              'every evaluated round; bit-exact equality with the original supplement_history curve, best.pt '
              'round checkpoint and last.pt state/velocity, plus equality with all 720 dev_audit_v1 panel scores'),
    round_selection='per fit: highest selection-half mean primary, then lower mean loss, then earlier round',
    candidate_selection='highest selection-half mean primary of the round-selected checkpoint, then lower loss; exact ties keep the incumbent',
    arms=dict(fixed='D00 at its selection-half round',
              llm=dict(proposers=list(PROPOSERS), modes=list(LLM_ARMS), budget=BUDGET,
                       baseline='D00 outside the budget', shared_first_slot=True,
                       attempts_per_slot=2, invalid_slots_charged=True),
              random=f'exact expectation over all C(11,{BUDGET}) subsets added to D00',
              gp_ei='controls.select_gp, Matern 2.5, alpha 1e-6, xi 0.01, two warm starts, same budget'),
    feedback=('raw and structured receive identical observed facts: selection-half per-panel primary/loss at '
              'the selected round and selection-half mean trajectory; direct receives no outcomes'),
    endpoints=dict(primary='confirmation-half equal-panel mean primary of the sealed selection, direction AB',
                   secondary=['direction BA', 'mean of both directions', 'original held-out test score',
                              'selection-minus-confirmation optimism', 'per-seed paired differences']),
    contrasts=['structured - direct', 'raw - direct', 'structured - random', 'structured - gp_ei',
               'direct - fixed', 'random - fixed'],
    disclosure=('The A/B partition (even/odd panels) and the held-out test set were previously exposed in '
                'descriptive analyses; this is an independent selection protocol on existing panels, not a '
                'new biological split. Held-out test is retrospective.'),
    no_tuning='No step reads confirmation panels or held-out data before the corresponding seal; all seeds/arms reported.',
)


def freeze(stage, out=OUT):
    out = Path(out)
    if stage == 1:
        value = dict(STAGE1, training_sources={str(HERE / n): sha(HERE / n) for n in ('common.py', 'train.py')})
        path = out / 'protocol_stage1.json'
        freeze_json(path, value)
        registration = out / 'registration_stage1.json'
        if not registration.exists():
            freeze_json(registration, dict(protocol_sha256=sha(path), utc=now(), before_fresh_fits=True))
        elif read(registration)['protocol_sha256'] != sha(path):
            raise ValueError('Stage 1 registration differs')
        return value
    names = ('common.py', 'search.py', 'protocol.py')
    value = dict(stage1_sha256=sha(out / 'protocol_stage1.json'),
                 search_sources={str(HERE / n): sha(HERE / n) for n in names},
                 before_llm_rollouts=True)
    path = out / 'protocol_stage2.json'
    freeze_json(path, value)
    if not (out / 'registration_stage2_time.json').exists():
        freeze_json(out / 'registration_stage2_time.json', dict(utc=now(), protocol_sha256=sha(path)))
    return value


def checked(stage, out=OUT):
    out = Path(out)
    if stage == 1:
        value = read(out / 'protocol_stage1.json')
        if read(out / 'registration_stage1.json')['protocol_sha256'] != sha(out / 'protocol_stage1.json'):
            raise ValueError('Stage 1 protocol differs from registration')
        return value
    value = read(out / 'protocol_stage2.json')
    if any(sha(p) != d for p, d in value['search_sources'].items()):
        raise ValueError('Search source changed after stage 2 registration')
    return value


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', type=int, choices=(1, 2))
    parser.add_argument('--out', type=Path, default=OUT)
    args = parser.parse_args()
    freeze(args.stage, args.out)
    print(json.dumps(dict(frozen=args.stage)))
