"""After both directions are sealed: confirmation-half and held-out scoring.

For every direction/seed/design the checkpoint round chosen on the selection
half is scored on the confirmation half (recorded during training, and
re-evaluated from the saved checkpoint as an independent check) and on the
original, historically exposed held-out test set with an independent rescore.
"""
import argparse
import importlib
import json
from pathlib import Path
import time

from extensions.split_panel_confirmation_20261110.common import (
    DESIGNS, DIRECTIONS, HALVES, OUT, SEEDS, TASKS, direction_dir, dump, half_summary,
    panel_file, read, round_checkpoint, sha)
from extensions.supplement_history_20261007.task_runner import (
    SOURCE_PACKAGES, assert_metrics_match, load_task)
from extensions.panel_feedback_20261110.runtime import adapter_class


def require_seals(out):
    seals = {}
    for direction in DIRECTIONS:
        path = direction_dir(out, direction) / 'seal.json'
        if not path.exists():
            raise PermissionError('Both directions must be sealed before confirmation/held-out scoring')
        seal = read(path)
        for name, digest in seal['selections_sha256'].items():
            if sha(name) != digest:
                raise ValueError('Sealed selection changed: ' + name)
        seals[direction] = sha(path)
    return seals


class Scorer:
    def __init__(self, task):
        self.task = task
        self.source = source = load_task(task)
        torch, np = source.torch, source.np
        self.torch, self.np = torch, np
        path = source.OUT / 'data' / ('cross_scenario60_k4' if task == 'cell' else '')
        self.panel_adapter = adapter_class(task, source)(path, 0, 'cpu')
        if task == 'cell':
            with np.load(source.TARGET / 'test/query.npz', allow_pickle=False) as archive:
                self.query = dict(archive)
            self.hidden = np.load(source.TARGET / 'public_hidden.npy', mmap_mode='r')
            self.mask = np.load(source.TARGET / 'scoring_mask.npy')
            self.initial = torch.load(source.TARGET / 'initial_head.pt', map_location='cpu', weights_only=True)
            self.independent = importlib.import_module(SOURCE_PACKAGES['cell'] + '.rescore_v2')
        else:
            query = source.archive(source.QUERY)
            x = source.features(query)
            self.proteins = read(source.OUT / 'data/manifest.json')['n_proteins']
            self.query = query
            self.protein = torch.as_tensor(x[:, :2 * self.proteins].reshape(-1, 2, self.proteins))
            self.qmask = torch.as_tensor(query['observed_mask'])
            self.drug = torch.as_tensor(x[:, 2 * self.proteins:])

    def model(self, config, checkpoint):
        torch = self.torch
        if self.task == 'cell':
            model = self.source.make_head(self.initial, config).to('cpu').eval()
        else:
            model = self.source.MultiStudyPredictor(self.proteins, self.drug.shape[-1], config['residual']).to('cpu').eval()
        self.source.restore(model, torch.load(checkpoint, map_location='cpu', weights_only=False))
        return model

    def panels(self, config, checkpoint):
        """Fresh ten-panel development re-evaluation of a saved checkpoint."""
        self.torch.manual_seed(0)
        model = self.panel_adapter.model(config).eval()
        self.source.restore(model, self.torch.load(checkpoint, map_location='cpu', weights_only=False))
        with self.torch.inference_mode():
            payload = self.panel_adapter.evaluate(model)
        return {r['panel_id']: r['development'] for r in payload['per_panel_development']}

    def heldout(self, config, checkpoint, folder):
        torch, np, source = self.torch, self.np, self.source
        folder.mkdir(parents=True, exist_ok=False)
        model = self.model(config, checkpoint)
        if self.task == 'cell':
            with torch.inference_mode():
                evidence = source.cell_evaluate(model, self.hidden, self.query, self.mask, 'cpu', return_rows=True)
            metrics = source.cell_summary([evidence])
            predictions = folder / 'predictions.json'
            dump(predictions, evidence['rows'])
            measured = self.independent.metrics_from_rows(read(predictions))
            differences = assert_metrics_match(measured, metrics, 1e-10)
            primary = metrics['macro_accuracy']
        else:
            with torch.inference_mode():
                probability = model('target', self.protein, self.qmask, self.drug).sigmoid().cpu().numpy()
            metrics = source.phenotype_scores(self.query['y'], probability)
            predictions = folder / 'predictions.npz'
            np.savez_compressed(predictions, probability=probability,
                                condition_key=self.query['condition_key'], compound_key=self.query['compound_key'])
            with np.load(predictions, allow_pickle=False) as saved:
                measured = source.manual_ranking_scores(self.query['y'], saved['probability'])
            differences = assert_metrics_match(measured, metrics, 1e-12)
            primary = metrics['ap']
        value = dict(primary=primary, metrics=metrics, independent_metrics=measured,
                     absolute_differences=differences, predictions_sha256=sha(predictions),
                     checkpoint_sha256=sha(checkpoint))
        dump(folder / 'results.json', value)
        return value


def score_task(task, out=OUT):
    out = Path(out)
    seals = require_seals(out)
    target = out / 'scores' / f'{task}.json'
    if target.exists():
        return read(target)
    scorer = Scorer(task)
    started = time.monotonic()
    heldout_cache, recheck_failures, rows = {}, [], {}
    for direction, (select_half, confirm_half) in DIRECTIONS.items():
        for seed in SEEDS:
            base = direction_dir(out, direction) / task / f'seed{seed}'
            controls = read(base / 'controls' / 'controls.json')
            per_design = {}
            for design, rnd in controls['selected_rounds'].items():
                confirm = panel_file(out, task, seed, design, confirm_half, direction=direction, purpose='confirmation')
                point = next(p for p in confirm['points'] if p['round'] == rnd)
                checkpoint = round_checkpoint(out, task, seed, design, rnd)
                fresh = scorer.panels(DESIGNS[design], checkpoint)
                recorded = {r['panel_id']: r['development'] for r in point['per_panel_development']}
                if any(fresh[k] != v for k, v in recorded.items()):
                    recheck_failures.append(dict(direction=direction, seed=seed, design=design, round=rnd))
                fresh_selection = half_summary([dict(panel_id=k, development=fresh[k]) for k in HALVES[select_half]],
                                               HALVES[select_half])
                if fresh_selection != controls['selection_development'][design]:
                    recheck_failures.append(dict(direction=direction, seed=seed, design=design, round=rnd, half='selection'))
                cache_key = (seed, design, rnd)
                if cache_key not in heldout_cache:
                    heldout_cache[cache_key] = scorer.heldout(
                        DESIGNS[design], checkpoint, out / 'scores' / task / f'seed{seed}' / f'{design}_r{rnd:03d}')
                per_design[design] = dict(round=rnd, selection=controls['selection_development'][design],
                                          confirmation=half_summary(point['per_panel_development'], HALVES[confirm_half]),
                                          heldout_primary=heldout_cache[cache_key]['primary'])
            rows[f'{direction}/seed{seed}'] = per_design
            print(json.dumps(dict(task=task, direction=direction, seed=seed, status='SCORED')), flush=True)
    scorer.source.verify()
    if require_seals(out) != seals:
        raise ValueError('Seal changed while scoring')
    value = dict(status='COMPLETE', task=task, seals_sha256=seals, rows=rows,
                 unique_heldout_checkpoints=len(heldout_cache), panel_recheck_failures=recheck_failures,
                 feedback_to_controller=False, historically_exposed_heldout=True,
                 wall_seconds=time.monotonic() - started)
    dump(target, value)
    return value


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--task', choices=TASKS, required=True)
    parser.add_argument('--out', type=Path, default=OUT)
    args = parser.parse_args()
    result = score_task(args.task, args.out)
    print(json.dumps(dict(status=result['status'], recheck_failures=len(result['panel_recheck_failures']))))
