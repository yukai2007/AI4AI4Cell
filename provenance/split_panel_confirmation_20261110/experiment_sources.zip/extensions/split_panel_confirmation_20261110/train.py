"""Fresh 100-round fits saving every evaluated round and splitting panel halves.

The optimizer/aggregation loop is the frozen panel_feedback loop. The only
additions are writes: one checkpoint per evaluated round, and the ten labelled
panel scores written as two half files instead of one development record.
No checkpoint is selected here; best.pt/last.pt are kept only so that training
can be checked bit-for-bit against the original supplement_history cache.
"""
import os
# Same CPU-only environment that task_runner.load_task sets, applied before torch loads.
os.environ['CUDA_VISIBLE_DEVICES'] = ''
for _name in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS',
              'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'):
    os.environ[_name] = '1'
import argparse
import copy
import json
from pathlib import Path
import time
import types

import numpy as np
import torch

from extensions.split_panel_confirmation_20261110.common import (
    CLIENTS, DESIGNS, EVAL_ROUNDS, HALVES, HERE, OLD, OUT, ROUNDS, SEEDS, TASKS,
    dump, fit_dir, freeze_json, read, round_checkpoint, sha)
from extensions.supplement_history_20261007.task_runner import fit_lock, load_task
from extensions.panel_feedback_20261110.payload import summarize_panels
from extensions.panel_feedback_20261110.runtime import federation


def split_halves(evidence):
    rows = {r['panel_id']: r for r in evidence['per_panel_development']}
    if sorted(rows) != sorted(HALVES['A'] + HALVES['B']):
        raise ValueError('Expected exactly the ten labelled target panels')
    return {half: [copy.deepcopy(rows[k]) for k in labels] for half, labels in HALVES.items()}


def fit_rounds(self, task, config, clients, out, seed, rounds=ROUNDS):
    """panel_feedback fit_cell/fit_protein, plus per-round checkpoint writes."""
    # Imported after load_task, as in panel_feedback runtime.federation.
    from extensions.panel_feedback_20261110.fitters import aggregate, aggregate_studies, validate, select_key
    config = validate(config)
    out = Path(out)
    out.mkdir(parents=True, exist_ok=False)
    (out / 'rounds').mkdir()
    started = time.monotonic()
    initialized = self.rpc(clients, [dict(op='init', config=config, seed=seed)] * len(clients))
    shared = initialized[0]['initial']
    keys = initialized[0]['parameter_keys']
    for item in initialized[1:]:
        if item['parameter_keys'] != keys or any(not np.array_equal(item['initial'][k], v) for k, v in shared.items()):
            raise ValueError('Clients must start with identical model parameters')
    velocity, curve, best = {}, [], None
    halves = dict(A=[], B=[])
    target_clients = [c for c in clients if c < 10]
    for rnd in range(1, rounds + 1):
        updates = self.rpc(clients, [dict(op='epoch', state=shared, seed=seed + rnd * 100 + c, batch_size=64) for c in clients])
        if task == 'cell':
            shared, velocity = aggregate(shared, [r['state'] for r in updates], [r['n'] for r in updates], velocity,
                                         config['server_momentum'], keys)
        else:
            shared, velocity = aggregate_studies(shared, updates, clients, velocity, config['server_momentum'], keys)
        row = dict(round=rnd, train_loss=sum(r['loss'] * r['n'] for r in updates) / sum(r['n'] for r in updates))
        if rnd % 5 == 0 or rnd == rounds:
            evidence = summarize_panels(self.rpc(target_clients, [dict(op='dev', state=shared)] * len(target_clients)))
            for half, values in split_halves(evidence).items():
                halves[half].append(dict(round=rnd, per_panel_development=values))
            torch.save(shared, out / 'rounds' / f'r{rnd:03d}.pt')
            # All-ten rule only to reproduce the original best.pt for the
            # equivalence check; never read by SPC selection.
            if best is None or select_key(evidence) > select_key(best):
                best = dict(primary=evidence['primary'], loss=evidence['loss'], round=rnd)
                torch.save(shared, out / 'best.pt')
            torch.save(dict(state=shared, velocity=velocity, round=rnd), out / 'last.pt')
        curve.append(row)
    for half, values in halves.items():
        dump(out / f'panels_{half}.json', dict(half=half, labels=HALVES[half], points=values))
    (out / 'reference_all_panels.json').write_text(json.dumps(best) + '\n')
    return dict(config=config, clients=clients, seed=seed, rounds=rounds, train_curve=curve,
                training_seconds=time.monotonic() - started, test_read=False)


def source_hashes():
    paths = sorted(HERE.glob('*.py')) + sorted((HERE.parent / 'panel_feedback_20261110').glob('*.py'))
    paths += [HERE.parent / 'supplement_history_20261007/task_runner.py',
              HERE.parent / 'unified_bio_20260918/core_v3.py',
              HERE.parent / 'unified_bio_20260918/core.py']
    return {str(p): sha(p) for p in paths}


def fit_one(task, seed, design, out=OUT):
    folder = fit_dir(out, task, seed, design)
    receipt = folder / 'receipt.json'
    if receipt.exists():
        return read(receipt)
    if folder.exists():
        raise ValueError('Partial fit preserved; inspect before rerun: ' + str(folder))
    source = load_task(task)
    folder.parent.mkdir(parents=True, exist_ok=True)
    with fit_lock(folder.parent, design):
        trainer = federation(task, source)
        trainer.fit_rounds = types.MethodType(fit_rounds, trainer)
        try:
            record = trainer.fit_rounds(task, DESIGNS[design], CLIENTS[task], folder, seed=seed)
        finally:
            trainer.close()
    dump(folder / 'fit.json', record)
    artifacts = sorted(p for p in folder.rglob('*') if p.is_file() and p.name != 'receipt.json')
    value = dict(status='COMPLETE', task=task, seed=seed, design=design, config=DESIGNS[design],
                 clients=CLIENTS[task], rounds=ROUNDS, eval_rounds=EVAL_ROUNDS,
                 training_seconds=record['training_seconds'], test_read=False,
                 source_sha256=source_hashes(),
                 artifacts_sha256={str(p.relative_to(folder)): sha(p) for p in artifacts})
    dump(receipt, value)
    return value


def verify_fit(task, seed, design, out=OUT):
    """Fresh training must reproduce the original cache exactly."""
    folder = fit_dir(out, task, seed, design)
    receipt = read(folder / 'receipt.json')
    for name, digest in receipt['artifacts_sha256'].items():
        if sha(folder / name) != digest:
            raise ValueError('Changed SPC artifact: ' + str(folder / name))
    old = OLD / task / f'seed{seed}' / 'fits' / design
    old_fit = read(old / 'fit.json')
    new_fit = read(folder / 'fit.json')
    load = lambda p: torch.load(p, map_location='cpu', weights_only=False)
    report = dict(task=task, seed=seed, design=design)
    report['train_curve_equal'] = [r['train_loss'] for r in old_fit['history']] == \
        [r['train_loss'] for r in new_fit['train_curve']]
    old_best_round = old_fit['best']['round']
    reference = read(folder / 'reference_all_panels.json')
    report['old_best_round'] = old_best_round
    report['reference_round_equal'] = reference['round'] == old_best_round
    report['reference_primary_loss_equal'] = (reference['primary'] == old_fit['best']['development']['primary']
                                              and reference['loss'] == old_fit['best']['development']['loss'])
    a, b = load(old / 'best.pt'), load(round_checkpoint(out, task, seed, design, old_best_round))
    report['old_best_equals_round_checkpoint'] = set(a) == set(b) and all(np.array_equal(a[k], b[k]) for k in a)
    if (old / 'last.pt').exists():
        a, b = load(old / 'last.pt'), load(folder / 'last.pt')
        report['last_state_velocity_equal'] = all(
            set(a[f]) == set(b[f]) and all(np.array_equal(a[f][k], b[f][k]) for k in a[f])
            for f in ('state', 'velocity')) and a['round'] == b['round']
    else:
        report['last_state_velocity_equal'] = None
    audit = read(OLD.parent / 'panel_feedback_20261110/dev_audit_v1' / task / 'development_audit.json')
    audited = audit['seeds'][str(seed)]['records'][design]
    expected = {r['panel_id']: r['development'] for r in audited['per_panel_development']}
    measured = {}
    for half in HALVES:
        point = next(p for p in read(folder / f'panels_{half}.json')['points'] if p['round'] == old_best_round)
        measured.update({r['panel_id']: r['development'] for r in point['per_panel_development']})
    report['audited_ten_panels_equal'] = audited['best_round'] == old_best_round and measured == expected
    report['pass'] = all(v is not False for k, v in report.items()
                         if k.endswith('_equal') or k.startswith('old_best_equals'))
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('fit', 'verify', 'verify-all'))
    parser.add_argument('--task', choices=TASKS)
    parser.add_argument('--seed', type=int, choices=SEEDS)
    parser.add_argument('--design', choices=sorted(DESIGNS))
    parser.add_argument('--out', type=Path, default=OUT)
    args = parser.parse_args()
    if args.command == 'fit':
        print(json.dumps(dict(fit_one(args.task, args.seed, args.design, args.out), source_sha256=None)), flush=True)
    elif args.command == 'verify':
        print(json.dumps(verify_fit(args.task, args.seed, args.design, args.out)), flush=True)
    elif args.command == 'verify-all':
        reports = [verify_fit(t, s, d, args.out) for t in TASKS for s in SEEDS for d in DESIGNS]
        freeze_json(args.out / 'train_equivalence.json', dict(
            reports=reports, all_pass=all(r['pass'] for r in reports), fits=len(reports)))
        print(json.dumps(dict(all_pass=all(r['pass'] for r in reports),
                              failures=[r for r in reports if not r['pass']])), flush=True)


if __name__ == '__main__':
    main()
