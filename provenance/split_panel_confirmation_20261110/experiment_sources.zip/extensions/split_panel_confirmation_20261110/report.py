"""Aggregate SPC scores: every arm, proposer, direction and seed; no filtering."""
import argparse
import json
from pathlib import Path

import numpy as np

from extensions.split_panel_confirmation_20261110.common import (
    DIRECTIONS, LLM_ARMS, OUT, PROPOSERS, SEEDS, TASKS, direction_dir, dump, read)

METRICS = ('selection', 'confirmation', 'heldout')
CONTRASTS = (('structured', 'direct'), ('raw', 'direct'), ('structured', 'raw'), ('structured', 'random'),
             ('structured', 'gp_ei'), ('direct', 'random'), ('direct', 'fixed'), ('random', 'fixed'),
             ('gp_ei', 'fixed'), ('structured', 'fixed'))


def value(row, metric):
    return row['heldout_primary'] if metric == 'heldout' else row[metric]['primary']


def arm_values(task, direction, seed, scores, out):
    base = direction_dir(out, direction) / task / f'seed{seed}'
    per_design = scores['rows'][f'{direction}/seed{seed}']
    controls = read(base / 'controls' / 'controls.json')
    result = {}
    def point(design):
        return {m: value(per_design[design], m) for m in METRICS} | dict(design_id=design, round=per_design[design]['round'])
    result['fixed'] = point('D00')
    result['gp_ei'] = point(controls['gp_ei']['design_id'])
    weights = controls['random']['weights']
    if abs(sum(weights.values()) - 1) > 1e-9:
        raise ValueError('Random weights must sum to one')
    result['random'] = {m: float(sum(w * value(per_design[d], m) for d, w in weights.items())) for m in METRICS}
    for proposer in PROPOSERS:
        selections = read(base / proposer / 'selections.json')['selections']
        for arm in LLM_ARMS:
            item = selections[arm]
            result[f'{proposer}/{arm}'] = point(item['design_id']) | dict(invalid_slots=item['invalid_slots'])
    return result


def summarize(out=OUT):
    out = Path(out)
    table, paired = {}, {}
    for task in TASKS:
        scores = read(out / 'scores' / f'{task}.json')
        if scores['panel_recheck_failures']:
            raise ValueError('Checkpoint panel re-evaluation failed; do not report')
        for direction in DIRECTIONS:
            per_seed = {seed: arm_values(task, direction, seed, scores, out) for seed in SEEDS}
            arms = per_seed[SEEDS[0]].keys()
            for arm in arms:
                table[f'{task}/{direction}/{arm}'] = dict(
                    {m: dict(mean_pp=100 * float(np.mean([per_seed[s][arm][m] for s in SEEDS])),
                             per_seed_pp=[100 * per_seed[s][arm][m] for s in SEEDS]) for m in METRICS},
                    designs=[per_seed[s][arm].get('design_id') for s in SEEDS],
                    rounds=[per_seed[s][arm].get('round') for s in SEEDS],
                    optimism_pp=100 * float(np.mean([per_seed[s][arm]['selection'] - per_seed[s][arm]['confirmation']
                                                       for s in SEEDS])))
            for proposer in PROPOSERS:
                for left, right in CONTRASTS:
                    name = lambda a: a if a in ('fixed', 'random', 'gp_ei') else f'{proposer}/{a}'
                    if left in ('fixed', 'random', 'gp_ei') and proposer != PROPOSERS[0]:
                        continue
                    key = f'{task}/{direction}/{name(left)}-{name(right)}'
                    paired[key] = {m: [100 * (per_seed[s][name(left)][m] - per_seed[s][name(right)][m]) for s in SEEDS]
                                   for m in ('confirmation', 'heldout')}
    report = dict(status='COMPLETE', table=table, paired_differences_pp=paired,
                  reporting='all tasks, directions, seeds, proposers and arms; random is the exact subset expectation')
    dump(out / 'report.json', report)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, default=OUT)
    args = parser.parse_args()
    report = summarize(args.out)
    for k, v in report['table'].items():
        print(k, *(f"{m}={v[m]['mean_pp']:.2f}" for m in METRICS), v['designs'])
