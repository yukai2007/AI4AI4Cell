"""Engineering check on real fits with a deterministic mock proposer.

Writes only to a separate mock output folder that symlinks the trained fits.
Held-out scoring is stubbed out: no test response is read by this check.
"""
import json
from pathlib import Path
import shutil
import sys

from extensions.split_panel_confirmation_20261110 import common, protocol, search, score
from extensions.split_panel_confirmation_20261110.common import OUT, SEEDS, TASKS, PROPOSERS


class MockBackend:
    def __init__(self, folder):
        Path(folder).mkdir(parents=True, exist_ok=False)
        self.calls = 0

    def generate_json(self, messages, *, seed, context, validator, schema_description, max_repairs=1):
        card = json.loads(messages[1]['content'])
        self.calls += 1
        # First available design in lexical order; slot 3 deliberately invalid to exercise charging.
        if context['slot'] == 3 and context['arm'] == 'raw':
            return dict(valid=False, parsed=None, attempts=[{}, {}])
        design = sorted(card['available_designs'])[(seed % 7) % len(card['available_designs'])]
        value = dict(design_id=design, reference_id=card['proposal_reference_id'],
                     changed_fields=card['available_changed_fields'][design], hypothesis='h', experiment='e',
                     expected_effect='x', prediction=dict(metric='primary', direction='increase', min_delta=0.0))
        validator(value)
        return dict(valid=True, parsed=value, attempts=[{}])


def main(mock):
    mock = Path(mock)
    if mock.exists():
        shutil.rmtree(mock)
    mock.mkdir(parents=True)
    (mock / 'train').symlink_to(OUT / 'train')
    for name in ('protocol_stage1.json', 'registration_stage1.json'):
        shutil.copy(OUT / name, mock / name)
    protocol.freeze(2, mock)
    search.make_backend = lambda proposer, folder, device: MockBackend(folder)
    for direction in ('AB', 'BA'):
        for task in TASKS:
            for seed in SEEDS:
                # Confirmation half must be closed before the seal.
                try:
                    common.panel_file(mock, task, seed, 'D00', common.DIRECTIONS[direction][1],
                                      direction=direction, purpose='confirmation')
                    raise AssertionError('confirmation half opened before seal')
                except PermissionError:
                    pass
                try:
                    common.panel_file(mock, task, seed, 'D00', common.DIRECTIONS[direction][1],
                                      direction=direction, purpose='selection')
                    raise AssertionError('selection read the confirmation half')
                except PermissionError:
                    pass
                search.run_controls(task, seed, direction, mock)
                for proposer in PROPOSERS:
                    result = search.run_llm(task, seed, direction, proposer, out=mock)
                    assert result['selections']['raw']['invalid_slots'] == 1, result
        search.seal(direction, mock)
    score.Scorer.heldout = lambda self, config, checkpoint, folder: dict(primary=0.0)
    task = sys.argv[2] if len(sys.argv) > 2 else 'cell'
    result = score.score_task(task, mock)
    assert not result['panel_recheck_failures'], result['panel_recheck_failures'][:3]
    logs = 0
    for d, (select_half, confirm_half) in common.DIRECTIONS.items():
        for line in (mock / 'directions' / d / 'access_log.jsonl').read_text().splitlines():
            row = json.loads(line)
            assert row['half'] == (select_half if row['purpose'] == 'selection' else confirm_half), row
            logs += 1
    print(json.dumps(dict(status='MOCK_PASS', task=task, access_reads=logs,
                          recheck_failures=len(result['panel_recheck_failures']))))


if __name__ == '__main__':
    main(sys.argv[1])
