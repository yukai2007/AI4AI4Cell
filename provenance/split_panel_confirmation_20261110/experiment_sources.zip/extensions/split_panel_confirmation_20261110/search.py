"""SPC search: fixed, direct/raw/structured (Qwen, Luna), exact random and GP-EI.

Every arm sees only the selection half of one direction. Candidate records are
derived from the fresh fits by choosing each fit's checkpoint round on the
selection half. The confirmation half and held-out data are never opened here.
"""
import argparse
from copy import deepcopy
import json
from pathlib import Path

from extensions.split_panel_confirmation_20261110.common import (
    BUDGET, DESIGNS, DIRECTIONS, HALVES, LLM_ARMS, OUT, PROPOSERS, SEEDS, TASKS,
    direction_dir, dump, fit_dir, half_summary, now, panel_file, read, select_round, sha)
from extensions.split_panel_confirmation_20261110.protocol import checked
from extensions.history_repair_20261109.evidence_cards import build_evidence_card
from extensions.history_repair_20261109.search_v3 import (
    SCHEMA, key, next_history, observed_record, validate_proposal)

DESCRIPTIONS = {
    'protein': (
        'Predict binary target efficacy from drug features and observed proteomic responses. '
        'Four training laboratories correspond to PTPC, Lin, Ruprecht and decryptE studies. '
        'Shared protein/drug encoders receive sample-weighted local updates; each study owns its prediction head. '
        'Five fixed PTPC target-development panels select checkpoints and candidates, by equal-panel average '
        'precision then lower binary cross-entropy.'),
    'cell': (
        'Identify the true single-gene perturbation from an observed expression response and five fixed options. '
        'Four source-defined laboratories are VCC, Replogle/K562, Nadig/HepG2 and Jiang/IFNB/K562, '
        'with fifteen training interventions per laboratory and source-specific measured-gene masks. '
        'A frozen scDEBART representation supplies a trainable response head. Local training uses response '
        'MSE plus 0.1 contrastive loss; five fixed VCC target-development panels select checkpoints and '
        'candidates by equal-panel macro Top-1 then lower cross-entropy.'),
}
SYSTEM = (
    'You choose biological prediction experiments to maximize the final retained development score '
    'within the remaining candidate-request budget. You are not rewarded for confirming a predicted '
    'decrease. Exploration is allowed when it has a clear rationale for finding a better final model. '
    'Use only the supplied candidate configurations and observed evidence. All candidates receive the same '
    'complete 100-round federated schedule on the same four training laboratories: local AdamW reset each '
    'round, one full local epoch, batch size 64, norm clipping 1, sample-weighted parameter averaging and '
    'optional server momentum. Neither history nor your explanation changes that schedule. Candidates restart '
    'from the registered initialization. residual=True adds a zero-output-initialized 32-wide adapter and '
    'trains the base head too. Every five rounds the development panels are scored; each candidate keeps the '
    'round with the highest equal-panel primary, lower loss breaking ties. '
    'Return one concise JSON object with exactly design_id, reference_id, changed_fields, hypothesis, '
    'experiment, expected_effect, prediction. Choose an available untried design_id. Copy reference_id '
    'from the supplied proposal_reference_id. changed_fields is the exact list of configuration keys '
    'whose values differ from reference_config; explain those changes, not imagined components. '
    'hypothesis, experiment and expected_effect are nonempty strings. prediction has exactly metric '
    "('primary' or 'loss'), direction ('increase' or 'decrease'), min_delta (nonnegative absolute "
    'metric units). 0.01 primary is one percentage point. Predictions refer to candidate minus '
    'reference at their selected development checkpoints. Distinguish observations from hypotheses. '
    'Do not invent scores or individual sample data. JSON only, under 512 output tokens.'
)


def scope(task, direction):
    half = DIRECTIONS[direction][0]
    return dict(task=DESCRIPTIONS[task], training_labs=4, development_panels=len(HALVES[half]),
                development_panel_ids=HALVES[half], panels_are_not_training_labs=True,
                selection='equal-panel primary mean, then lower loss; exact ties retain incumbent')


def candidate_records(task, seed, direction, out=OUT):
    """Selection-half record per design, in search_v3.observed_record format."""
    half = DIRECTIONS[direction][0]
    records = {}
    for design, config in DESIGNS.items():
        receipt = read(fit_dir(out, task, seed, design) / 'receipt.json')
        if receipt['status'] != 'COMPLETE' or receipt['config'] != config:
            raise ValueError('Incomplete or changed fit: ' + design)
        panels = panel_file(out, task, seed, design, half, direction=direction, purpose='selection')
        if receipt['artifacts_sha256'][f'panels_{half}.json'] != sha(fit_dir(out, task, seed, design) / f'panels_{half}.json'):
            raise ValueError('Panel half changed after training: ' + design)
        train_loss = {r['round']: r['train_loss'] for r in read(fit_dir(out, task, seed, design) / 'fit.json')['train_curve']}
        curve = [dict(round=p['round'], train_loss=train_loss[p['round']],
                      development=half_summary(p['per_panel_development'], HALVES[half]),
                      panels=p['per_panel_development']) for p in panels['points']]
        chosen = select_round(curve)
        development = dict(chosen['development'], per_context={
            r['panel_id']: dict(r['development']) for r in chosen['panels']})
        records[design] = dict(config=deepcopy(config), development=development, best_round=chosen['round'],
                               status='COMPLETE',
                               trajectory=[{k: r[k] for k in ('round', 'train_loss', 'development')} for r in curve])
    return records


def make_messages(history, arm, slot, task, direction):
    mode = 'direct' if slot == 1 else arm
    card = build_evidence_card(history, mode, designs=DESIGNS, evaluation_scope=scope(task, direction),
                               total_slots=BUDGET)
    card['proposal_reference_id'] = next(k for k, v in DESIGNS.items() if v == card['reference_config'])
    card['available_changed_fields'] = {
        name: sorted(k for k in config if config[k] != card['reference_config'][k])
        for name, config in card['available_designs'].items()}
    return [dict(role='system', content=SYSTEM),
            dict(role='user', content=json.dumps(card, ensure_ascii=False, allow_nan=False))], card


def agent_seed(seed, direction, slot):
    return 100000 * seed + (0 if direction == 'AB' else 50000) + slot


def make_backend(proposer, folder, device):
    if proposer == 'qwen':
        from extensions.history_repair_20261109.backend_v3 import LocalQwenBackend
        return LocalQwenBackend(folder, device=device, max_calls=32)
    from extensions.recipe_search_compact_20261110.luna_backend import LunaBackend
    return LunaBackend(folder)


def run_llm(task, seed, direction, proposer, device='cuda:0', out=OUT):
    checked(1, out)
    checked(2, out)
    base = direction_dir(out, direction) / task / f'seed{seed}' / proposer
    if (base / 'selections.json').exists():
        return read(base / 'selections.json')
    if base.exists():
        raise ValueError('Partial search preserved; inspect before rerun: ' + str(base))
    records = candidate_records(task, seed, direction, out)
    dump(base / 'inputs.json', dict(task=task, seed=seed, direction=direction, proposer=proposer,
         records_sha256=sha_json(records), started_utc=now()))
    backend = make_backend(proposer, base / 'backend', device)
    baseline = observed_record(records['D00'], 'D00', DESIGNS)
    baseline['accepted'] = True
    histories = {arm: [deepcopy(baseline)] for arm in LLM_ARMS}
    messages, card = make_messages(histories['direct'], 'direct', 1, task, direction)
    shared = backend.generate_json(messages, seed=agent_seed(seed, direction, 1),
        context=dict(task=task, seed=seed, direction=direction, slot=1, arm='shared_cold_start'),
        validator=lambda v: validate_proposal(v, card), schema_description=SCHEMA, max_repairs=1)
    dump(base / 'shared_first.json', shared)
    for arm in LLM_ARMS:
        histories[arm] = next_history(histories[arm], shared, records, DESIGNS, card)
        dump(base / arm / 'slot1.json', dict(request=shared, history=histories[arm], shared_request=True))
    for slot in range(2, BUDGET + 1):
        for arm in LLM_ARMS:
            messages, card = make_messages(histories[arm], arm, slot, task, direction)
            request = backend.generate_json(messages, seed=agent_seed(seed, direction, slot),
                context=dict(task=task, seed=seed, direction=direction, slot=slot, arm=arm),
                validator=lambda v: validate_proposal(v, card), schema_description=SCHEMA, max_repairs=1)
            histories[arm] = next_history(histories[arm], request, records, DESIGNS, card)
            dump(base / arm / f'slot{slot}.json', dict(request=request, history=histories[arm]))
            print(json.dumps(dict(task=task, seed=seed, direction=direction, proposer=proposer, arm=arm,
                                  slot=slot, valid=request['valid'],
                                  design=(request.get('parsed') or {}).get('design_id'))), flush=True)
    selections = {}
    for arm, history in histories.items():
        valid = [r for r in history if r.get('development')]
        selected = max(valid, key=key)
        curve, incumbent = [], baseline
        for row in history:
            if row.get('development') and key(row) > key(incumbent):
                incumbent = row
            curve.append(incumbent['design_id'])
        selections[arm] = dict(design_id=selected['design_id'], round=records[selected['design_id']]['best_round'],
                               selection_development={k: selected['development'][k] for k in ('primary', 'loss')},
                               candidate_ids=[r['design_id'] for r in valid], invalid_slots=len(history) - len(valid),
                               prefix_incumbents=curve)
    dump(base / 'selections.json', dict(selections=selections, shared_first=(shared.get('parsed') or {}).get('design_id'),
                                        llm_calls=backend.calls, completed_utc=now()))
    return read(base / 'selections.json')


def sha_json(value):
    import hashlib
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def run_controls(task, seed, direction, out=OUT):
    """Fixed, exact random and GP-EI; deterministic and LLM-free."""
    from extensions.history_repair_20261109.controls import exact_random_weights, random_prefix_curve, select_gp
    checked(1, out)
    checked(2, out)
    base = direction_dir(out, direction) / task / f'seed{seed}' / 'controls'
    if (base / 'controls.json').exists():
        return read(base / 'controls.json')
    records = candidate_records(task, seed, direction, out)
    weights, count = exact_random_weights(records, budget=BUDGET)
    trace, selected, ids = select_gp(DESIGNS, lambda k: deepcopy(records[k]), seed, budget=BUDGET)
    rounds = {d: r['best_round'] for d, r in records.items()}
    value = dict(fixed=dict(design_id='D00', round=rounds['D00']),
                 random=dict(weights=weights, subsets=count),
                 random_prefix=random_prefix_curve(records, max_budget=BUDGET),
                 gp_ei=dict(design_id=selected, round=rounds[selected], candidate_ids=ids, trace=trace),
                 selected_rounds=rounds,
                 selection_development={d: {k: r['development'][k] for k in ('primary', 'loss')} for d, r in records.items()},
                 records_sha256=sha_json(records), completed_utc=now())
    dump(base / 'controls.json', value)
    return value


def seal(direction, out=OUT):
    checked(2, out)
    root = direction_dir(out, direction)
    files = []
    for task in TASKS:
        for seed in SEEDS:
            files.append(root / task / f'seed{seed}' / 'controls' / 'controls.json')
            files += [root / task / f'seed{seed}' / p / 'selections.json' for p in PROPOSERS]
    missing = [str(p) for p in files if not p.exists()]
    if missing:
        raise ValueError('Cannot seal incomplete direction: ' + ', '.join(missing))
    transcripts = sorted(p for p in root.rglob('*.json') if p.name != 'seal.json')
    dump(root / 'seal.json', dict(direction=direction, sealed_utc=now(), confirmation_read=False,
         heldout_read=False, selections_sha256={str(p): sha(p) for p in files},
         transcripts_sha256={str(p): sha(p) for p in transcripts},
         access_log_sha256=sha(root / 'access_log.jsonl')))
    return read(root / 'seal.json')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('llm', 'controls', 'seal'))
    parser.add_argument('--direction', choices=sorted(DIRECTIONS), required=True)
    parser.add_argument('--task', choices=TASKS)
    parser.add_argument('--seed', type=int, choices=SEEDS)
    parser.add_argument('--proposer', choices=PROPOSERS)
    parser.add_argument('--device', default='cuda:0')
    parser.add_argument('--out', type=Path, default=OUT)
    args = parser.parse_args()
    if args.command == 'llm':
        result = run_llm(args.task, args.seed, args.direction, args.proposer, args.device, args.out)
        print(json.dumps(dict(status='SELECTED', **{a: s['design_id'] for a, s in result['selections'].items()})))
    elif args.command == 'controls':
        result = run_controls(args.task, args.seed, args.direction, args.out)
        print(json.dumps(dict(status='CONTROLS', gp=result['gp_ei']['design_id'])))
    else:
        print(json.dumps(dict(status='SEALED', direction=seal(args.direction, args.out)['direction'])))


if __name__ == '__main__':
    main()
