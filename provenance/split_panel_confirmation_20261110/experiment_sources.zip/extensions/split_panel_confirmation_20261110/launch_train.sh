#!/usr/bin/env bash
# 72 fresh CPU fits, 24 at a time (4 single-thread workers each), then equivalence verification.
set -euo pipefail
cd /liziqing/yukai/AI4AI4Cell
PY=/opt/conda/envs/LDA/bin/python
OUTDIR=results/split_panel_confirmation_20261110/v1
mkdir -p "$OUTDIR/logs"
$PY -m extensions.split_panel_confirmation_20261110.protocol 1 --out "$OUTDIR"
for task in cell protein; do for seed in 61 62 63; do for d in D00 D01 D02 D03 D04 D05 D06 D07 D08 D09 D10 D11; do
  echo "$task $seed $d"; done; done; done |
  xargs -P 24 -L 1 bash -c '$0 -m extensions.split_panel_confirmation_20261110.train fit --task $1 --seed $2 --design $3 --out '"$OUTDIR"' > '"$OUTDIR"'/logs/fit_$1_$2_$3.log 2>&1 || echo FAILED $1 $2 $3' "$PY"
$PY -m extensions.split_panel_confirmation_20261110.train verify-all --out "$OUTDIR" > "$OUTDIR/logs/verify_all.log" 2>&1
echo DONE
